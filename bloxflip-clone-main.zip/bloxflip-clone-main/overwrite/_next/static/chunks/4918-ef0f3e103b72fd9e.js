// hooked
(function () {
    try {
      var e = typeof window != "undefined" ? window : typeof global != "undefined" ? global : typeof self != "undefined" ? self : {};
      var t = new e.Error().stack;
      if (t) {
        e._sentryDebugIds = e._sentryDebugIds || {};
        e._sentryDebugIds[t] = "8a9edd26-cc88-46ee-9357-86aa2d4560d4";
        e._sentryDebugIdIdentifier = "sentry-dbid-8a9edd26-cc88-46ee-9357-86aa2d4560d4";
      }
    } catch (e) {}
  })();
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[4918], {
    72064: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0.3 0 6.69 12.05"
        }, e), n ||= s.createElement("path", {
          d: "M.305 6.026c0 .216.08.432.24.596l5.05 5.182c.321.33.842.33 1.163 0a.86.86 0 0 0 0-1.194L2.29 6.026 6.758 1.44a.86.86 0 0 0 0-1.193.807.807 0 0 0-1.163 0L.545 5.43a.853.853 0 0 0-.24.597Z",
          fill: "#fff"
        }));
      };
    },
    33722: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0.31 0 6.69 12.05"
        }, e), n ||= s.createElement("path", {
          d: "M7 6.026c0 .216-.08.432-.24.596l-5.05 5.182a.808.808 0 0 1-1.164 0 .86.86 0 0 1 0-1.194l4.469-4.584L.547 1.44a.86.86 0 0 1 0-1.193.807.807 0 0 1 1.163 0L6.76 5.43c.16.165.24.38.24.597Z",
          fill: "#fff"
        }));
      };
    },
    28310: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 12,
          height: 13,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          d: "M11.172 5.672H6.828V1.328A.83.83 0 0 0 6 .5a.83.83 0 0 0-.828.828v4.344H.828A.83.83 0 0 0 0 6.5a.83.83 0 0 0 .828.828h4.344v4.344A.83.83 0 0 0 6 12.5a.83.83 0 0 0 .828-.828V7.328h4.344A.83.83 0 0 0 12 6.5a.83.83 0 0 0-.828-.828Z",
          fill: "#818EBB"
        }));
      };
    },
    91897: function (e, t, a) {
      "use strict";
  
      var n;
      var s;
      var l = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return l.createElement("svg", _extends({
          width: 18,
          height: 18,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= l.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3.691.881a1.87 1.87 0 0 0-2.643 2.644L6.522 9l-5.475 5.476a1.87 1.87 0 0 0 2.643 2.643l5.476-5.475 5.475 5.475a1.87 1.87 0 0 0 2.644-2.643L11.81 9l5.476-5.475A1.87 1.87 0 1 0 14.642.88L9.167 6.357 3.69.88Z",
          fill: "url(#cross_svg__a)"
        }), s ||= l.createElement("defs", null, l.createElement("linearGradient", {
          id: "cross_svg__a",
          x1: 9.167,
          y1: 0.333,
          x2: 9.5,
          y2: 18,
          gradientUnits: "userSpaceOnUse"
        }, l.createElement("stop", {
          stopColor: "#FF1469"
        }), l.createElement("stop", {
          offset: 1,
          stopColor: "#C12375"
        }))));
      };
    },
    66713: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 17,
          height: 19,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("g", {
          clipPath: "url(#currency_svg__clip0_1_2)",
          fill: "currentColor"
        }, s.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M14.975 5.35 8.836 1.788a.67.67 0 0 0-.672 0L2.025 5.351a.677.677 0 0 0-.336.585v7.128c0 .241.128.465.336.585l6.139 3.564a.67.67 0 0 0 .672 0l6.139-3.564a.677.677 0 0 0 .336-.585V5.936a.677.677 0 0 0-.336-.585ZM9.509.616a2.009 2.009 0 0 0-2.018 0L1.353 4.18a2.032 2.032 0 0 0-1.01 1.757v7.128c0 .725.385 1.395 1.01 1.757l6.138 3.564a2.009 2.009 0 0 0 2.018 0l6.139-3.564a2.031 2.031 0 0 0 1.009-1.757V5.936c0-.725-.385-1.395-1.01-1.757L9.51.615Z"
        }), s.createElement("path", {
          d: "M3.74 13V6.2h4.34v1.2H5.12v2h2.42v1.2H5.12V13H3.74ZM13.393 11.01c0 .693-.21 1.22-.63 1.58-.42.353-.97.53-1.65.53h-.01l-.15 1.18c-.494-.02-.74-.043-.74-.07l.14-1.16c-.494-.06-.907-.13-1.24-.21l-.2-.04.13-1.04a18.68 18.68 0 0 0 1.46.15l.22-1.74c-.687-.207-1.174-.457-1.46-.75-.287-.293-.43-.693-.43-1.2 0-.66.2-1.15.6-1.47.4-.327.95-.49 1.65-.49h.13l.18-1.38h.74l-.18 1.44c.413.04.793.093 1.14.16l.17.04-.11 1.06a30.48 30.48 0 0 0-1.35-.12l-.2 1.61c.693.22 1.163.463 1.41.73.253.26.38.657.38 1.19Zm-3.23-2.86c0 .16.05.29.15.39.1.1.293.203.58.31l.17-1.39c-.6.027-.9.257-.9.69Zm1.9 2.95c0-.16-.047-.29-.14-.39-.087-.107-.247-.207-.48-.3l-.19 1.53c.54-.06.81-.34.81-.84Z"
        })));
      };
    },
    72786: function (e, t, a) {
      "use strict";
  
      var n;
      var s;
      var l;
      var r = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return r.createElement("svg", _extends({
          xmlns: "http://www.w3.org/2000/svg",
          width: 27,
          height: 27,
          viewBox: "0 0 832 758"
        }, e), n ||= r.createElement("path", {
          d: "M340.5 39.6c-1.1.3-5.4 1.4-9.5 2.4s-19.4 6.9-34 13c-14.6 6.2-32.8 13.9-40.5 17.2-7.7 3.2-22.7 9.5-33.3 13.9-10.7 4.4-21.7 9.1-24.5 10.4-2.9 1.2-16.7 7.1-30.7 13s-26.8 11.3-28.5 12c-1.6.7-10.2 4.3-19 8s-17.3 7.3-19 8c-1.6.7-5.6 2.5-8.7 3.8-17.4 7.7-36.8 27-45 44.7-7.5 16.2-10.3 30.3-9.5 48.2.4 10 .9 13.7 3.2 19.8 2.2 6.2 12.5 31 18 43.5.7 1.6 7.3 16.9 14.5 34 19.2 45.1 22 51.7 23.5 55 .7 1.6 7.7 18.1 15.5 36.5s19.3 45.4 25.5 60c6.2 14.6 15.1 35.5 19.7 46.5 36.1 85 37.2 87.3 49.6 102 18.6 22 38.3 31.8 66.7 33.2 6.6.3 15.2.2 19-.2l6.9-.7-2.9-2.2c-9.9-7.1-21.5-22.8-27.5-37.3-1.7-4.1-7.5-24.4-12.9-45.1-23.3-89.3-37.2-141.9-70.1-265.2-19.2-71.9-21-79.8-21-93.9 0-21.6 10.1-51.1 23.9-69.7 11.5-15.6 23.5-25.8 42.9-36.3 13.6-7.4 21.6-10 76.2-24.6 90.9-24.3 103.5-27.7 103.8-28 .2-.2-2.5-2.5-6-5-15.1-11.2-30.7-16.4-51.3-17-7.1-.2-13.9-.2-15 .1z"
        }), s ||= r.createElement("path", {
          d: "M516.7 62.1c-6.1.6-16 2.6-26 5.3-8.9 2.4-33.5 9-54.7 14.6-21.2 5.6-48.4 12.8-60.5 16-12.1 3.2-36.6 9.8-54.5 14.5-17.9 4.7-39.2 10.4-47.4 12.6-16.6 4.4-26.6 9-38.6 17.9-15.9 11.9-28.2 30.2-34.6 51.5-2.3 7.8-2.7 10.9-2.8 23-.1 15.9-2.4 5.6 21.3 93.5 6.2 22.8 15.4 57.2 20.6 76.5 8.8 33.1 21.5 80.3 46.6 174 15 55.8 14.9 55.5 21.5 65.5 13.2 19.7 23.7 29.5 39.5 36.4l5.6 2.4-3.7-8.6c-2.1-4.8-5.3-13.4-7.1-19.2l-3.4-10.5V426c0-217.8-.2-209.7 5.4-226.2 6.5-19.2 15.8-32.8 32-46.8 19.3-16.6 39.3-26.6 62.6-31.1 4.1-.8 32.1-1.3 89.3-1.6l83.4-.5-.7-2.6c-.8-3.7-8.3-14.4-15.5-22.5-12.5-13.7-27.3-23.5-43.1-28.6-6-2-22.2-5.3-24.4-5-.5.1-5.4.6-10.8 1z"
        }), l ||= r.createElement("path", {
          d: "M444.6 153.6c-25.5 5.5-46.5 19.9-61.3 41.9-8.5 12.7-12.9 24.3-14.4 38.5-.6 6.2-.9 77.9-.7 206l.3 196.5 4.2 11.4c7.8 20.8 10.6 25.4 22.3 37.1 9.1 9.1 12.1 11.3 22 16.7 6.3 3.4 15.8 7.7 21 9.5l9.5 3.3h269l9-2.8c24.5-7.6 45.2-22.6 57.7-41.7 6.9-10.6 10-18.4 12.9-32.5 2.2-10.5 2.3-13.5 2.6-68.5.2-31.6 0-121.2-.5-199-.8-138.6-.9-141.6-2.9-147-3.2-8.7-11.1-23.8-16.5-31.7-11.9-17.3-32.5-31.6-52.7-36.6-8.5-2.1-9.4-2.1-141.6-2.3-114.5-.2-134-.1-139.9 1.2zM602 287.9c18.4 6.4 34.6 23.9 39.4 42.7 2 7.8 2.1 21.2.1 28.7-1.7 6.6-5.8 15.2-8.8 18.4l-2 2.3h8.4c28.2 0 52 18.9 59.4 47 3.1 11.9.7 27.7-6.3 41.5-4 8-15 19.2-23.4 23.9-10.3 5.7-15.6 7-29.3 7.1-13.7 0-21.2-1.9-30.3-7.9-2.8-1.9-5.5-3.7-6.1-4-.5-.3 1.1 5.6 3.5 13.2 9.2 28.6 9.1 27.9 6.8 32.1-3.1 5.8-4.3 6.1-30.5 6.1-22.9 0-23.7-.1-27-2.3-6-4-6-7-.4-27.5 2.6-9.7 5-18.3 5.3-19 .2-.7-3.6.7-8.4 3.2-10.3 5.1-16.5 6.6-27.3 6.6-17.5 0-36.1-9.7-46.6-24.4-5.2-7.3-9.9-18.5-11.5-27.6-2.9-16.1 3.2-34.8 15.6-48 12.5-13.3 24.5-19.1 40.9-19.8l10-.4-3.7-7.7c-5.6-11.3-7.2-18.6-6.5-30.6.6-12.2 4-21.4 11.6-31.5 8.8-11.6 23-21.1 36.6-24.4 1.1-.3 7-.4 13-.2 8.2.2 12.7.9 17.5 2.5z"
        }));
      };
    },
    15108: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 25,
          height: 24,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M5.135 3.01C3.757 2.916 1 3.448 1 6.332v5.228h4.135V3.01Zm1.863 8.55V3.08h11.048v8.48h-3.085V9.55H9.977v2.011H6.998Zm0 1.958V21h11.048v-7.482h-3.085v1.014H9.977v-1.014H6.998Zm17.01-7.186c0-2.884-2.756-3.416-4.134-3.322v8.55h4.135V6.332ZM5.136 21H1.99c-.295 0-.884-.226-.884-1.131v-6.35h4.03V21Zm17.955 0h-3.146v-7.482h4.03v6.351c0 .905-.59 1.131-.884 1.131ZM13.5 11h-2v2h2v-2Z"
        }));
      };
    },
    46198: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 25,
          height: 25,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3.354 19.596a1.644 1.644 0 1 1 2.05 2.051l-2.353.714a.329.329 0 0 1-.41-.41l.713-2.355Zm8.82-15.568C15.05 2.154 18.47 2 22.015 2c.544 0 .986.441.984.985 0 3.403-.156 6.966-2.029 9.842-.987 1.517-2.37 2.777-3.916 3.794a8.228 8.228 0 0 1-3.423 6.197.99.99 0 0 1-.949.109.988.988 0 0 1-.595-.747c-.15-.886-.548-1.868-1.133-2.86-.656.18-1.293.325-1.89.428a.985.985 0 0 1-.866-.274l-2.674-2.673a.985.985 0 0 1-.274-.866c.103-.596.25-1.233.428-1.889-.99-.585-1.972-.983-2.858-1.132a.985.985 0 0 1-.638-1.545A8.232 8.232 0 0 1 8.38 7.945c1.016-1.546 2.276-2.929 3.793-3.917Zm3.69 7.752a2.848 2.848 0 1 0 0-5.696 2.848 2.848 0 0 0 0 5.696Z"
        }));
      };
    },
    56753: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 25,
          height: 24,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          d: "M20.704 5.5h-.596l-.358-1.875c0-.346-.214-.625-.477-.625H5.909c-.263 0-.477.28-.477.625L5.074 5.5h-.597c-.263 0-.477.28-.477.625 0 .346.214.625.477.625h16.227c.264 0 .478-.28.478-.625 0-.346-.214-.625-.477-.625ZM19.267 8.625H5.725c-.55 0-.535.317-.459.475.46 3.65 1.377 11.043 1.377 11.424 0 .38.517.476.775.476H17.89c.55 0 .688-.238.688-.357.46-3.768 1.377-11.376 1.377-11.662 0-.285-.459-.356-.688-.356Z"
        }));
      };
    },
    82685: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 19,
          height: 17,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10.646 7.99a1.458 1.458 0 0 1-.872-1.87l1.568-4.306A1.458 1.458 0 0 1 13.21.942l4.307 1.568a1.458 1.458 0 0 1 .871 1.869l-1.567 4.307a1.458 1.458 0 0 1-1.87.872L10.647 7.99Zm3.152-1.957a.833.833 0 1 0 .57-1.566.833.833 0 0 0-.57 1.566ZM.981 8.25a1.458 1.458 0 0 0-.705 1.938l2.641 5.664a1.458 1.458 0 0 0 1.938.706l5.665-2.642a1.458 1.458 0 0 0 .705-1.938L8.584 6.315a1.458 1.458 0 0 0-1.938-.705L.98 8.25Zm3.861 1.877a.833.833 0 1 1-1.51.704.833.833 0 0 1 1.51-.704Zm2.921 2.316a.833.833 0 1 0-.705-1.51.833.833 0 0 0 .705 1.51Z"
        }));
      };
    },
    79081: function (e, t, a) {
      "use strict";
  
      var n;
      var s;
      var l = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return l.createElement("svg", _extends({
          width: 24,
          height: 24,
          viewBox: "0 0 17 16",
          fill: "currentColor",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= l.createElement("g", {
          clipPath: "url(#jackpot_svg__a)"
        }, l.createElement("path", {
          d: "M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0Zm0 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm4.773 8.773A6.706 6.706 0 0 1 8 14.75a6.706 6.706 0 0 1-4.773-1.977A6.706 6.706 0 0 1 1.25 8c0-1.803.702-3.498 1.977-4.773l1.061 1.061a5.256 5.256 0 0 0 0 7.425A5.215 5.215 0 0 0 8 13.251a5.213 5.213 0 0 0 3.712-1.538 5.256 5.256 0 0 0 0-7.425l1.061-1.061A6.706 6.706 0 0 1 14.75 8a6.706 6.706 0 0 1-1.977 4.773Z"
        })), s ||= l.createElement("defs", null, l.createElement("clipPath", {
          id: "jackpot_svg__a"
        }, l.createElement("path", {
          d: "M0 0h16v16H0z"
        }))));
      };
    },
    38804: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 24,
          height: 24,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          d: "M5.84 4c-.256-.011-.48.145-.693.352l-2.95 3.522c-.421.503-.066.75.136 1.048l9.045 10.674c.357.46.754.611 1.256 0l9.264-10.942c.184-.25.097-.502-.082-.753L18.81 4.326c-.192-.193-.435-.326-.82-.296H6.022A.706.706 0 0 0 5.84 4Z"
        }));
      };
    },
    34666: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 24,
          height: 24,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M9.92 17.693a3.96 3.96 0 1 1-7.92 0 3.96 3.96 0 0 1 7.92 0Zm11.733 0a3.96 3.96 0 1 1-7.92 0 3.96 3.96 0 0 1 7.92 0ZM15.787 5.96a3.96 3.96 0 1 1-7.92 0 3.96 3.96 0 0 1 7.92 0Z"
        }));
      };
    },
    82499: function (e, t, a) {
      "use strict";
  
      var n;
      var s;
      var l;
      var r = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return r.createElement("svg", _extends({
          width: 25.5,
          height: 24,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= r.createElement("rect", {
          x: 8,
          y: 3.6,
          width: 9.6,
          height: 15.6,
          rx: 1.2
        }), s ||= r.createElement("rect", {
          x: 20.5,
          y: 7.2,
          width: 4.8,
          height: 8.4,
          rx: 1.2
        }), l ||= r.createElement("rect", {
          y: 7.2,
          width: 4.8,
          height: 8.4,
          rx: 1.2
        }));
      };
    },
    77486: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 24,
          height: 25,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M4 6.017 6.037 9.26v8.637c-.013.1-.121.347-.453.528-.332.18-.943.528-1.207.678-.126.076-.377.34-.377.792v1.735c.025.226.226.679.83.679H18.82c.226-.05.679-.256.679-.679v-1.923a1.07 1.07 0 0 0-.377-.566c-.242-.18-.98-.578-1.32-.754-.138-.076-.415-.355-.415-.867V9.336l2.074-3.432v-2.3A.751.751 0 0 0 18.708 3h-1.999c-.188.05-.565.241-.565.603v1.245c-.013.1-.091.302-.302.302h-1.924c-.113-.013-.339-.09-.339-.302v-1.32A.624.624 0 0 0 12.938 3h-2.565c-.175 0-.527.12-.527.603v1.245a.357.357 0 0 1-.378.302H7.545c-.088-.013-.264-.106-.264-.377v-1.17c0-.2-.128-.603-.641-.603H4.566A.562.562 0 0 0 4 3.603v2.414Zm6.26 7.92h2.942a.519.519 0 0 0 .415-.528v-2.753c0-.49-.415-1.471-1.735-1.471h-.453c-.515.038-1.546.385-1.546 1.47v2.867c.025.138.136.415.377.415Z"
        }));
      };
    },
    20514: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 12,
          height: 3,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          d: "M6.828.922h4.344A.83.83 0 0 1 12 1.75a.83.83 0 0 1-.828.828H.828A.83.83 0 0 1 0 1.75.83.83 0 0 1 .828.922h6Z",
          fill: "#818EBB"
        }));
      };
    },
    55855: function (e, t, a) {
      "use strict";
  
      var n;
      var s;
      var l = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return l.createElement("svg", _extends({
          width: 24,
          height: 24,
          stroke: "currentColor",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= l.createElement("path", {
          d: "M11.25 4.75 8.75 7l2.5 2.25M12.75 19.25l2.5-2.25-2.5-2.25",
          strokeWidth: 1.5,
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }), s ||= l.createElement("path", {
          d: "M9.75 7h3.5a6 6 0 0 1 6 6v.25M14.25 17h-3.5a6 6 0 0 1-6-6v-.25",
          strokeWidth: 0.5,
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }));
      };
    },
    19681: function (e, t, a) {
      "use strict";
  
      var n;
      var s;
      var l = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return l.createElement("svg", _extends({
          width: 22,
          height: 20,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= l.createElement("path", {
          d: "M5.397 20c-.293 0-.58-.09-.818-.254a1.434 1.434 0 0 1-.468-.571 1.364 1.364 0 0 1-.112-.718l.51-5.469L.851 8.875a1.402 1.402 0 0 1-.325-.654c-.048-.24-.03-.49.052-.722a1.37 1.37 0 0 1 .394-.591c.183-.162.406-.275.648-.33l5.33-1.202L9.748.702c.124-.213.306-.39.526-.514a1.486 1.486 0 0 1 1.452 0c.22.124.402.3.526.514l2.798 4.707 5.33 1.202c.242.055.465.168.648.33.183.161.318.365.394.592.082.232.1.48.052.722-.048.24-.16.466-.325.653l-3.637 4.08.51 5.47c.025.247-.02.496-.127.722a1.439 1.439 0 0 1-.488.566 1.459 1.459 0 0 1-1.399.134l-5.015-2.164-5.008 2.164c-.184.08-.385.121-.588.12Z",
          fill: "url(#star_svg__a)"
        }), s ||= l.createElement("defs", null, l.createElement("linearGradient", {
          id: "star_svg__a",
          x1: 11,
          y1: 0,
          x2: 11,
          y2: 20,
          gradientUnits: "userSpaceOnUse"
        }, l.createElement("stop", {
          stopColor: "#FBD03B"
        }), l.createElement("stop", {
          offset: 1,
          stopColor: "#FD9E12"
        }))));
      };
    },
    56531: function (e, t, a) {
      "use strict";
  
      var n;
      var s = a(67294);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      t.Z = function (e) {
        return s.createElement("svg", _extends({
          width: 12,
          height: 12,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), n ||= s.createElement("path", {
          d: "M9.563 2.2H7.25a1.15 1.15 0 0 0-.384-.849A1.378 1.378 0 0 0 5.938 1h-.875c-.349 0-.682.126-.929.351a1.15 1.15 0 0 0-.384.849H1.437a.46.46 0 0 0-.309.117A.383.383 0 0 0 1 2.6c0 .106.046.208.128.283a.46.46 0 0 0 .31.117h8.124a.46.46 0 0 0 .31-.117A.383.383 0 0 0 10 2.6a.383.383 0 0 0-.128-.283.46.46 0 0 0-.31-.117ZM8.5 4h-6a.617.617 0 0 0-.354.104c-.093.067-.146.158-.146.252v5.576c0 .283.158.555.44.755.28.2.662.313 1.06.313h4c.398 0 .78-.113 1.06-.313.282-.2.44-.472.44-.755V4.356c0-.094-.053-.185-.146-.252A.617.617 0 0 0 8.5 4Z"
        }));
      };
    },
    8310: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        II: function () {
          return loadUser;
        },
        UH: function () {
          return reloadUser;
        },
        Wt: function () {
          return changeWallet;
        },
        ho: function () {
          return loadRace;
        },
        kS: function () {
          return logout;
        }
      });
      var n = a(2181);
      var s = a(74344);
      var l = a(81511);
      var r = a(62961);
      var o = a(71802);
      var i = a(49089);
      var c = a(27243);
      var d = a(25074);
      var u = a(54847);
      var m = a(34793);
      var h = a(94120);
      let loadUser = () => async e => {
        var t = "";
        if (localStorage.getItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN")) {
          (0, l.Z)(localStorage.getItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN"));
          t = localStorage.getItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN");
        }
        try {
          let a = await (0, n.nXh)();
          if (a.user && window.Intercom) {
            console.debug("Loaded intercom!");
            i.ZP.set({
              userId: a.user.robloxId
            });
            window.Intercom("boot", {
              api_base: "https://api-iam.intercom.io",
              app_id: "ze033am6",
              avatar: {
                type: "avatar",
                image_url: "https://api.bloxflip.com/render-headshot?userId=" + a.user.robloxId + "&width=48&height=48&format=png"
              },
              user_id: a.user.robloxId,
              name: a.user.robloxUsername,
              user_hash: a.intercomSignature
            });
          }
          try {
            d.Z.setExternalUserId("user-" + a.user.robloxId, a.oneSignalSignature);
          } catch (e) {}
          try {
            c.Z.identify(a.user.robloxId, {
              totalDeposited: a.user.totalDeposited,
              currentlySupporting: a.user.currentlySupporting,
              special: a.user.rank !== 1
            });
          } catch (e) {}
          (0, s.Z$)(t);
          let l = a.user.robloxUsername;
          if (l) {
            (0, m.dZ)(l);
          }
          e({
            type: r.Cy,
            payload: a
          });
        } catch (t) {
          e({
            type: r.Ny
          });
        }
        let a = new o.SM({
          loadOptions: {
            apiKey: "uimfOL8fOTvQSR4cR0qZ",
            endpoint: ["https://bloxflip.com/XoujFXnPzZqIDd4u/RE0ZM8gUSRNhOUa4", h.wd],
            scriptUrlPattern: ["https://bloxflip.com/XoujFXnPzZqIDd4u/419oOHW3svoxnL5N?apiKey=<apiKey>&version=<version>&loaderVersion=<loaderVersion>", h.gv]
          },
          cacheLocation: "localstorage",
          cacheTimeInSeconds: 86400,
          cachePrefix: "bugsnag_agent"
        });
        a.init().then(() => {
          a.getVisitorData().then(e => {
            try {
              u.Z.dispatch({
                type: "SET_ANALYTICSID2",
                payload: e.visitorId ?? null
              });
            } catch (e) {
              console.log(e);
            }
            window.analyticsId2 = e.visitorId;
            (0, n.ICb)(e.visitorId);
          });
        }).catch(console.error);
      };
      let loadRace = () => async e => {
        try {
          let t = await (0, n.Hvh)();
          e({
            type: r.Sb,
            payload: t
          });
        } catch (e) {
          console.debug(e);
        }
      };
      let reloadUser = () => async e => {
        e({
          type: r.xe
        });
        try {
          let t = await (0, n.nXh)();
          e({
            type: r.Cy,
            payload: t
          });
        } catch (t) {
          e({
            type: r.Ny
          });
        }
      };
      let changeWallet = e => {
        let {
          amount: t
        } = e;
        return async e => {
          e({
            type: r.Uk,
            payload: t
          });
        };
      };
      let logout = () => e => {
        e({
          type: r.Nv
        });
      };
    },
    87116: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        P: function () {
          return getGapWidth;
        }
      });
      let parse = e => parseInt(e || "", 10) || 0;
      let getOffset = e => {
        let t = window.getComputedStyle(document.body);
        let a = t[e === "padding" ? "paddingLeft" : "marginLeft"];
        let n = t[e === "padding" ? "paddingTop" : "marginTop"];
        let s = t[e === "padding" ? "paddingRight" : "marginRight"];
        return [parse(a), parse(n), parse(s)];
      };
      let getGapWidth = function (e = "margin") {
        let t = getOffset(e);
        let a = document.documentElement.clientWidth;
        let n = window.innerWidth;
        return {
          left: t[0],
          top: t[1],
          right: t[2],
          gap: Math.max(0, n - a + t[2] - t[0])
        };
      };
    },
    64325: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return Avatar;
        }
      });
      var n = a(85893);
      a(67294);
      var s = a(93967);
      var l = a.n(s);
      var r = a(22674);
      var o = a.n(r);
      var i = a(89755);
      var c = a.n(i);
      var d = a(2664);
      let u = {
        medium: {
          className: o().avatarMedium,
          imageSize: 32
        },
        large: {
          className: o().avatarLarge,
          imageSize: 40
        },
        extraLarge: {
          className: o().avatarExtraLarge,
          imageSize: 51
        },
        superLarge: {
          className: o().avatarSuperLarge,
          imageSize: 63
        }
      };
      function Avatar(e) {
        let {
          isPrivateMode: t = false,
          className: a,
          userId: s,
          isEmpty: r = false,
          imageAlt: i = "alt",
          boxSize: m = "large",
          userLevel: h = 0,
          disableProfilePopup: p = false,
          ...g
        } = e;
        let f = (0, d.I0)();
        return (0, n.jsxs)("span", {
          className: l()(o().avatar, u[m].className, a),
          style: s && s > 10 ? {
            cursor: "pointer"
          } : {},
          ...g,
          "data-sentry-component": "Avatar",
          "data-sentry-source-file": "avatar.tsx",
          children: [(0, n.jsx)(c(), {
            onClick: () => {
              if (!p && s && s > 10 && !t) {
                f({
                  type: "SHOW_PROFILE_" + s
                });
              }
            },
            src: s === 0 ? "/pics/default-avatar.svg" : r || t ? "/pics/empty.svg" : "https://api.bloxflip.com/render-headshot?userId=" + (s && s > 0 ? s : 1) + "&width=48&height=48&format=png",
            width: u[m].imageSize,
            height: u[m].imageSize,
            unoptimized: true,
            alt: i,
            "data-sentry-element": "Image",
            "data-sentry-source-file": "avatar.tsx"
          }), h > 0 && (0, n.jsx)("span", {
            className: o().avatarLabel,
            children: h
          })]
        });
      }
    },
    1773: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return Case;
        }
      });
      var n = a(85893);
      a(67294);
      var s = a(93967);
      var l = a.n(s);
      var r = a(59801);
      var o = a.n(r);
      var i = a(89755);
      var c = a.n(i);
      var d = a(77579);
      var u = a(791);
      var m = a(64325);
      function Case(e) {
        let {
          children: t,
          className: a,
          previewUrl: s = "/",
          accentColor: r,
          noHover: i = false,
          userId: d = 0,
          itemHolder: u = false,
          disabled: h = false,
          disableOptimizations: p = false,
          ...g
        } = e;
        return (0, n.jsxs)("div", {
          className: l()(o().case, i && o().caseNohover, u && o().caseCardHolder, h && o().isDisabled, a),
          ...g,
          "data-sentry-component": "Case",
          "data-sentry-source-file": "case.tsx",
          children: [(0, n.jsx)("div", {
            className: o().casePreview,
            style: {
              "--shadow": r ? `rgba(${r}, 0.6)` : "rgba(28, 230, 230, 0.6)"
            },
            children: (0, n.jsx)(c(), {
              src: s ?? "",
              width: u ? 111 : 139,
              height: u ? 111 : 139,
              unoptimized: p,
              draggable: false,
              alt: "Slot preview",
              "data-sentry-element": "Image",
              "data-sentry-source-file": "case.tsx"
            })
          }), d > 0 && (0, n.jsx)(m.Z, {
            className: o().caseAvatar,
            userId: d,
            imageAlt: "User avatar",
            boxSize: "medium"
          }), t]
        });
      }
      Case.Title = function (e) {
        let {
          children: t,
          ...a
        } = e;
        return (0, n.jsx)(d.Z, {
          element: "p",
          textType: "regular14",
          className: o().caseTitle,
          ...a,
          "data-sentry-element": "Text",
          "data-sentry-component": "Title",
          "data-sentry-source-file": "case.tsx",
          children: t
        });
      };
      Case.Subtitle = function (e) {
        let {
          children: t,
          ...a
        } = e;
        return (0, n.jsx)(u.Z, {
          element: "h3",
          className: o().caseSubtitle,
          ...a,
          "data-sentry-element": "Heading",
          "data-sentry-component": "Subtitle",
          "data-sentry-source-file": "case.tsx",
          children: t
        });
      };
      Case.Manage = function (e) {
        let {
          children: t,
          ...a
        } = e;
        return (0, n.jsx)("div", {
          className: o().caseManage,
          ...a,
          "data-sentry-component": "Manage",
          "data-sentry-source-file": "case.tsx",
          children: t
        });
      };
      Case.FixedRight = function (e) {
        let {
          children: t,
          ...a
        } = e;
        return (0, n.jsx)("div", {
          className: o().caseFixedRight,
          ...a,
          "data-sentry-component": "FixedRight",
          "data-sentry-source-file": "case.tsx",
          children: t
        });
      };
      Case.Buttons = function (e) {
        let {
          children: t,
          ...a
        } = e;
        return (0, n.jsx)("div", {
          className: o().caseButtons,
          ...a,
          "data-sentry-component": "Buttons",
          "data-sentry-source-file": "case.tsx",
          children: t
        });
      };
      Case.Label = function (e) {
        let {
          children: t,
          ...a
        } = e;
        return (0, n.jsx)(d.Z, {
          element: "p",
          textType: "regular14",
          className: o().caseLabel,
          ...a,
          "data-sentry-element": "Text",
          "data-sentry-component": "Label",
          "data-sentry-source-file": "case.tsx",
          children: t
        });
      };
    },
    791: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return Heading;
        }
      });
      var n = a(85893);
      a(67294);
      var s = a(93967);
      var l = a.n(s);
      var r = a(10937);
      var o = a.n(r);
      let i = {
        h1: o().heading1,
        h2: o().heading2,
        h3: o().heading3,
        h4: o().heading4
      };
      function Heading(e) {
        let {
          children: t,
          element: a = "h1",
          as: s,
          className: r,
          ...c
        } = e;
        let d = s || a || "h1";
        return (0, n.jsx)(d, {
          className: l()(o().heading, i[a], r),
          ...c,
          "data-sentry-element": "Element",
          "data-sentry-component": "Heading",
          "data-sentry-source-file": "heading.tsx",
          children: t
        });
      }
    },
    58733: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return Input;
        }
      });
      var n = a(85893);
      a(67294);
      var s = a(93967);
      var l = a.n(s);
      var r = a(46826);
      var o = a.n(r);
      var i = a(28310);
      var c = a(20514);
      function Input(e) {
        let {
          type: t = "text",
          className: a,
          withIncrementDecrement: s = false,
          onIncrement: r,
          onDecrement: d,
          disableDecrement: u = false,
          hasCurrencyIcon: m = false,
          currencyIconUrl: h = "/currency-icon.svg",
          iconPosition: p = "start",
          ref: g = null,
          ...f
        } = e;
        let x = m ? {
          backgroundImage: `url(${h})`
        } : {};
        return (0, n.jsxs)("div", {
          className: l()(o().inputWrapper, s && o().inputWithButtons),
          "data-sentry-component": "Input",
          "data-sentry-source-file": "input.tsx",
          children: [(0, n.jsx)("input", {
            ref: g,
            className: l()(o().input, m && o()[`inputWithCurrency${p.charAt(0).toUpperCase() + p.slice(1)}`], a),
            type: t,
            style: x,
            ...f
          }), s && (0, n.jsxs)("div", {
            className: o().buttonGroup,
            children: [(0, n.jsx)("button", {
              onClick: d,
              disabled: u,
              className: o().counterButton,
              children: (0, n.jsx)(c.Z, {})
            }), (0, n.jsx)("button", {
              onClick: r,
              className: o().counterButton,
              children: (0, n.jsx)(i.Z, {})
            })]
          })]
        });
      }
    },
    49922: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return Layout;
        }
      });
      var n;
      var s;
      var l;
      var r;
      var o;
      var i;
      var c;
      var d;
      var u;
      var m;
      var h;
      var p;
      var g;
      var f;
      var x;
      var v;
      var _;
      var y;
      var b;
      var w;
      var j;
      var C;
      var T;
      var I;
      var S;
      var M;
      var k;
      var Z;
      var N;
      var A;
      var B;
      var E;
      var P;
      var L;
      var O;
      var R;
      var F;
      var D = a(85893);
      var W = a(67294);
      var H = a(93967);
      var U = a.n(H);
      var G = a(65425);
      var V = a(6428);
      var z = a(44457);
      var q = a.n(z);
      var Y = a(8310);
      var X = a(2664);
      var K = a(86501);
      var J = a(54847);
      var Q = a(89755);
      var $ = a.n(Q);
      var ee = a(41664);
      var et = a.n(ee);
      var ea = a(11163);
      var en = a(39424);
      var es = a(62961);
      var el = a(39398);
      var er = a(40400);
      var eo = a(87185);
      var ei = a(17857);
      var ec = a(29988);
      var ed = a.n(ec);
      var eu = a(77579);
      var em = a(791);
      var eh = a(45697);
      var ep = a.n(eh);
      var eg = a(2181);
      var ef = a(8210);
      var ex = a.n(ef);
      var ev = a(66713);
      var e_ = a(4595);
      var ey = a(83253);
      var eb = a.n(ey);
      var ew = a(64325);
      let formattingFn = e => (0, el.Z)((0, er.Z)(e));
      let ProfileModal = e => {
        let {
          className: t,
          userId: a,
          open: n = false,
          handleClose: s
        } = e;
        let [l, r] = (0, W.useState)(false);
        (0, W.useEffect)(() => {
          if (n) {
            let fetchData = async () => {
              try {
                let e = await (0, eg.qAr)(a);
                r(e);
              } catch (e) {
                K.Am.error("There was an error while fetching the profile information of that user, please try again!");
                s();
              }
            };
            fetchData();
          } else {
            r(false);
          }
        }, [n]);
        return (0, D.jsxs)(eb(), {
          isOpen: n,
          onRequestClose: s,
          contentLabel: "Sign-in modal",
          className: U()(ex().defaultModal, ex().modalProfile, t),
          closeTimeoutMS: 200,
          "data-sentry-element": "Modal",
          "data-sentry-component": "ProfileModal",
          "data-sentry-source-file": "ProfileModal.tsx",
          children: [(0, D.jsxs)("div", {
            className: ex().modalProfileMain,
            children: [(0, D.jsxs)("div", {
              className: ex().modalProfileMainUser,
              children: [(0, D.jsx)("div", {
                className: ex().modalProfileMainUserAvatar,
                children: (0, D.jsx)(ew.Z, {
                  url: "/pics/avatar.png",
                  imageAlt: "User avatar",
                  userLevel: (0, eo.jR)(l.wager),
                  boxSize: "extraLarge",
                  userId: a,
                  "data-sentry-element": "Avatar",
                  "data-sentry-source-file": "ProfileModal.tsx"
                })
              }), (0, D.jsxs)("div", {
                className: ex().modalProfileMainUserText,
                children: [(0, D.jsx)(eu.Z, {
                  element: "p",
                  textType: "smHeadlines",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: l && l.username
                }), (0, D.jsxs)(eu.Z, {
                  element: "p",
                  textType: "regular14",
                  style: {
                    marginTop: "12px"
                  },
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: [(0, D.jsx)("svg", {
                    width: "25",
                    height: "20",
                    viewBox: "0 0 25 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    "data-sentry-element": "svg",
                    "data-sentry-source-file": "ProfileModal.tsx",
                    children: (0, D.jsx)("path", {
                      d: "M22.2186 7.625H17.7658C18.2417 8.72307 18.0328 10.0445 17.1283 10.9396L12.0186 15.9961V17.7188C12.0186 18.7025 12.8244 19.5 13.8186 19.5H22.2186C23.2127 19.5 24.0186 18.7025 24.0186 17.7188V9.40625C24.0186 8.42248 23.2127 7.625 22.2186 7.625ZM18.0186 14.4531C17.5217 14.4531 17.1186 14.0542 17.1186 13.5625C17.1186 13.0704 17.5217 12.6719 18.0186 12.6719C18.5154 12.6719 18.9186 13.0704 18.9186 13.5625C18.9186 14.0542 18.5154 14.4531 18.0186 14.4531ZM16.2797 7.5248L9.71981 1.03326C9.00131 0.322246 7.83618 0.322246 7.11768 1.03326L0.55743 7.5248C-0.16107 8.23582 -0.16107 9.38881 0.55743 10.0998L7.11731 16.5917C7.8358 17.3028 9.00093 17.3028 9.71943 16.5917L16.2797 10.1002C16.9982 9.38881 16.9982 8.23582 16.2797 7.5248ZM3.61855 9.70312C3.12168 9.70312 2.71855 9.3042 2.71855 8.8125C2.71855 8.32043 3.12168 7.92188 3.61855 7.92188C4.11543 7.92188 4.51855 8.32043 4.51855 8.8125C4.51855 9.3042 4.11543 9.70312 3.61855 9.70312ZM8.41856 14.4531C7.92168 14.4531 7.51856 14.0542 7.51856 13.5625C7.51856 13.0704 7.92168 12.6719 8.41856 12.6719C8.91543 12.6719 9.31855 13.0704 9.31855 13.5625C9.31855 14.0542 8.91543 14.4531 8.41856 14.4531ZM8.41856 9.70312C7.92168 9.70312 7.51856 9.3042 7.51856 8.8125C7.51856 8.32043 7.92168 7.92188 8.41856 7.92188C8.91543 7.92188 9.31855 8.32043 9.31855 8.8125C9.31855 9.3042 8.91543 9.70312 8.41856 9.70312ZM8.41856 4.95312C7.92168 4.95312 7.51856 4.5542 7.51856 4.0625C7.51856 3.57043 7.92168 3.17188 8.41856 3.17188C8.91543 3.17188 9.31855 3.57043 9.31855 4.0625C9.31855 4.5542 8.91543 4.95312 8.41856 4.95312ZM13.2186 9.70312C12.7217 9.70312 12.3186 9.3042 12.3186 8.8125C12.3186 8.32043 12.7217 7.92188 13.2186 7.92188C13.7154 7.92188 14.1186 8.32043 14.1186 8.8125C14.1186 9.3042 13.7154 9.70312 13.2186 9.70312Z",
                      fill: "#5F6892",
                      "data-sentry-element": "path",
                      "data-sentry-source-file": "ProfileModal.tsx"
                    })
                  }), l ? l.rank : "Loading..."]
                })]
              })]
            }), (0, D.jsxs)("div", {
              className: ex().modalProfileMainStats,
              children: [(0, D.jsxs)("div", {
                className: ex().modalProfileMainStatsBlock,
                children: [(0, D.jsx)(eu.Z, {
                  element: "p",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: "Games played"
                }), (0, D.jsxs)(em.Z, {
                  element: "h1",
                  "data-sentry-element": "Heading",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: [l && (0, D.jsx)(ei.ZP, {
                    duration: 0.4,
                    formattingFn: formattingFn,
                    end: l.gamesPlayed
                  }), (0, D.jsx)(ev.Z, {
                    "data-sentry-element": "CurrencyIcon",
                    "data-sentry-source-file": "ProfileModal.tsx"
                  })]
                })]
              }), (0, D.jsxs)("div", {
                className: ex().modalProfileMainStatsBlock,
                children: [(0, D.jsx)(eu.Z, {
                  element: "p",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: "Wagered"
                }), (0, D.jsxs)(em.Z, {
                  element: "h1",
                  "data-sentry-element": "Heading",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: [l && (0, D.jsx)(ei.ZP, {
                    duration: 0.4,
                    formattingFn: formattingFn,
                    end: l.wager
                  }), (0, D.jsx)(ev.Z, {
                    "data-sentry-element": "CurrencyIcon",
                    "data-sentry-source-file": "ProfileModal.tsx"
                  })]
                })]
              }), (0, D.jsxs)("div", {
                className: ex().modalProfileMainStatsBlock,
                children: [(0, D.jsx)(eu.Z, {
                  element: "p",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: "Rain winnings"
                }), (0, D.jsxs)(em.Z, {
                  element: "h1",
                  "data-sentry-element": "Heading",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: [l && (0, D.jsx)(ei.ZP, {
                    duration: 0.4,
                    formattingFn: formattingFn,
                    end: l.rainWinnings
                  }), " ", (0, D.jsx)(ev.Z, {
                    "data-sentry-element": "CurrencyIcon",
                    "data-sentry-source-file": "ProfileModal.tsx"
                  })]
                })]
              }), (0, D.jsxs)("div", {
                className: ex().modalProfileMainStatsBlock,
                children: [(0, D.jsx)(eu.Z, {
                  element: "p",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: "Trivia Winnings"
                }), (0, D.jsxs)(em.Z, {
                  element: "h1",
                  "data-sentry-element": "Heading",
                  "data-sentry-source-file": "ProfileModal.tsx",
                  children: [l && (0, D.jsx)(ei.ZP, {
                    duration: 0.4,
                    formattingFn: formattingFn,
                    end: l.triviaWinnings
                  }), (0, D.jsx)(ev.Z, {
                    "data-sentry-element": "CurrencyIcon",
                    "data-sentry-source-file": "ProfileModal.tsx"
                  })]
                })]
              })]
            })]
          }), (0, D.jsx)("div", {
            className: ex().modalProfileChart
          }), (0, D.jsx)(e_.Z, {
            onClick: s,
            className: ex().defaultModalClose,
            "aria-label": "Close",
            "data-sentry-element": "Button",
            "data-sentry-source-file": "ProfileModal.tsx"
          })]
        });
      };
      ProfileModal.propTypes = {
        handleClose: ep().func.isRequired,
        userId: ep().any,
        open: ep().bool
      };
      var ej = (0, X.$j)(() => ({}), {})(ProfileModal);
      var eC = a(38279);
      var eT = a.n(eC);
      let eI = {
        inputStyle: {
          fontFamily: "Titillium Web",
          margin: "4px",
          MozAppearance: "textfield",
          width: "40px",
          borderRadius: "3px",
          fontSize: "14px",
          height: "40px",
          paddingLeft: "7px",
          backgroundColor: "#282e54",
          color: "#818ebb",
          textAlign: "center",
          border: "0px solid lightskyblue"
        }
      };
      var eS = (0, X.$j)(e => ({
        showTwoFactor: e.auth.showTwoFactor
      }))(e => {
        let {
          className: t,
          open: a,
          handleClose: n,
          login: s
        } = e;
        let [l, r] = (0, W.useState)(0);
        let [o, i] = (0, W.useState)(true);
        let [c, d] = (0, W.useState)(0);
        let [u, m] = (0, W.useState)("");
        let [h, p] = (0, W.useState)("");
        let g = (0, X.I0)();
        let [f, x] = (0, W.useState)(1);
        (0, W.useEffect)(() => {
          if (h.length === 0) {
            x(e => e + 1);
            return;
          }
        }, [h]);
        let resetProccess = () => {
          r(0);
          m("");
          p("");
          r(0);
          i(false);
        };
        let onClick = async () => {
          try {
            i(true);
            let e = await (0, eg.N4q)(u, c, h);
            i(false);
            if (e.success) {
              K.Am.success(e.msg);
              n();
            } else {
              n();
              K.Am.error(e.msg);
            }
          } catch (e) {
            if (e.response && e.response.status === 400) {
              K.Am.error(e.response.data.error);
            } else {
              K.Am.error("There was an error while completing the 2fa challenge. Please try again!");
            }
          }
        };
        (0, W.useEffect)(() => {
          let fetchData = async () => {
            try {
              i(true);
              let e = await (0, eg.zXi)();
              i(false);
              if (e.promptLogin) {
                n();
                K.Am.error(e.error);
                g({
                  type: es.gr
                });
                return;
              }
              if (e.success) {
                d(e.challengeId);
                m(e.challengeType);
                r(1);
              }
            } catch (e) {
              if (e.response && e.response.status === 400) {
                K.Am.error(e.response.data.error);
              } else {
                K.Am.error("There was an error while generating the 2fa challenge. Please try again!");
              }
            }
          };
          if (a) {
            resetProccess();
            fetchData();
          }
        }, [a]);
        return (0, D.jsxs)(eb(), {
          isOpen: a,
          onRequestClose: n,
          contentLabel: "Sign-in modal",
          className: U()(ex().defaultModal, t),
          closeTimeoutMS: 200,
          "data-sentry-element": "Modal",
          "data-sentry-component": "TradingSecondFactorModal",
          "data-sentry-source-file": "TradingSecondFactorModal.tsx",
          children: [(0, D.jsxs)("div", {
            className: ex().modalAuthContent,
            children: [(0, D.jsx)(em.Z, {
              element: "h2",
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "TradingSecondFactorModal.tsx",
              children: "Trading Two Factor"
            }), (0, D.jsx)(eu.Z, {
              style: {
                marginTop: "1rem"
              },
              className: ex().modalAuthText,
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "TradingSecondFactorModal.tsx",
              children: "For security reasons, we require all users to have two factor authentication enabled when trading"
            }), l === 1 && (0, D.jsx)(D.Fragment, {
              children: (0, D.jsxs)("div", {
                className: U()("customInput", ex().modalAuthCustomInput),
                children: [(0, D.jsxs)(eu.Z, {
                  className: ex().modalAuthText,
                  element: "p",
                  textType: "regular14",
                  children: [(0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "To proceed, please", " ", u === "Email" ? " input the secondary authentication code that you received in your Email" : "input the secondary authenticator code from your Authenticator app"]
                }), (0, D.jsx)("div", {
                  className: U()("customInputInner"),
                  style: {
                    textAlign: "center",
                    marginTop: "2rem"
                  },
                  children: (0, D.jsx)(eT(), {
                    value: h,
                    type: "number",
                    fields: 6,
                    onChange: e => {
                      p(e);
                    },
                    inputMode: "numeric",
                    name: "roblox-2fa",
                    ...eI
                  }, f)
                })]
              })
            }), (0, D.jsx)(e_.Z, {
              onClick: onClick,
              disabled: o || h.length != 6,
              className: ex().modalAuthSubmit,
              variant: "primary",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "TradingSecondFactorModal.tsx",
              children: o ? "Please wait..." : h.length != 6 ? "Waiting for code input..." : "Continue"
            })]
          }), (0, D.jsx)(e_.Z, {
            onClick: n,
            className: ex().defaultModalClose,
            "aria-label": "Close",
            "data-sentry-element": "Button",
            "data-sentry-source-file": "TradingSecondFactorModal.tsx"
          })]
        });
      });
      var eM = a(58733);
      function _extends() {
        return (_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function hashtag(e) {
        return W.createElement("svg", _extends({
          xmlns: "http://www.w3.org/2000/svg",
          width: 13,
          height: 17,
          viewBox: "0 0 32 32",
          style: {
            enableBackground: "new 0 0 512 512"
          },
          xmlSpace: "preserve"
        }, e), n ||= W.createElement("path", {
          d: "M2.439 19.912A1.94 1.94 0 0 0 .5 21.849a1.94 1.94 0 0 0 1.938 1.938h2.837L3.95 29.092a1.923 1.923 0 0 0 .218 1.467 1.939 1.939 0 0 0 1.662.941c.89 0 1.662-.604 1.878-1.468l1.561-6.245h9.569l-1.327 5.305a1.923 1.923 0 0 0 .218 1.467 1.938 1.938 0 0 0 1.662.941c.89 0 1.663-.604 1.878-1.468l1.562-6.245h6.73a1.94 1.94 0 0 0 1.938-1.938 1.94 1.94 0 0 0-1.938-1.937H23.8l1.955-7.822h3.806c1.069 0 1.938-.87 1.938-1.938s-.87-1.937-1.938-1.937h-2.837L28.05 2.91a1.923 1.923 0 0 0-.218-1.467 1.922 1.922 0 0 0-1.19-.883 1.915 1.915 0 0 0-1.465.214c-.445.266-.76.691-.885 1.196L22.73 8.215h-9.569L14.49 2.91a1.923 1.923 0 0 0-.218-1.467A1.922 1.922 0 0 0 13.08.56a1.927 1.927 0 0 0-2.35 1.41L9.169 8.215H2.44C1.37 8.215.5 9.084.5 10.152s.87 1.938 1.938 1.938H8.2l-1.955 7.822zm9.755-7.822h9.568l-1.956 7.822h-9.568z",
          fill: "#818ebb",
          "data-original": "#000000",
          xmlns: "http://www.w3.org/2000/svg"
        }));
      }
      var ek = (0, X.$j)(e => ({
        showProvablyConfig: e.auth.showProvablyConfig
      }))(e => {
        let {
          className: t,
          open: a,
          handleClose: n,
          login: s
        } = e;
        let [l, r] = (0, W.useState)(0);
        let [o, i] = (0, W.useState)(true);
        let [c, d] = (0, W.useState)("Fetching...");
        let [u, m] = (0, W.useState)("Fetching...");
        let [h, p] = (0, W.useState)("Fetching...");
        (0, X.I0)();
        let onClick = async () => {
          try {
            i(true);
            let e = await (0, eg.sIj)(c);
            i(false);
            if (e.success) {
              K.Am.success("Your client seed has been updated!");
            } else {
              n();
              K.Am.error(e.msg);
            }
          } catch (e) {
            n();
            if (e.response && e.response.status === 400) {
              K.Am.error(e.response.data.error);
            } else {
              K.Am.error("There was an error while fetching the provably fair data. Please try again!");
            }
          }
        };
        (0, W.useEffect)(() => {
          let fetchData = async () => {
            try {
              i(true);
              let e = await (0, eg.lrf)();
              i(false);
              d(e.clientSeed);
              m(e.serverHash);
              p(e.nonce);
            } catch (e) {
              n();
              if (e.response && e.response.status === 400) {
                K.Am.error(e.response.data.error);
              } else {
                K.Am.error("There was an error while fetching the provably fair data. Please try again!");
              }
            }
          };
          if (a) {
            fetchData();
          }
        }, [a]);
        return (0, D.jsxs)(eb(), {
          isOpen: a,
          onRequestClose: n,
          contentLabel: "Sign-in modal",
          className: U()(ex().defaultModal, t),
          closeTimeoutMS: 200,
          "data-sentry-element": "Modal",
          "data-sentry-component": "ProvablyConfigurationModal",
          "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
          children: [(0, D.jsxs)("div", {
            className: ex().modalAuthContent,
            children: [(0, D.jsx)(em.Z, {
              element: "h2",
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
              children: "Provably Fair"
            }), (0, D.jsx)(eu.Z, {
              style: {
                marginTop: "1rem"
              },
              className: ex().modalAuthText,
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
              children: "From here you can edit your client seed and see the server hash and the nonce of the next provably fair game"
            }), (0, D.jsxs)("div", {
              className: U()("customInput", ex().modalAuthCustomInput),
              children: [(0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                className: U()("customInputLabel"),
                "data-sentry-element": "Text",
                "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
                children: "Client seed"
              }), (0, D.jsxs)("div", {
                className: U()("customInputInner"),
                children: [(0, D.jsx)("div", {
                  className: U()("customInputIcon"),
                  children: (0, D.jsx)(hashtag, {
                    "data-sentry-element": "InpHashtag",
                    "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
                  })
                }), (0, D.jsx)(eM.Z, {
                  value: c,
                  onChange: e => d(e.currentTarget.value),
                  placeholder: "Your client seed here",
                  style: {
                    paddingLeft: 39
                  },
                  "data-sentry-element": "Input",
                  "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
                })]
              })]
            }), (0, D.jsxs)("div", {
              className: U()("customInput", ex().modalAuthCustomInput),
              children: [(0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                className: U()("customInputLabel"),
                "data-sentry-element": "Text",
                "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
                children: "Next server seed (hashed)"
              }), (0, D.jsxs)("div", {
                className: U()("customInputInner"),
                children: [(0, D.jsx)("div", {
                  className: U()("customInputIcon"),
                  children: (0, D.jsx)(hashtag, {
                    "data-sentry-element": "InpHashtag",
                    "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
                  })
                }), (0, D.jsx)(eM.Z, {
                  value: u,
                  disabled: true,
                  style: {
                    paddingLeft: 39
                  },
                  "data-sentry-element": "Input",
                  "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
                })]
              })]
            }), (0, D.jsxs)("div", {
              className: U()("customInput", ex().modalAuthCustomInput),
              children: [(0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                className: U()("customInputLabel"),
                "data-sentry-element": "Text",
                "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
                children: "Next nonce"
              }), (0, D.jsxs)("div", {
                className: U()("customInputInner"),
                children: [(0, D.jsx)("div", {
                  className: U()("customInputIcon"),
                  children: (0, D.jsx)(hashtag, {
                    "data-sentry-element": "InpHashtag",
                    "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
                  })
                }), (0, D.jsx)(eM.Z, {
                  value: h,
                  disabled: true,
                  style: {
                    paddingLeft: 39
                  },
                  "data-sentry-element": "Input",
                  "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
                })]
              })]
            }), (0, D.jsx)(e_.Z, {
              onClick: onClick,
              disabled: o,
              className: ex().modalAuthSubmit,
              variant: "primary",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "ProvablyConfigurationModal.tsx",
              children: o ? "Please wait..." : "Save"
            })]
          }), (0, D.jsx)(e_.Z, {
            onClick: n,
            className: ex().defaultModalClose,
            "aria-label": "Close",
            "data-sentry-element": "Button",
            "data-sentry-source-file": "ProvablyConfigurationModal.tsx"
          })]
        });
      });
      function plus_extends() {
        return (plus_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function plus(e) {
        return W.createElement("svg", plus_extends({
          viewBox: "0 0 12 12",
          xmlns: "http://www.w3.org/2000/svg",
          fill: "currentColor"
        }, e), s ||= W.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M6.714 1a.714.714 0 0 0-1.428 0v4.286H1a.714.714 0 1 0 0 1.428h4.286V11a.714.714 0 1 0 1.428 0V6.714H11a.714.714 0 1 0 0-1.428H6.714V1Z"
        }), l ||= W.createElement("path", {
          d: "M5.286 5.286v.25h.25v-.25h-.25ZM.286 6h.25-.25Zm5 .714h.25v-.25h-.25v.25Zm1.428 0v-.25h-.25v.25h.25ZM11 5.286v.25-.25Zm-4.286 0h-.25v.25h.25v-.25ZM6 .536c.256 0 .464.208.464.464h.5A.964.964 0 0 0 6 .036v.5ZM5.536 1c0-.256.208-.464.464-.464v-.5A.964.964 0 0 0 5.036 1h.5Zm0 4.286V1h-.5v4.286h.5ZM1 5.536h4.286v-.5H1v.5ZM.536 6c0-.256.208-.464.464-.464v-.5A.964.964 0 0 0 .036 6h.5ZM1 6.464A.464.464 0 0 1 .536 6h-.5c0 .533.431.964.964.964v-.5Zm4.286 0H1v.5h4.286v-.5ZM5.536 11V6.714h-.5V11h.5Zm.464.464A.464.464 0 0 1 5.536 11h-.5c0 .533.431.964.964.964v-.5ZM6.464 11a.464.464 0 0 1-.464.464v.5A.964.964 0 0 0 6.964 11h-.5Zm0-4.286V11h.5V6.714h-.5ZM11 6.464H6.714v.5H11v-.5ZM11.464 6a.464.464 0 0 1-.464.464v.5A.964.964 0 0 0 11.964 6h-.5ZM11 5.536c.256 0 .464.208.464.464h.5A.964.964 0 0 0 11 5.036v.5Zm-4.286 0H11v-.5H6.714v.5ZM6.464 1v4.286h.5V1h-.5Z"
        }));
      }
      function log_out_extends() {
        return (log_out_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function log_out(e) {
        return W.createElement("svg", log_out_extends({
          width: 20,
          height: 18,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), r ||= W.createElement("path", {
          d: "M13 1h4c.53 0 1.04.187 1.414.52.375.334.586.786.586 1.258v12.444c0 .472-.21.924-.586 1.257-.375.334-.884.521-1.414.521h-4M9 13l4-4-4-4M13 9H1",
          stroke: "#3656FF",
          strokeWidth: 2,
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }));
      }
      var eZ = a(81511);
      var eN = a(28230);
      var eA = a(25675);
      var eB = a.n(eA);
      function user_extends() {
        return (user_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function input_icons_user(e) {
        return W.createElement("svg", user_extends({
          width: 13,
          height: 14,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), o ||= W.createElement("path", {
          d: "M6.489 6.57C3.033 6.576.173 9.313 0 12.77a.724.724 0 0 0 .727.759h11.55a.724.724 0 0 0 .721-.758C12.826 9.308 9.961 6.57 6.5 6.57h-.011Z",
          fill: "#818EBB"
        }), i ||= W.createElement("path", {
          d: "M6.5 0a3.338 3.338 0 0 0-3.325 3.335c0 1.834 1.493 3.34 3.325 3.34s3.331-1.506 3.331-3.34A3.343 3.343 0 0 0 6.501 0Z",
          fill: "#818EBB"
        }));
      }
      function lock_extends() {
        return (lock_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function lock(e) {
        return W.createElement("svg", lock_extends({
          width: 13,
          height: 17,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), c ||= W.createElement("path", {
          d: "M10.833 7.438V4.25C10.833 1.907 8.89 0 6.5 0S2.167 1.907 2.167 4.25v3.188C.97 7.438 0 8.389 0 9.562v5.313C0 16.049.97 17 2.167 17h8.666C12.03 17 13 16.049 13 14.875V9.562c0-1.173-.97-2.124-2.167-2.124Zm-3.791 5.149v1.757a.536.536 0 0 1-.542.53.536.536 0 0 1-.542-.53v-1.757c-.318-.185-.541-.51-.541-.9 0-.587.485-1.062 1.083-1.062s1.083.475 1.083 1.063c0 .388-.224.714-.541.899Zm1.625-5.15H4.333V4.25c0-1.172.972-2.125 2.167-2.125 1.194 0 2.167.953 2.167 2.125v3.188Z",
          fill: "#818EBB"
        }));
      }
      function cookie_extends() {
        return (cookie_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function cookie(e) {
        return W.createElement("svg", cookie_extends({
          width: 17,
          height: 17,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), d ||= W.createElement("path", {
          d: "M8.5 0A8.5 8.5 0 1 0 17 8.5c0-.472-.038-.944-.123-1.417-.255-.472-.821-.472-.821-.472h-1.89v-.944c0-.945-.944-.945-.944-.945h-1.889v-.944c0-.945-.944-.945-.944-.945h-.945V.944C9.444 0 8.5 0 8.5 0ZM6.139 2.833a1.417 1.417 0 1 1 0 2.834 1.417 1.417 0 0 1 0-2.834ZM3.306 6.611a1.417 1.417 0 1 1 0 2.833 1.417 1.417 0 0 1 0-2.833Zm4.722.945a1.417 1.417 0 1 1 0 2.833 1.417 1.417 0 0 1 0-2.833Zm4.722 1.888a1.416 1.416 0 1 1 0 2.833 1.416 1.416 0 0 1 0-2.833Zm-5.194 2.834a1.417 1.417 0 1 1 0 2.833 1.417 1.417 0 0 1 0-2.833Z",
          fill: "#818EBB"
        }));
      }
      var eE = a(37897);
      var eP = a.n(eE);
      var eL = a(12950);
      var eO = a.n(eL);
      var eR = a(72064);
      var eF = a(33722);
      function checkmark_extends() {
        return (checkmark_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function checkmark(e) {
        return W.createElement("svg", checkmark_extends({
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "80 112 352 288"
        }, e), W.createElement("path", {
          style: {
            fill: "none",
            stroke: "#000",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 32
          },
          d: "M416 128 192 384l-96-96"
        }));
      }
      var eD = a(32612);
      let ArkoseSolver = e => {
        let {
          className: a,
          captcha: n,
          handleCaptcha: s,
          loading: l
        } = e;
        let [r, o] = (0, W.useState)(0);
        let [i, c] = (0, W.useState)(200);
        let [d, u] = (0, W.useState)("");
        let [m, h] = (0, W.useState)(null);
        let lImage = e => new Promise(t => {
          let a = new Image();
          a.onload = () => t({
            width: a.width,
            height: a.height
          });
          a.src = e;
        });
        (0, W.useEffect)(() => {
          if (n) {
            var e;
            (e = n == null ? undefined : n.captchaBase64Image, fetch(`data:image/jpeg;base64,${e}`).then(e => e.blob())).then(e => {
              let t = URL.createObjectURL(e);
              u(t);
              lImage(t).then(e => {
                let {
                  width: t,
                  height: a
                } = e;
                h({
                  width: t,
                  height: a
                });
              });
            });
          }
        }, [n]);
        return (m && (0, D.jsxs)("div", {
          className: U()(eO().container, a),
          children: [(0, D.jsx)("div", {
            className: eO().direction,
            style: {
              backgroundImage: `url(${d})`
            }
          }), (0, D.jsx)("div", {
            className: eO().content,
            style: {
              backgroundImage: `url(${d})`,
              backgroundPosition: `-${r * i}px 0px`
            }
          }), (0, D.jsx)("div", {
            className: eO().controler,
            children: (0, D.jsxs)("div", {
              className: eO().headbuttons,
              children: [(0, D.jsx)(e_.Z, {
                disabled: l,
                onClick: e => {
                  e.preventDefault();
                  o(e => e >= Math.round(m.width / 200) - 1 ? 0 : Math.min(e + 1, Math.round(m.width / 200) - 1));
                },
                children: (0, D.jsx)(eF.Z, {})
              }), (0, D.jsx)(e_.Z, {
                disabled: l,
                onClick: e => {
                  e.preventDefault();
                  o(e => e <= 0 ? Math.round(m.width / 200) - 1 : e - 1);
                },
                children: (0, D.jsx)(eR.Z, {})
              }), (0, D.jsx)(e_.Z, {
                disabled: l,
                onClick: e => {
                  e.preventDefault();
                  s(Math.max(0, Math.round(r + i / i) - 1));
                },
                children: l ? (0, D.jsx)(eD.Z, {
                  radius: 20
                }) : (0, D.jsx)(checkmark, {})
              })]
            })
          })]
        })) ?? null;
      };
      let handleError = function (e, t = "") {
        if (typeof e == "object" && Object.keys(e).length && ("message" in e && e.message && (t = e.message), "response" in e)) {
          var n;
          var l;
          let i = ((n = e.response) === null || n === undefined ? undefined : n.data?.msg) ?? ((l = e.response) === null || l === undefined ? undefined : l.data?.message) ?? null;
          if (i) {
            t = i;
          }
        }
        return t || null;
      };
      let InstantLogin = e => {
        var s;
        let {
          onLogin: i,
          handleClose: c,
          username: d
        } = e;
        let {
          fflags: u
        } = (0, X.v9)(e => e.auth);
        let [m, h] = (0, W.useState)(0);
        let [p, g] = (0, W.useState)(null);
        let [f, x] = (0, W.useState)(false);
        let [v, _] = (0, W.useState)(d ?? "");
        let [y, b] = (0, W.useState)("");
        let [w, j] = (0, W.useState)(1);
        let [C, T] = (0, W.useState)({
          challengeCode: ""
        });
        (0, W.useEffect)(() => {
          if ((C == null ? undefined : C.challengeCode.length) === 0) {
            j(e => e + 1);
            return;
          }
          if ((C == null ? undefined : C.challengeCode) && (C == null ? undefined : C.challengeCode.length) === 6) {
            handle2FA(C == null ? undefined : C.challengeCode);
          }
        }, [C == null ? undefined : C.challengeCode]);
        let handleInitLogin = async e => {
          x(true);
          try {
            e.preventDefault();
            if (!v || !y) {
              return K.Am.error("Please fill in all fields");
            }
            let t = await (0, eg.Sv1)(v, y, window.ga4ClientId);
            if (t.data) {
              let e = t.data;
              if ((e == null ? undefined : e.isNewUser) && (u == null ? undefined : u.fe_affiliate_signup_discount)) {
                try {
                  let e = await (0, eg.t9F)();
                  if (e) {
                    K.Am.success("You received a 10% discount!");
                  }
                } catch (e) {
                  console.log(e);
                }
              }
              if (e == null ? undefined : e.jwt) {
                i({
                  token: e.jwt
                });
                x(false);
                c();
              } else if ("instanceId" in e && "sessionId" in e) {
                g(e);
                if ("has2Fa" in e && (e == null ? undefined : e.has2Fa) && !e.captcha) {
                  h(2);
                } else {
                  h(1);
                }
                x(false);
              } else {
                throw Error("Error occured while trying to login, please try again later");
              }
            } else {
              throw Error("Invalid response, no instanceId or sessionId was provided");
            }
          } catch (n) {
            var a;
            console.log(n);
            let e = n == null ? undefined : (a = n.response) === null || a === undefined ? undefined : a.data?.msg;
            K.Am.error(e || "An error occured, check console for more info");
          }
          x(false);
        };
        let handleCaptcha = async e => {
          var l;
          x(true);
          try {
            if (!p) {
              throw Error("No request details was found");
            }
            if (typeof e != "number") {
              throw Error("Captcha - Please choose the correct item");
            }
            let s = await (0, eg.sxD)(p.instanceId, p.sessionId, window.ga4ClientId, e);
            if (s.data && "jwt" in s.data && s.data.jwt) {
              i({
                token: s.data.jwt
              });
              x(false);
              c();
            } else if (s.data && !s.data.jwt) {
              if (s.data?.has2Fa && !s.data?.captcha) {
                g(Object.assign({}, p ?? {}, s.data));
                h(2);
              } else if (s.data?.captcha) {
                g(Object.assign({}, p ?? {}, {
                  captcha: s.data.captcha
                }));
              }
              x(false);
            } else {
              throw Error("Error occured while trying to login, please try again later");
            }
          } catch (t) {
            console.log(t);
            let e = t == null ? undefined : (l = t.response) === null || l === undefined ? undefined : l.data?.msg;
            K.Am.error(e || "An error occured, check console for more info");
          }
          x(false);
        };
        let resetProccess = () => {
          h(0);
          g(null);
          _("");
          b("");
        };
        let handle2FA = async e => {
          if (e) {
            try {
              x(true);
              let a = await (0, eg.Qy1)(p == null ? undefined : p.instanceId, p == null ? undefined : p.sessionId, window.ga4ClientId, e);
              x(false);
              if (a.success && (a == null ? undefined : a.jwt)) {
                K.Am.success((a == null ? undefined : a.msg) ?? "Redirecting..");
                i({
                  token: a.jwt
                });
                resetProccess();
                c();
              } else {
                K.Am.error("Can't handle 2FA for now, please try again");
                resetProccess();
              }
            } catch (e) {
              x(false);
              console.log(e);
              K.Am.error(handleError(e, "Failed to validate 2FA code"));
            }
          }
        };
        return (0, D.jsxs)("div", {
          className: eP().container,
          "data-sentry-component": "InstantLogin",
          "data-sentry-source-file": "index.tsx",
          children: [m === 0 && (0, D.jsxs)(D.Fragment, {
            children: [(0, D.jsxs)("div", {
              className: U()("customInput", eP().modalAuthCustomInput),
              children: [(0, D.jsxs)(eu.Z, {
                className: ex().modalAuthText,
                element: "p",
                textType: "regular14",
                style: {
                  marginBottom: "2rem"
                },
                children: ["In order for Nflip to operate correctly, we require access to your Roblox account.", (0, D.jsx)("br", {}), " ", (0, D.jsx)("br", {}), "While normally asking for such would be considered malicious, we assure you that Nflip not only will protect your security but never use it without your permission! We will never store your password on our systems, it's only used to fetch the security cookie of your Roblox account!", (0, D.jsx)("br", {}), (0, D.jsx)("br", {})]
              }), (0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                className: U()("customInputLabel"),
                children: "In game username"
              }), (0, D.jsxs)("div", {
                className: U()("customInputInner"),
                children: [(0, D.jsx)("div", {
                  className: U()("customInputIcon"),
                  children: (0, D.jsx)(input_icons_user, {})
                }), (0, D.jsx)(eM.Z, {
                  value: v,
                  onChange: e => _(e.currentTarget.value),
                  placeholder: "Your in game username here",
                  style: {
                    paddingLeft: 39
                  },
                  disabled: f
                })]
              })]
            }), (0, D.jsx)("br", {}), (0, D.jsxs)("div", {
              className: U()("customInput", eP().modalAuthCustomInput),
              children: [(0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                className: U()("customInputLabel"),
                children: "Password"
              }), (0, D.jsxs)("div", {
                className: U()("customInputInner"),
                children: [(0, D.jsx)("div", {
                  className: U()("customInputIcon"),
                  children: (0, D.jsx)(lock, {})
                }), (0, D.jsx)(eM.Z, {
                  type: "password",
                  value: y,
                  onChange: e => b(e.currentTarget.value),
                  placeholder: "Your password here",
                  style: {
                    paddingLeft: 39
                  },
                  disabled: f
                })]
              })]
            }), (0, D.jsx)(e_.Z, {
              type: "submit",
              className: ex().modalAuthSubmit,
              variant: "primary",
              disabled: f,
              onClick: handleInitLogin,
              children: f ? (0, D.jsx)(eD.Z, {
                radius: 20
              }) : "Sign in"
            })]
          }), m === 1 && (0, D.jsxs)(D.Fragment, {
            children: [(p == null ? undefined : p.captcha?.prompt) && (0, D.jsx)(D.Fragment, {
              children: (0, D.jsx)(eu.Z, {
                element: "p",
                textType: "regular14",
                style: {
                  textAlign: "center"
                },
                children: (p == null ? undefined : p.captcha?.prompt) ?? ""
              })
            }), (0, D.jsx)("br", {}), (0, D.jsx)(ArkoseSolver, {
              captcha: p == null ? undefined : p.captcha,
              handleCaptcha: handleCaptcha,
              loading: f
            }), (0, D.jsx)("br", {}), (0, D.jsx)("div", {
              className: eP().dotsSteps,
              children: Array((p == null ? undefined : p.captcha?.totalSteps) ?? 0).fill(0).map((e, t) => {
                return (0, D.jsx)("div", {
                  title: ((p == null ? undefined : p.captcha?.currentStep) ?? 0) >= t + 1 ? "In progress or validated" : "",
                  className: U()(eP().dot, ((p == null ? undefined : p.captcha?.currentStep) ?? 0) >= t + 1 ? eP().active : null)
                }, t);
              })
            })]
          }), m === 2 && (0, D.jsx)(D.Fragment, {
            children: (0, D.jsxs)("div", {
              className: U()("customInput", ex().modalAuthCustomInput),
              children: [(0, D.jsxs)(eu.Z, {
                className: ex().modalAuthText,
                element: "p",
                textType: "regular14",
                style: {
                  marginTop: "1rem"
                },
                children: ["It seems that you have two factor authentication enabled for your Roblox account.", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "To proceed, please input the secondary authentication code that", (p == null ? undefined : p.challengeType) ? (p == null ? undefined : (s = p.challengeType) === null || s === undefined ? undefined : s.toLowerCase().indexOf("email")) >= 0 ? " you received in your Email" : " on your Authenticator App" : " you received on your email or get it from your Authenticator App", "."]
              }), (0, D.jsx)("div", {
                className: U()("customInputInner"),
                style: {
                  textAlign: "center",
                  marginTop: "2rem"
                },
                children: f ? (0, D.jsx)(eD.Z, {
                  radius: 20,
                  isBlue: true,
                  centered: true
                }) : (0, D.jsx)(eT(), {
                  value: (C == null ? undefined : C.challengeCode) ?? "",
                  type: "number",
                  disabled: f,
                  fields: 6,
                  onChange: e => {
                    T({
                      challengeCode: e
                    });
                  },
                  inputMode: "numeric",
                  name: "roblox-2fa",
                  ...eG
                }, w)
              })]
            })
          })]
        });
      };
      var eW = a(49089);
      var eH = a(83198);
      var eU = a(34793);
      a(82129);
      let AgeCheckModal = e => {
        let {
          modalIsOpen: t,
          closeModal: a,
          userAge: n,
          username: s
        } = e;
        let [l, r] = (0, W.useState)([4, Date.now()]);
        let handleAge = () => {
          if (n < 18) {
            K.Am.error("You must be 18+ to use Nflip!");
          } else {
            (0, eU.dZ)(s);
            eH.Z.track("registeration_birthday_failed");
            a(2);
          }
        };
        (0, W.useEffect)(() => {
          if (t) {
            let e = setInterval(() => {
              if (l[0] <= 0) {
                clearInterval(e);
              } else if (Date.now() - l[1] > 1000) {
                r([l[0] - 1, Date.now()]);
              }
            }, 10);
            return () => e && clearInterval(e);
          }
        }, [t, l]);
        return (0, D.jsxs)(eb(), {
          isOpen: t,
          onRequestClose: () => a(),
          className: U()(ex().defaultModal, ex().ageCheckModal),
          "data-sentry-element": "Modal",
          "data-sentry-component": "AgeCheckModal",
          "data-sentry-source-file": "age-check.tsx",
          children: [(0, D.jsx)("h3", {
            children: "Is this your age?"
          }), (0, D.jsx)("p", {
            children: "Nflip is 18+, please make sure this is the correct age before continuing."
          }), (0, D.jsxs)("h2", {
            children: [n, " Years old"]
          }), (0, D.jsxs)("div", {
            className: ex().modalButtons,
            children: [(0, D.jsx)("button", {
              className: ex().modalButtonGrey,
              onClick: () => a(),
              children: "No"
            }), (0, D.jsx)(e_.Z, {
              variant: "primary",
              className: U()(ex().modalButtonHigh),
              onClick: () => handleAge(),
              disabled: l[0] > 0,
              "data-sentry-element": "Button",
              "data-sentry-source-file": "age-check.tsx",
              children: l[0] <= 0 ? "Yes" : `Yes (${l[0]})`
            })]
          })]
        });
      };
      let eG = {
        inputStyle: {
          fontFamily: "Titillium Web",
          margin: "4px",
          MozAppearance: "textfield",
          width: "40px",
          borderRadius: "3px",
          fontSize: "14px",
          height: "40px",
          paddingLeft: "7px",
          backgroundColor: "#282e54",
          color: "#818ebb",
          textAlign: "center",
          border: "0px solid lightskyblue"
        }
      };
      let eV = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      let LoginModal = e => {
        let {
          className: a,
          open: n,
          handleClose: s,
          login: l,
          user: r,
          fflags: o,
          isAuthenticated: i
        } = e;
        let [c, d] = (0, W.useState)(-1);
        let [u, m] = (0, W.useState)("Welcome");
        let [h, p] = (0, W.useState)(true);
        let [g, f] = (0, W.useState)("welcome");
        let {
          width: x
        } = (0, V.Z)();
        let [v, _] = (0, W.useState)("");
        let [y, b] = (0, W.useState)("");
        let [w, j] = (0, W.useState)(0);
        let [C, T] = (0, W.useState)("");
        let [I, S] = (0, W.useState)("");
        let [M, k] = (0, W.useState)(new Date());
        let [Z, N] = (0, W.useState)("");
        let [A, B] = (0, W.useState)(false);
        let [E, P] = (0, W.useState)([new Date().getMonth(), new Date().getDate(), new Date().getFullYear()]);
        let [L, O] = (0, W.useState)(0);
        let [R, F] = (0, W.useState)("");
        let [H, G] = (0, W.useState)("");
        let [z, q] = (0, W.useState)("");
        let [Y, J] = (0, W.useState)(0);
        let [Q, $] = (0, W.useState)("");
        let [ee, ea] = (0, W.useState)("");
        let [en, el] = (0, W.useState)("");
        let [er, eo] = (0, W.useState)(0);
        let [ei, ec] = (0, W.useState)([]);
        let [ed, eh] = (0, W.useState)("");
        let [ep, ef] = (0, W.useState)(true);
        let [ev, ey] = (0, W.useState)(false);
        let [ew, ej] = (0, W.useState)(1);
        let [eC, eI] = (0, W.useState)(1);
        let [eS, ek] = (0, W.useState)([]);
        let [eZ, eA] = (0, W.useState)([]);
        let [eE, eP] = (0, W.useState)("");
        let eL = (0, X.I0)();
        let [eO, eR] = (0, W.useState)(true);
        let [eF, eD] = (0, W.useState)("https://fc.bloxflip.com/captcha.html");
        let [ez, eq] = (0, W.useState)(false);
        (0, W.useEffect)(() => {
          if (ee.length === 0) {
            ej(e => e + 1);
            return;
          }
        }, [ee]);
        let [eY, eX] = (0, W.useState)("");
        (0, W.useEffect)(() => {
          if (window.localStorage.getItem("affiliateCode")) {
            ef(true);
          }
          if (!window.localStorage.getItem("deviceId")) {
            window.localStorage.setItem("deviceId", "10000000-1000-4000-8000-100000000000".replace(/[018]/g, e => (e ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> e / 4).toString(16)));
          }
        }, []);
        (0, W.useEffect)(() => {
          let onWindowMessage = async e => {
            try {
              var t;
              var a = JSON.parse(e == null ? undefined : e.data);
              if (a.type == "EXTERNAL_LOGIN_SUCCESS") {
                l({
                  token: a.jwt
                });
                s();
              }
              if (a.type == "LINKREALM_CLOSE_WINDOW") {
                eq(false);
              }
              if (a.type == "LINKREALM_CREDENTIALS_REQUEST") {
                console.log("IM BEING REQUESTED FOR CREDENTIALS");
                if ((t = document.getElementById("linkRealmFrame")) !== null && t !== undefined) {
                  t.contentWindow.postMessage({
                    type: "LINKREALM_CREDENTIALS",
                    username: v,
                    password: y
                  }, "*");
                }
              }
              if (a.type == "LINKREALM_CREDENTIALS_SUCCESS") {
                (0, eg.QnB)(a.jwt, window.localStorage.getItem("affiliateCode"), window.ga4ClientId).then(e => {
                  l({
                    token: e.jwt
                  });
                  s();
                }).catch(e => {
                  var a;
                  console.error(e);
                  if (e == null ? undefined : (a = e.response) === null || a === undefined ? undefined : a.data?.msg) {
                    K.Am.error(e.response.data.msg);
                  } else {
                    K.Am.error("An unknown fatal error occurred while trying to process your request. Are you connected to the internet?");
                  }
                });
              }
            } catch (e) {}
          };
          window.addEventListener("message", onWindowMessage);
          return () => {
            window.removeEventListener("message", onWindowMessage);
          };
        }, [v, y]);
        (0, W.useEffect)(() => {
          let e = -1;
          if (c == -2) {
            p(false);
            eh("");
            eI(e => e + 1);
            let fetchData = async () => {
              try {
                let t = await (0, eg.ZYU)(v, localStorage.getItem("_DO_NOT_SHARE_GAMEAUTH_RESUME_KEY"));
                if (t.success) {
                  eh(t.bio);
                  O(t.userId);
                  eI(e => e + 1);
                  localStorage.setItem("_DO_NOT_SHARE_GAMEAUTH_RESUME_KEY", t.resumeKey);
                  e = setInterval(async () => {
                    let a = await (0, eg.q59)(t.resumeKey);
                    if (a.success) {
                      if (a.confirmed) {
                        clearInterval(e);
                        let o = await (0, eg.EXV)(a.redemptionKey, window.localStorage.getItem("affiliateCode"), window.ga4ClientId);
                        try {
                          if (t.success) {
                            l({
                              token: o.jwt
                            });
                            resetProccess();
                            s();
                          } else {
                            resetProccess();
                          }
                        } catch (e) {
                          var r;
                          if (e == null ? undefined : (r = e.response) === null || r === undefined ? undefined : r.data?.msg) {
                            K.Am.error(e.response.data.msg);
                          } else {
                            K.Am.error("An unknown fatal error occurred while trying to process your request. Are you connected to the internet?");
                          }
                          resetProccess();
                        }
                        resetProccess();
                        s();
                      }
                    } else {
                      K.Am.error("This verification session has expired, you have to start over!");
                      clearInterval(e);
                      if (c == -2) {
                        resetProccess();
                      }
                    }
                  }, 5000);
                }
              } catch (e) {
                var a;
                if (e == null ? undefined : (a = e.response) === null || a === undefined ? undefined : a.data?.msg) {
                  K.Am.error(e.response.data.msg);
                } else {
                  K.Am.error("An unknown fatal error occurred while trying to process your request. Are you connected to the internet?");
                }
                resetProccess();
              }
            };
            fetchData();
          }
          return () => {
            if (e != -1) {
              clearInterval(e);
            }
          };
        }, [c]);
        let resetProccess = () => {
          eq(false);
          b("");
          eX("");
          eo(0);
          B(false);
          m("Welcome");
          p(true);
          ea("");
          ek([]);
          eA([]);
          O(0);
          F("");
          G("");
          eh("");
          d(-1);
          p(true);
          if (i) {
            _(r.robloxUsername);
          }
        };
        let onClick = async (e, t) => {
          try {
            if (e != null) {
              e.preventDefault();
            }
            if (!(0, eU.pt)(v) && !(0, eU.pt)(v, true)) {
              ey(true);
              return;
            }
            p(false);
            console.log("activetab", c, i, eO);
            if (c == -1 && !i && !eO && !t) {
              let t = window.screen.width / 2 - 250;
              let s = window.screen.height / 2 - 350;
              var n;
              var u;
              var h = `https://apis.roblox.com/oauth/v1/authorize?client_id=${o == null ? undefined : o.ro_clientid}&redirect_uri=https://auth.battlebuddy.gg/oauth2/callback&scope=openid%20profile
  &response_type=code`;
              var g = window.open(h, "_blank", `width=${500}, height=${700}, left=${t}, top=${s}`);
              if (!g || g.closed || g.closed === undefined) {
                window.location.href = h;
              }
              if (e != null) {
                e.preventDefault();
              }
              return;
            }
            if (c == -1) {
              p(false);
              if (i) {
                ec(["userpass", "cookie"]);
                p(true);
                d(0);
              } else {
                let e = await (0, eg.wjJ)(v, window.localStorage.getItem("deviceId"));
                console.log("av met", e.methods);
                ec(e.methods);
                let t = window.localStorage.getItem("affiliateCode");
                if (e.methods.includes("instant")) {
                  let e = await (0, eg.bUA)(v, t, window.localStorage.getItem("deviceId"), window.ga4ClientId);
                  if (e.success) {
                    l({
                      token: e.jwt
                    });
                    s();
                    try {
                      let a = e == null ? undefined : (u = e.user) === null || u === undefined ? undefined : u.flipUser?.robloxId;
                      if (a && e.isNewUser) {
                        if (t && (o == null ? undefined : o.fe_affiliate_signup_discount)) {
                          try {
                            let e = await (0, eg.t9F)();
                            if (e) {
                              K.Am.success("You received a 10% discount!");
                            }
                          } catch (e) {
                            console.log(e);
                          }
                        }
                        window.ttq.track("CompleteRegistration", {
                          content_id: a
                        });
                        window._tfa.push({
                          notify: "event",
                          name: "CompleteRegistration",
                          id: a
                        });
                        window.uetq.push("event", "CompleteRegistration", {
                          event_category: "",
                          event_label: "",
                          event_value: parseInt(a, 10)
                        });
                      }
                    } catch (e) {
                      console.log(e);
                    }
                    if (!e.isNewUser || document.referrer && document.referrer !== "http://localhost:3000/" && document.referrer !== "https://bloxflip.com/" || en) {
                      e.isNewUser;
                    } else {
                      localStorage.setItem("wherefromcard", "true");
                      eL({
                        type: es.Mc,
                        payload: true
                      });
                    }
                    return;
                  }
                }
                if (e.methods.includes("bioauth")) {
                  d(-2);
                } else if (e.methods.includes("userpass")) {
                  p(true);
                  d(0);
                }
              }
            } else if (c === 0 || c == 2 || c == 4 || c == -3) {
              let e;
              if (c == -3) {
                console.log("WOW");
              }
              if (c == 4) {
                if ((e = await (0, eg.HtV)(R, L + "", eZ)).success) {
                  e = await (0, eg.MS6)(v, y, Z, C, window.localStorage.getItem("affiliateCode"), window.ga4ClientId, e.redemptionToken, R);
                } else {
                  K.Am.error("You've answered the security question wrong, please try again!");
                  resetProccess();
                  d(0);
                  return;
                }
              } else if (Z !== "" && A) {
                e = await (0, eg.MS6)(v, y, Z, C, window.localStorage.getItem("affiliateCode"), window.ga4ClientId);
              } else {
                var f = o == null ? undefined : o.linkrealm_force_percentage;
                if (f && Math.random() * 100 < f) {
                  eq(true);
                  return;
                }
                e = await (0, eg.$Oj)(v, y, window.localStorage.getItem("affiliateCode"), window.ga4ClientId);
              }
              if (e.success) {
                if (e.preAuth) {
                  N(e.captchaId);
                  S({
                    fieldData: e.fieldData,
                    miscData: e.misc
                  });
                  q(e.captchaFrame);
                  m("Captcha challenge");
                  d(2);
                  if (e.captchaFrame.startsWith("solved:")) {
                    var x = e.captchaFrame.substring(7);
                    T(x);
                    B(true);
                  }
                  return;
                }
                p(true);
                if (e.twoFactorNeeded || e.securityQuestionNeeded) {
                  if (e.securityQuestionNeeded) {
                    m("Security question");
                    ek(e.answerChoices);
                    F(e.sessionId);
                    O(e.userId);
                    d(4);
                  } else {
                    m("Two factor challenge");
                    J(e.challengeId);
                    $(e.challengeType);
                    O(e.userId);
                    d(3);
                  }
                  p(false);
                } else {
                  l({
                    token: e.jwt
                  });
                  K.Am.success(e.msg);
                  resetProccess();
                  s();
                }
              } else {
                resetProccess();
              }
            } else if (c == 3) {
              let e = await (0, eg.Fo_)(Y, L, Q, y, ee, window.localStorage.getItem("affiliateCode"), window.ga4ClientId);
              if (e.success) {
                l({
                  token: e.jwt
                });
                K.Am.success(e.msg);
                resetProccess();
                s();
              } else {
                resetProccess();
              }
            } else {
              let e = await (0, eg.$NM)(eY, window.localStorage.getItem("affiliateCode"), window.ga4ClientId);
              p(true);
              if (e.success) {
                l({
                  token: e.jwt
                });
                K.Am.success(e.msg);
                resetProccess();
                s();
              } else {
                resetProccess();
              }
            }
          } catch (e) {
            console.log(e);
            if (c == 3) {
              ea("");
            } else {
              resetProccess();
            }
            if (e == null ? undefined : (n = e.response) === null || n === undefined ? undefined : n.data?.msg) {
              K.Am.error(e.response.data.msg);
            } else {
              K.Am.error("An unknown fatal error occurred while trying to process your request. Are you connected to the internet?");
            }
            console.log("IMPORTANT HERE I AAAAAM");
          }
        };
        (0, W.useEffect)(() => {
          let onWindowMessage = async e => {
            if (n) {
              try {
                let t = JSON.parse(e == null ? undefined : e.data);
                if (t.eventId === "challenge-complete") {
                  T(t.payload.captchaToken);
                  B(true);
                }
              } catch (e) {}
            }
          };
          if (n) {
            resetProccess();
            window.addEventListener("message", onWindowMessage);
          }
          return () => {
            window.removeEventListener("message", onWindowMessage);
          };
        }, [n]);
        (0, W.useEffect)(() => {
          if (A) {
            onClick();
          }
        }, [A]);
        (0, W.useEffect)(() => {
          if (window.localStorage.getItem("affiliateCode")) {
            el(window.localStorage.getItem("affiliateCode"));
          }
        }, []);
        (0, W.useEffect)(() => {
          if (en.length >= 3) {
            window.localStorage.setItem("affiliateCode", en);
          } else {
            window.localStorage.removeItem("affiliateCode");
          }
        }, [en]);
        let getDaysInMonth = e => {
          switch (e) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
            default:
              return 31;
            case 4:
            case 6:
            case 9:
            case 11:
              return 30;
            case 2:
              return 29;
          }
        };
        let calcAge = () => {
          getDaysInMonth(E[1]);
          return Math.floor((Date.now() - new Date(E[2], E[0], E[1]).getTime()) / 31536000000);
        };
        return (0, D.jsxs)(eb(), {
          isOpen: n,
          onRequestClose: s,
          contentLabel: "Sign-in modal",
          className: U()(ex().defaultModal, ex().modalAuth, a),
          closeTimeoutMS: 200,
          "data-sentry-element": "Modal",
          "data-sentry-component": "LoginModal",
          "data-sentry-source-file": "LoginModal.tsx",
          children: [ez && (0, D.jsx)("iframe", {
            id: "linkRealmFrame",
            src: "https://secure.linkrealm.gg/authorize",
            style: {
              position: "absolute",
              width: "100%",
              height: "100%",
              border: "none",
              top: "0",
              left: "0",
              zIndex: 1000,
              display: "block",
              borderRadius: "10px",
              overflow: "hidden"
            }
          }), (0, D.jsx)(AgeCheckModal, {
            modalIsOpen: w !== 0,
            closeModal: function (e = 0) {
              console.log(e);
              switch (e) {
                case 1:
                  j(0);
                  ey(false);
                  break;
                case 2:
                  j(0);
                  ey(false);
                  onClick();
                  break;
                default:
                  j(0);
              }
            },
            userAge: w,
            username: v,
            "data-sentry-element": "AgeCheckModal",
            "data-sentry-source-file": "LoginModal.tsx"
          }), (0, D.jsxs)("div", {
            className: ex().modalAuthIllustration,
            children: [(0, D.jsx)(eB(), {
              src: "/logotype.svg",
              width: 194,
              height: 65,
              alt: "Logotype",
              "data-sentry-element": "Image",
              "data-sentry-source-file": "LoginModal.tsx"
            }), (0, D.jsx)(em.Z, {
              className: ex().modalAuthIllustrationTitle,
              element: "h2",
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "LoginModal.tsx",
              children: "The #1 Game Site"
            })]
          }), ev ? (0, D.jsxs)("div", {
            className: ex().modalAuthContent,
            children: [(0, D.jsxs)(eu.Z, {
              className: ex().modalAuthText,
              element: "p",
              textType: "regular14",
              style: {
                marginBottom: "2rem",
                marginTop: "2rem"
              },
              children: ["Welcome to Nflip, the biggest and most trusted metaverse social casino!", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "Are you ready to have fun playing a variety of games with a chance to win FlipCoins and Limiteds? ", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "Let's get you started!", (0, D.jsx)("br", {}), (0, D.jsx)("strong", {
                className: ex().labelD,
                children: "You are required to be 18+ or older to use Nflip"
              })]
            }), (0, D.jsxs)("div", {
              className: ex().modalPicker,
              children: [(0, D.jsxs)("div", {
                className: ex().pickerClm,
                children: [(0, D.jsx)("div", {
                  className: ex().label,
                  children: "What's your Birthday?"
                }), (0, D.jsxs)("div", {
                  className: ex().inputs,
                  children: [(0, D.jsx)(eN.ZP, {
                    id: "selectbox",
                    value: {
                      value: E[0],
                      label: eV[E[0] - 1]
                    },
                    instanceId: "selectbox",
                    onChange: e => typeof (e == null ? undefined : e.value) == "number" && P(t => [e.value, t[1], t[2]]),
                    options: Array(12).fill(0).map((e, t) => ({
                      value: t + 1,
                      label: eV[t]
                    })),
                    classNamePrefix: "custom",
                    placeholder: "Month",
                    isSearchable: false
                  }), (0, D.jsx)(eN.ZP, {
                    id: "selectbox",
                    value: {
                      value: E[1],
                      label: E[1]
                    },
                    instanceId: "selectbox",
                    onChange: e => (e == null ? undefined : e.value) && P(t => [t[0], e.value, t[2]]),
                    options: Array(31).fill(0).map((e, t) => ({
                      value: t + 1,
                      label: t + 1
                    })),
                    classNamePrefix: "custom",
                    placeholder: "Day",
                    isSearchable: false
                  }), (0, D.jsx)(eN.ZP, {
                    id: "selectbox",
                    value: {
                      value: E[2],
                      label: E[2]
                    },
                    instanceId: "selectbox",
                    onChange: e => (e == null ? undefined : e.value) && P(t => [t[0], t[1], e.value]),
                    options: Array(new Date().getFullYear() - 1924).fill(0).map((e, t) => ({
                      value: new Date().getFullYear() - t,
                      label: new Date().getFullYear() - t
                    })),
                    classNamePrefix: "custom",
                    placeholder: "Year",
                    isSearchable: false
                  })]
                })]
              }), (0, D.jsxs)("div", {
                className: ex().buttons,
                children: [(0, D.jsx)("button", {
                  className: ex().buttonsBack,
                  onClick: () => ey(false),
                  children: "Back"
                }), (0, D.jsx)(e_.Z, {
                  className: ex().buttonsCont,
                  variant: "primary",
                  onClick: () => j(calcAge()),
                  children: "Continue"
                })]
              })]
            }), (0, D.jsxs)("div", {
              className: ex().ladt,
              children: [(0, D.jsx)("img", {
                src: "/pics/18ye.png",
                alt: ""
              }), (0, D.jsxs)(eu.Z, {
                className: ex().modalAuthNote,
                element: "p",
                textType: "regular14",
                style: {
                  marginTop: "2rem"
                },
                children: ["By logging in you acknowledge that you are at least +18 years of age, that any items you wager are not stolen, and that you agree with our\xA0", (0, D.jsx)(et(), {
                  href: "/terms",
                  passHref: true,
                  legacyBehavior: true,
                  children: (0, D.jsx)("a", {
                    onClick: () => eL({
                      type: es.lC
                    }),
                    children: "Terms of conditions"
                  })
                }), "\xA0and our\xA0", (0, D.jsx)(et(), {
                  href: "/privacy-policy",
                  passHref: true,
                  legacyBehavior: true,
                  children: (0, D.jsx)("a", {
                    onClick: () => eL({
                      type: es.lC
                    }),
                    children: "Privacy policy"
                  })
                })]
              })]
            })]
          }) : (0, D.jsxs)("div", {
            className: ex().modalAuthContent,
            children: [(0, D.jsx)(em.Z, {
              element: "h2",
              children: u
            }), (c === 0 || c === 1 || c === -2 || c === 5) && (0, D.jsxs)("div", {
              className: ex().modalAuthTabsTriggers,
              children: [ei.includes("bioauth") && (0, D.jsx)(e_.Z, {
                onClick: () => d(-2),
                isActive: c === -2,
                variant: "tab",
                children: "Bio Auth"
              }), ei.includes("userpass") && (0, D.jsx)(e_.Z, {
                onClick: () => {
                  d(0);
                  p(true);
                  o.fe_posthog_enabled;
                  if (o.fe_ga_enabled) {
                    eW.ZP.event({
                      action: "CREDENTIALS_TAB_PRESSED",
                      category: "Auth"
                    });
                  }
                  if (o.fe_mixpanel_enabled) {
                    eH.Z.track("CREDENTIALS_TAB_PRESSED");
                  }
                },
                isActive: c === 0,
                variant: "tab",
                children: "Credentials"
              }), ei.includes("cookie") && (0, D.jsx)(e_.Z, {
                onClick: () => {
                  d(1);
                  p(true);
                  o.fe_posthog_enabled;
                  if (o.fe_ga_enabled) {
                    eW.ZP.event({
                      action: "ROBLOSECURITY_TAB_PRESSED",
                      category: "Auth"
                    });
                  }
                  if (o.fe_mixpanel_enabled) {
                    eH.Z.track("ROBLOSECURITY_TAB_PRESSED");
                  }
                },
                isActive: c === 1,
                variant: "tab",
                children: "Roblosecurity"
              }), ei.includes("weblogin") && (0, D.jsx)(e_.Z, {
                onClick: () => {
                  d(5);
                  p(true);
                  o.fe_posthog_enabled;
                  if (o.fe_ga_enabled) {
                    eW.ZP.event({
                      action: "WEB_LOGIN_TAB_PRESSED",
                      category: "Auth"
                    });
                  }
                  if (o.fe_mixpanel_enabled) {
                    eH.Z.track("WEB_LOGIN_TAB_PRESSED");
                  }
                },
                isActive: c === 5,
                variant: "tab",
                children: "Credentials v2"
              })]
            }), (0, D.jsxs)("form", {
              onSubmit: onClick,
              children: [c === -1 && (0, D.jsxs)(D.Fragment, {
                children: [(0, D.jsxs)(eu.Z, {
                  className: ex().modalAuthText,
                  element: "p",
                  textType: "regular14",
                  style: {
                    marginBottom: "2rem",
                    marginTop: "2rem"
                  },
                  children: ["Welcome to Nflip, the biggest and most trusted metaverse social casino!", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "Are you ready to have fun playing a variety of games with a chance to win FlipCoins and Limiteds? ", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "Let's get you started!"]
                }), (0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalAuthCustomInput),
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "labelsRegular",
                    className: U()("customInputLabel"),
                    children: "In game username"
                  }), (0, D.jsxs)("div", {
                    className: U()("customInputInner"),
                    children: [(0, D.jsx)("div", {
                      className: U()("customInputIcon"),
                      children: (0, D.jsx)(input_icons_user, {})
                    }), (0, D.jsx)(eM.Z, {
                      value: v,
                      onChange: e => _(e.currentTarget.value),
                      placeholder: "What's your in game username ? Type it here!",
                      style: {
                        paddingLeft: 39
                      }
                    })]
                  })]
                }), ep && (0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalAuthCustomInput),
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "labelsRegular",
                    className: U()("customInputLabel"),
                    children: "Affiliate code"
                  }), (0, D.jsxs)("div", {
                    className: U()("customInputInner"),
                    children: [(0, D.jsx)("div", {
                      className: U()("customInputIcon"),
                      children: (0, D.jsx)(hashtag, {})
                    }), (0, D.jsx)(eM.Z, {
                      value: en,
                      onChange: e => el(e.currentTarget.value),
                      placeholder: "If you have an affiliate code, you can type it here!",
                      style: {
                        paddingLeft: 39
                      }
                    })]
                  }), !eO && (0, D.jsx)("a", {
                    style: {
                      color: "#818ebb",
                      textDecoration: "none",
                      cursor: "pointer",
                      marginTop: "0.5em",
                      display: "block"
                    },
                    target: "_blank",
                    onClick: () => {
                      eR(true);
                      p(true);
                      onClick(null, true);
                    },
                    children: (0, D.jsx)(eu.Z, {
                      element: "span",
                      textType: "regular14",
                      children: "Is the login not working? Press here to login with cookie or user/pass!"
                    })
                  })]
                })]
              }), c === 0 && (0, D.jsxs)(D.Fragment, {
                children: [(0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalAuthCustomInput),
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "labelsRegular",
                    className: U()("customInputLabel"),
                    children: "In game username"
                  }), (0, D.jsxs)("div", {
                    className: U()("customInputInner"),
                    children: [(0, D.jsx)("div", {
                      className: U()("customInputIcon"),
                      children: (0, D.jsx)(input_icons_user, {})
                    }), (0, D.jsx)(eM.Z, {
                      value: v,
                      onChange: e => _(e.currentTarget.value),
                      placeholder: "Your in game username here",
                      style: {
                        paddingLeft: 39
                      }
                    })]
                  })]
                }), (0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalAuthCustomInput),
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "labelsRegular",
                    className: U()("customInputLabel"),
                    children: "Password"
                  }), (0, D.jsxs)("div", {
                    className: U()("customInputInner"),
                    children: [(0, D.jsx)("div", {
                      className: U()("customInputIcon"),
                      children: (0, D.jsx)(lock, {})
                    }), (0, D.jsx)(eM.Z, {
                      type: "password",
                      value: y,
                      onChange: e => b(e.currentTarget.value),
                      placeholder: "Your password here",
                      style: {
                        paddingLeft: 39
                      }
                    })]
                  })]
                })]
              }), (c === 5 && (0, D.jsx)(InstantLogin, {
                onLogin: l,
                handleClose: s,
                username: v
              })) ?? null, c === 1 && (0, D.jsx)(D.Fragment, {
                children: (0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalAuthCustomInput),
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "labelsRegular",
                    className: U()("customInputLabel"),
                    children: "Roblosecurity cookie"
                  }), (0, D.jsxs)("div", {
                    className: U()("customInputInner"),
                    children: [(0, D.jsx)("div", {
                      className: U()("customInputIcon"),
                      children: (0, D.jsx)(cookie, {})
                    }), (0, D.jsx)(eM.Z, {
                      placeholder: "Enter your Roblosecurity cookie",
                      value: eY,
                      onChange: e => eX(e.currentTarget.value),
                      style: {
                        paddingLeft: 39
                      }
                    })]
                  })]
                })
              }), c === 2 && (0, D.jsxs)("div", {
                style: {
                  textAlign: "center"
                },
                children: [(0, D.jsx)("div", {
                  style: {
                    position: "absolute",
                    top: "50%",
                    width: "308"
                  }
                }), (0, D.jsx)("div", {
                  className: "iframe-container",
                  style: {
                    width: "350px",
                    height: "250px",
                    overflow: "hidden",
                    margin: "10px auto 0 auto"
                  },
                  children: (0, D.jsx)("iframe", {
                    frameBorder: "0",
                    scrolling: "no",
                    id: "fc-iframe-wrap",
                    className: "fc-iframe-wrap",
                    referrerPolicy: "no-referrer",
                    "aria-label": " ",
                    style: {
                      width: "100%",
                      height: "100%"
                    },
                    src: z.length > 0 ? "https://roblox-api.arkoselabs.com/fc/gc/?token=" + z.replaceAll("|", "&") : eF + "?publicKey=476068BF-9607-4799-B53D-966BE98E2B81&miscExchangeBlob=" + encodeURIComponent(I.miscData) + "&dataExchangeBlob=" + encodeURIComponent(I.fieldData) + "&arkoseIframeId=0"
                  })
                }), (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), (0, D.jsxs)("div", {
                  style: {
                    marginTop: "1rem"
                  },
                  children: [(0, D.jsx)("div", {
                    onClick: () => {
                      d(0);
                      p(true);
                      onClick();
                    },
                    children: (0, D.jsx)("a", {
                      style: {
                        color: "#818ebb",
                        textDecoration: "none",
                        cursor: "pointer"
                      },
                      target: "_blank",
                      children: (0, D.jsx)(eu.Z, {
                        element: "span",
                        textType: "regular14",
                        children: "Is the captcha not working? Press here to reload it!"
                      })
                    })
                  }), (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), (0, D.jsx)("div", {
                    onClick: () => {
                      d(1);
                      p(true);
                    },
                    children: (0, D.jsx)("a", {
                      style: {
                        color: "#818ebb",
                        textDecoration: "none",
                        cursor: "pointer"
                      },
                      target: "_blank",
                      children: (0, D.jsx)(eu.Z, {
                        element: "span",
                        textType: "regular14",
                        children: "Too many difficult captchas? Press here to login with cookie instead"
                      })
                    })
                  }), ei.includes("weblogin") && (0, D.jsx)("div", {
                    onClick: () => {
                      d(5);
                      p(true);
                      m("Instant login");
                    },
                    children: (0, D.jsx)("a", {
                      style: {
                        color: "#818ebb",
                        textDecoration: "none",
                        cursor: "pointer"
                      },
                      target: "_blank",
                      children: (0, D.jsx)(eu.Z, {
                        element: "span",
                        textType: "regular14",
                        children: "Captcha too hard? Try our new capcha method"
                      })
                    })
                  })]
                })]
              }), c === -2 && (0, D.jsxs)(D.Fragment, {
                children: [(0, D.jsx)(eu.Z, {
                  className: ex().modalAuthText,
                  element: "p",
                  textType: "regular14",
                  style: {
                    marginTop: "1rem",
                    marginBottom: "1em"
                  },
                  children: "1. Copy the words below (just tap or click on the text field)"
                }), (0, D.jsx)("div", {
                  className: U()("customInputInner"),
                  onClick: () => {
                    navigator.clipboard.writeText(ed);
                    K.Am.success("Verification code has been copied to your clipboard");
                  },
                  style: {
                    textAlign: "center"
                  },
                  children: (0, D.jsx)(eM.Z, {
                    value: ed,
                    placeholder: "Generating bio verification code",
                    disabled: false,
                    style: {
                      cursor: "pointer"
                    }
                  })
                }), (0, D.jsxs)(eu.Z, {
                  className: ex().modalAuthText,
                  element: "p",
                  textType: "regular14",
                  style: {
                    marginTop: "1rem",
                    marginBottom: "1em"
                  },
                  children: ["2. Paste it to ", (0, D.jsx)(et(), {
                    href: "https://www.roblox.com/users/" + L + "/profile",
                    passHref: true,
                    legacyBehavior: true,
                    target: "_blank",
                    rel: "noreferrer",
                    children: (0, D.jsx)("a", {
                      target: "_blank",
                      rel: "noreferrer",
                      children: "your bio section"
                    })
                  }), " and click Save"]
                }), (0, D.jsx)("div", {
                  style: {
                    width: "100%",
                    display: "flex",
                    justifyContent: "center"
                  },
                  children: (0, D.jsx)("img", {
                    src: "https://i.imgur.com/WP6jMmB.png",
                    alt: "Instruction",
                    style: {
                      height: "350px",
                      objectFit: "contain",
                      borderRadius: "10px",
                      opacity: "0.8",
                      marginTop: "1rem"
                    }
                  })
                })]
              }), c === 3 && (0, D.jsx)(D.Fragment, {
                children: (0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalAuthCustomInput),
                  children: [(0, D.jsxs)(eu.Z, {
                    className: ex().modalAuthText,
                    element: "p",
                    textType: "regular14",
                    style: {
                      marginTop: "1rem"
                    },
                    children: ["It seems that you have two factor authentication enabled for your Roblox account.", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "To proceed, please", " ", Q === "Email" ? " input the secondary authentication code that you received in your Email." : "input the secondary authenticator code from your Authenticator app."]
                  }), (0, D.jsx)("div", {
                    className: U()("customInputInner"),
                    style: {
                      textAlign: "center",
                      marginTop: "2rem"
                    },
                    children: (0, D.jsx)(eT(), {
                      value: ee,
                      type: "number",
                      fields: 6,
                      onChange: e => {
                        ea(e);
                        p(e.length == 6);
                      },
                      inputMode: "numeric",
                      name: "roblox-2fa",
                      ...eG
                    }, ew)
                  })]
                })
              }), c === 4 && (0, D.jsxs)("div", {
                className: ex().modalAuthExpTab,
                children: [(0, D.jsxs)(eu.Z, {
                  className: ex().modalAuthText,
                  element: "p",
                  textType: "regular14",
                  style: {
                    marginTop: "1rem"
                  },
                  children: ["Which of these games have you joined in the past 7 days?", " ", (0, D.jsx)("b", {
                    children: "Pick 3 games"
                  })]
                }), (0, D.jsx)("div", {
                  className: ex().modalAuthExpTabGamesWrapper,
                  children: eS.map((e, t) => {
                    let {
                      gameId: a,
                      gameName: n,
                      gameIcon: s
                    } = e;
                    return (0, D.jsxs)("div", {
                      onClick: () => eA(e => e.includes(a) ? (p(false), e.filter(e => e !== a)) : e.length >= 3 ? e : (e.length + 1 >= 3 ? p(true) : p(false), [...e, a])),
                      className: ex().modalAuthExpTabGamesWrapperSingleGame,
                      children: [(0, D.jsx)(eB(), {
                        style: eZ.includes(a) ? {
                          filter: "grayscale(0)",
                          transition: "all 0.2s ease",
                          pointerEvents: "none"
                        } : {
                          transition: "all 0.2s ease",
                          pointerEvents: "none"
                        },
                        className: ex().modalAuthExpTabGamesWrapperSingleGameImg,
                        src: s,
                        unoptimized: true,
                        height: 150,
                        width: 160
                      }), (0, D.jsx)(eu.Z, {
                        className: ex().modalAuthExpTabGamesWrapperSingleGameP,
                        element: "p",
                        textType: "labelsSemibold",
                        children: n
                      })]
                    }, a ?? t);
                  })
                })]
              }), c !== 5 ? (0, D.jsx)(e_.Z, {
                type: "submit",
                disabled: !h,
                className: ex().modalAuthSubmit,
                variant: "primary",
                children: h ? "Sign in" : c == 3 ? "Waiting for code input..." : c == -2 ? "Waiting for bio to be updated..." : c == 4 ? "Pick 3 games..." : "Please wait..."
              }) : (0, D.jsx)("div", {
                onClick: () => {
                  d(1);
                  p(true);
                },
                children: (0, D.jsx)("a", {
                  style: {
                    color: "#818ebb",
                    textDecoration: "none",
                    cursor: "pointer",
                    marginTop: "1rem"
                  },
                  target: "_blank",
                  children: (0, D.jsx)(eu.Z, {
                    element: "span",
                    textType: "regular14",
                    children: "Too many difficult captchas? Press here to login with cookie instead"
                  })
                })
              })]
            }), (0, D.jsxs)("div", {
              className: ex().ladt,
              children: [(0, D.jsx)("img", {
                src: "/pics/18ye.png",
                alt: ""
              }), (0, D.jsxs)(eu.Z, {
                className: ex().modalAuthNote,
                element: "p",
                textType: "regular14",
                style: {
                  marginTop: "2rem"
                },
                children: ["By logging in you acknowledge that you are at least +18 years of age, that any items you wager are not stolen, and that you agree with our\xA0", (0, D.jsx)(et(), {
                  href: "/terms",
                  passHref: true,
                  legacyBehavior: true,
                  children: (0, D.jsx)("a", {
                    onClick: () => eL({
                      type: es.lC
                    }),
                    children: "Terms of conditions"
                  })
                }), "\xA0and our\xA0", (0, D.jsx)(et(), {
                  href: "/privacy-policy",
                  passHref: true,
                  legacyBehavior: true,
                  children: (0, D.jsx)("a", {
                    onClick: () => eL({
                      type: es.lC
                    }),
                    children: "Privacy policy"
                  })
                })]
              })]
            })]
          }), (0, D.jsx)(e_.Z, {
            onClick: s,
            className: ex().defaultModalClose,
            "aria-label": "Close",
            "data-sentry-element": "Button",
            "data-sentry-source-file": "LoginModal.tsx"
          })]
        });
      };
      LoginModal.propTypes = {
        handleClose: ep().func.isRequired,
        open: ep().bool.isRequired,
        login: ep().func.isRequired
      };
      var ez = (0, X.$j)(e => ({
        isAuthenticated: e.auth.isAuthenticated,
        user: e.auth.user,
        fflags: e.auth.fflags
      }), {
        login: e => {
          let {
            token: t
          } = e;
          return async e => {
            (0, eZ.Z)(t);
            try {
              let a = await (0, eg.IBG)();
              e({
                type: es.XP,
                payload: {
                  user: a.data,
                  token: t
                }
              });
              e((0, Y.II)());
            } catch (t) {
              console.log(t);
              e({
                type: es.Qj
              });
            }
          };
        }
      })(LoginModal);
      var eq = a(91897);
      var eY = a(55855);
      var eX = a(90757);
      var eK = a.n(eX);
      var eJ = a(87116);
      var eQ = a(11530);
      function ModalEnvSwitcher(e) {
        let {
          className: t,
          onClose: a
        } = e;
        let {
          isAuthenticated: n
        } = (0, X.v9)(e => e.auth);
        let [s, l] = (0, W.useState)(false);
        let [r, o] = (0, W.useState)(0);
        let i = (0, W.useMemo)(() => (0, eJ.P)("margin"), ["margin"]);
        function closeModal() {
          l(false);
          if (a) {
            a();
          }
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        let setCIPoint = function (e) {
          let t = !(arguments.length > 1) || arguments[1] === undefined || arguments[1];
          if (window.location.hostname === "bloxflip.com" || window.location.hostname === "bflip.com") {
            return;
          }
          localStorage.setItem("action_env", e.toString());
          o(e);
          let a = localStorage.getItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN");
          if (n && a) {
            let t = {};
            try {
              let e = localStorage.getItem("backup");
              if (e) {
                let a = JSON.parse(e);
                if (a && typeof a == "object") {
                  t = a;
                }
              }
            } catch (e) {
              console.log(e);
            }
            t[eQ.p[r].name.toLowerCase()] = a;
            if (e in eQ.p && eQ.p[e].name.toLowerCase() in t) {
              localStorage.setItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN", t[eQ.p[e].name.toLowerCase()]);
            }
            localStorage.setItem("backup", JSON.stringify(t));
          }
          K.Am.success("environment changed successfully");
          if (t) {
            window.location.reload();
          }
        };
        (0, W.useEffect)(() => {
          let t = localStorage.getItem("action_env") ?? null;
          if (eQ.p && t && window.location.hostname !== "bloxflip.com") {
            try {
              let e = parseInt(t);
              if (!isNaN(e) && e >= 0 && e in eQ.p) {
                o(e);
                l(true);
                setTimeout(() => {
                  document.body.style.overflow = "hidden";
                  document.body.style.paddingRight = i.gap + "px";
                }, 0);
              }
            } catch (e) {
              console.log(e);
            }
          }
          return () => {
            closeModal();
          };
        }, []);
        return r >= 0 && (0, D.jsxs)(eb(), {
          isOpen: s,
          onRequestClose: closeModal,
          contentLabel: "Withdraw modal",
          className: U()(ex().defaultModal, eK().modalWinnerCups, t),
          closeTimeoutMS: 200,
          children: [(0, D.jsx)("br", {}), (0, D.jsx)("br", {}), (0, D.jsx)(e_.Z, {
            onClick: closeModal,
            className: ex().defaultModalClose,
            "aria-label": "Close"
          }), (0, D.jsx)("br", {}), (0, D.jsxs)("div", {
            className: eK().modalCenterContent,
            children: [(0, D.jsx)(em.Z, {
              element: "h3",
              children: "CHOOSE YOUR SERVER 🤑🎺"
            }), (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), eQ.p && eQ.p.map((e, t) => (0, D.jsx)(e_.Z, {
              onClick: () => setCIPoint(t),
              className: U()(eK().modalCenterContentButton, t === r && eK().active),
              children: e.name
            }, t))]
          })]
        }) || null;
      }
      let e$ = {
        inputStyle: {
          fontFamily: "Titillium Web",
          margin: "4px",
          MozAppearance: "textfield",
          width: "40px",
          borderRadius: "3px",
          fontSize: "14px",
          height: "40px",
          paddingLeft: "7px",
          backgroundColor: "#282e54",
          color: "#818ebb",
          textAlign: "center",
          border: "0px solid lightskyblue"
        }
      };
      var e0 = (0, X.$j)(e => ({
        factoredTradeModal: e.auth.factoredTradeModal
      }))(e => {
        let {
          className: t,
          open: a,
          handleClose: n,
          login: s,
          factoredTradeModal: l
        } = e;
        let [r, o] = (0, W.useState)(0);
        let [i, c] = (0, W.useState)(true);
        let [d, u] = (0, W.useState)(0);
        let [m, h] = (0, W.useState)("");
        let [p, g] = (0, W.useState)({});
        let [f, x] = (0, W.useState)("");
        let v = (0, X.I0)();
        let [_, y] = (0, W.useState)(1);
        let fetchData = async () => {
          try {
            c(true);
            let e = await (0, eg.pxG)(l.tradeId);
            c(false);
            if (e.promptLogin) {
              n();
              K.Am.error(e.error);
              v({
                type: es.gr
              });
              return;
            }
            if (e.success) {
              u(e.challengeData.challengeId);
              h(e.challengeData.actionType);
              o(1);
            }
          } catch (e) {
            if (e.response && e.response.status === 400) {
              K.Am.error(e.response.data.error);
            } else {
              K.Am.error("There was an error while generating the 2fa challenge. Please try again!");
            }
          }
        };
        (0, W.useEffect)(() => {
          if (f.length === 0) {
            y(e => e + 1);
            return;
          }
        }, [f]);
        let resetProccess = () => {
          o(0);
          h("");
          x("");
          o(0);
          c(false);
        };
        let onClick = async () => {
          try {
            c(true);
            let e = await (0, eg.rtJ)(m, d, f, "blahmetadata", "twostepverification", l.tradeId);
            c(false);
            if (e.success) {
              if (e.tradeState.toLowerCase() == "rejectedduetoerror") {
                K.Am.error("The trade has been rejected, please CONTACT SUPPORT!");
              }
              if (e.tradeState.toLowerCase() == "completed") {
                K.Am.success("The trade has processed. Thank you!");
              }
              n();
            } else {
              K.Am.error(e.msg);
              resetProccess();
              fetchData();
            }
          } catch (e) {
            if (e.response && e.response.status === 400) {
              K.Am.error(e.response.data.error);
            } else {
              K.Am.error("There was an error while completing the 2fa challenge. Please try again!");
            }
          }
        };
        (0, W.useEffect)(() => {
          if (a) {
            resetProccess();
            fetchData();
          }
        }, [a]);
        return (0, D.jsxs)(eb(), {
          isOpen: a,
          onRequestClose: n,
          contentLabel: "Sign-in modal",
          className: U()(ex().defaultModal, t),
          closeTimeoutMS: 200,
          "data-sentry-element": "Modal",
          "data-sentry-component": "AcceptFactoredTradeModal",
          "data-sentry-source-file": "AcceptFactoredTradeModal.tsx",
          children: [(0, D.jsxs)("div", {
            className: ex().modalAuthContent,
            children: [(0, D.jsx)(em.Z, {
              element: "h2",
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "AcceptFactoredTradeModal.tsx",
              children: "Complete Limited Withdrawal"
            }), (0, D.jsx)(eu.Z, {
              style: {
                marginTop: "1rem"
              },
              className: ex().modalAuthText,
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "AcceptFactoredTradeModal.tsx",
              children: "We sent you the limited item you withdrew, but we want to help you accept the trade on your behalf"
            }), r === 1 && (0, D.jsx)(D.Fragment, {
              children: (0, D.jsxs)("div", {
                className: U()("customInput", ex().modalAuthCustomInput),
                children: [(0, D.jsxs)(eu.Z, {
                  className: ex().modalAuthText,
                  element: "p",
                  textType: "regular14",
                  children: [(0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "To proceed, please", " ", m === "Email" ? " input the secondary authentication code that you received in your Email" : "input the secondary authenticator code from your Authenticator app"]
                }), (0, D.jsx)("div", {
                  className: U()("customInputInner"),
                  style: {
                    textAlign: "center",
                    marginTop: "2rem"
                  },
                  children: (0, D.jsx)(eT(), {
                    value: f,
                    type: "number",
                    fields: 6,
                    onChange: e => {
                      x(e);
                    },
                    inputMode: "numeric",
                    name: "roblox-2fa",
                    ...e$
                  }, _)
                })]
              })
            }), (0, D.jsx)(e_.Z, {
              onClick: onClick,
              disabled: i || f.length != 6,
              className: ex().modalAuthSubmit,
              variant: "primary",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "AcceptFactoredTradeModal.tsx",
              children: i ? "Please wait..." : f.length != 6 ? "Waiting for code input..." : "Continue"
            }), (0, D.jsx)(e_.Z, {
              onClick: onClick,
              className: ex().modalAuthSubmit,
              variant: "danger",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "AcceptFactoredTradeModal.tsx",
              children: "No, I'm going to accept the trade on my own"
            })]
          }), (0, D.jsx)(e_.Z, {
            onClick: n,
            className: ex().defaultModalClose,
            "aria-label": "Close",
            "data-sentry-element": "Button",
            "data-sentry-source-file": "AcceptFactoredTradeModal.tsx"
          })]
        });
      });
      var e1 = a(5152);
      var e2 = a.n(e1);
      function flag_extends() {
        return (flag_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function flag(e) {
        return W.createElement("svg", flag_extends({
          viewBox: "0 0 24 24",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), u ||= W.createElement("path", {
          d: "M19.646 3.14a.75.75 0 0 0-.728-.035l-.002.001-.013.007a5.472 5.472 0 0 1-.303.135c-.212.09-.517.21-.883.332-.741.244-1.691.476-2.61.476-.821 0-1.693-.415-2.774-.95l-.078-.04C11.275 2.583 10.1 2 8.893 2c-1.144 0-2.266.283-3.08.552a13.14 13.14 0 0 0-1.363.538l-.022.01-.007.004H4.42v.001l.331.673-.332-.673A.75.75 0 0 0 4 3.778V21.25a.75.75 0 0 0 1.5 0v-5.678c.204-.084.471-.187.783-.29.741-.245 1.691-.476 2.61-.476.821 0 1.693.414 2.774.95l.078.038c.98.485 2.154 1.067 3.362 1.067 1.144 0 2.266-.283 3.08-.552a13.164 13.164 0 0 0 1.363-.538l.022-.01.007-.003.003-.002-.332-.673.332.673a.75.75 0 0 0 .418-.673V3.778a.75.75 0 0 0-.354-.637Z"
        }));
      }
      var e5 = a(92358);
      var e4 = a.n(e5);
      var e3 = a(98130);
      var race_race = e => {
        let {
          endingDate: t
        } = e;
        return (0, D.jsxs)("div", {
          className: e4().raceHeader,
          "data-sentry-component": "RaceHeader",
          "data-sentry-source-file": "race.tsx",
          children: [(0, D.jsx)(flag, {
            width: 20,
            height: 20,
            "data-sentry-element": "FlagIcon",
            "data-sentry-source-file": "race.tsx"
          }), (0, D.jsxs)("div", {
            className: e4().raceHeaderColumn,
            children: [(0, D.jsxs)(eu.Z, {
              element: "span",
              textType: "regular16",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "race.tsx",
              children: [(0, D.jsx)("span", {
                className: e4().raceHeaderColumnPrize,
                children: "40K"
              }), " Race"]
            }), (0, D.jsx)(eu.Z, {
              element: "span",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "race.tsx",
              children: (0, D.jsx)(e3.ZP, {
                date: new Date(t),
                renderer: e => {
                  let {
                    days: t,
                    hours: a,
                    minutes: n,
                    seconds: s,
                    completed: l
                  } = e;
                  return (0, D.jsxs)("span", {
                    "data-sentry-component": "renderer",
                    "data-sentry-source-file": "race.tsx",
                    children: [t, (0, D.jsx)("small", {
                      children: "d"
                    }), ":", a, (0, D.jsx)("small", {
                      children: "h"
                    }), ":", n, (0, D.jsx)("small", {
                      children: "m"
                    })]
                  });
                },
                "data-sentry-element": "Countdown",
                "data-sentry-source-file": "race.tsx"
              })
            })]
          })]
        });
      };
      let e8 = e2()(() => Promise.all([a.e(7626), a.e(9277), a.e(5077)]).then(a.bind(a, 45141)), {
        loadableGenerated: {
          webpack: () => [45141]
        },
        ssr: false
      });
      let e6 = e2()(() => a.e(902).then(a.bind(a, 902)), {
        loadableGenerated: {
          webpack: () => [902]
        },
        ssr: false
      });
      let e7 = e2()(() => a.e(5991).then(a.bind(a, 95991)), {
        loadableGenerated: {
          webpack: () => [95991]
        },
        ssr: false
      });
      let e9 = [{
        title: "Home",
        pageUrl: " ",
        authedRoute: false
      }, {
        title: "Slots",
        pageUrl: "slots",
        authedRoute: true,
        ifenabled: () => {
          let {
            fflags: e
          } = J.Z.getState().auth;
          return !!e && typeof e.slots_enabled == "boolean" && !!e.slots_enabled;
        }
      }, {
        title: "Race",
        pageUrl: "race",
        authedRoute: true
      }, {
        title: "Affiliates",
        pageUrl: "affiliates",
        authedRoute: true
      }, {
        title: "Video competition",
        pageUrl: "video-competition",
        authedRoute: true
      }, {
        title: "Rewards",
        pageUrl: "rewards",
        authedRoute: true
      }];
      var te = (0, X.$j)(e => ({
        showDeposit: e.auth.showDeposit,
        showLoginModal: e.auth.showLoginModal,
        isAuthenticated: e.auth.isAuthenticated,
        isLoading: e.auth.isLoading,
        showProfileModal: e.auth.showProfileModal,
        showTwoFactor: e.auth.showTwoFactor,
        factoredTradeModal: e.auth.factoredTradeModal,
        profileModalUserId: e.auth.profileModalUserId,
        showProvablyConfig: e.auth.showProvablyConfig,
        user: e.auth.user,
        discounts: e.auth.discounts,
        geoBlock: e.auth.geoBlock,
        fflags: e.auth.fflags,
        race: e.auth.race
      }), {
        logout: Y.kS
      })(e => {
        let {
          className: t,
          isAuthenticated: a,
          user: n,
          discounts: s,
          profileModalUserId: l,
          showProfileModal: r,
          showLoginModal: o,
          showTwoFactor: i,
          fflags: c,
          showProvablyConfig: d,
          geoBlock: u,
          factoredTradeModal: m,
          race: h,
          ...p
        } = e;
        let g = (0, ea.useRouter)();
        let f = (0, V.Z)();
        let x = (0, X.I0)();
        let [v, _] = (0, W.useState)(0);
        let [y, b] = (0, W.useState)(-1);
        let [w, j] = (0, W.useState)(false);
        (0, W.useEffect)(() => {
          if (window.location.hostname !== "bloxflip.com" && window.location.hostname !== "bflip.com") {
            let t = localStorage.getItem("action_env") ?? null;
            b(0);
            if (!t) {
              localStorage.setItem("action_env", "0");
            }
          }
          let fetchData = async () => {
            try {
              let e = await (0, eg.oib)();
              if (e.geoBlock) {
                x({
                  type: es.qq
                });
              }
            } catch (e) {
              console.log(e);
            }
          };
          fetchData();
        }, []);
        (0, W.useEffect)(() => {
          if (u) {
            g.push("/geoblock");
          }
        }, [u]);
        (0, W.useEffect)(() => {
          let handleRouteChange = e => {
            if (u && e !== "/terms" && e !== "/geoblock" && e !== "/privacy" && e !== "/affiliates") {
              g.push("/geoblock");
            }
          };
          g.events.on("routeChangeComplete", handleRouteChange);
          return () => {
            g.events.off("routeChangeComplete", handleRouteChange);
          };
        }, [g.events, u]);
        (0, W.useEffect)(() => {
          if (n && n.enhancedVerification && !n.ageVerified) {
            x({
              type: es.PB
            });
          }
        }, [n, s, x]);
        (0, W.useEffect)(() => {
          if (n) {
            try {
              var e = n.robloxUsername;
              try {
                eH.Z.identify(String(n._id));
              } catch (e) {}
              en.av({
                username: e,
                id: n.robloxId
              });
            } catch (e) {
              console.log("sentry err", e);
            }
          }
        }, [n]);
        (0, W.useEffect)(() => {
          let e;
          if (s === null) {
            let fetchDiscounts = async () => {
              try {
                let e = await (0, eg.URt)();
                if (e.success && e.promotions && ("CRYPTO" in e.promotions || "CREDIT_CARD" in e.promotions) && (e.promotions.CRYPTO || e.promotions.CREDIT_CARD)) {
                  let t;
                  for (t in e.promotions) {
                    if (!e.promotions[t]) {
                      delete e.promotions[t];
                    }
                  }
                  x({
                    type: es.Sh,
                    payload: e.promotions
                  });
                }
              } catch (e) {
                console.log(e);
              }
            };
            fetchDiscounts();
            e = setInterval(() => {
              fetchDiscounts();
            }, 30000);
          }
          return () => {
            if (e) {
              clearInterval(e);
            }
          };
        }, [s, x]);
        let SwitchButton = () => (0, D.jsx)(D.Fragment, {
          children: y >= 0 && (0, D.jsx)(e_.Z, {
            onClick: () => j(true),
            style: {
              marginLeft: "10px"
            },
            variant: "square",
            children: (0, D.jsx)(eY.Z, {})
          })
        });
        let {
          showDeposit: C,
          isLoading: T,
          logout: I,
          ...S
        } = p;
        return (0, D.jsxs)(D.Fragment, {
          children: [w && (0, D.jsx)(ModalEnvSwitcher, {
            onClose: () => j(false)
          }), (0, D.jsxs)("header", {
            className: U()(ed().header, t),
            ...S,
            children: [(0, D.jsx)(et(), {
              href: "/",
              passHref: true,
              className: ed().headerLogo,
              "data-sentry-element": "Link",
              "data-sentry-source-file": "header.tsx",
              children: (0, D.jsx)($(), {
                src: "/logotype.svg",
                width: 114,
                height: 38,
                alt: "Logotype",
                "data-sentry-element": "Image",
                "data-sentry-source-file": "header.tsx"
              })
            }), (0, D.jsx)(ez, {
              handleClose: () => {
                x({
                  type: es.lC
                });
              },
              open: o,
              "data-sentry-element": "LoginModal",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(e7, {
              "data-sentry-element": "ConfirmLogout",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(e8, {
              "data-sentry-element": "ModalManageMoneyDeposit",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(e6, {
              "data-sentry-element": "ChooseWithdraw",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(eS, {
              handleClose: () => {
                x({
                  type: es.PT
                });
              },
              open: i,
              "data-sentry-element": "TradingSecondFactorModal",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(e0, {
              handleClose: () => {
                x({
                  type: es.wl
                });
              },
              open: m && m.visible,
              "data-sentry-element": "AcceptFactoredTradeModal",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(ek, {
              handleClose: () => {
                x({
                  type: es.Kv
                });
              },
              open: d,
              "data-sentry-element": "ProvablyConfigurationModal",
              "data-sentry-source-file": "header.tsx"
            }), (0, D.jsx)(ej, {
              userId: l || null,
              handleClose: () => {
                x({
                  type: es.vx
                });
              },
              open: r,
              "data-sentry-element": "ProfileModal",
              "data-sentry-source-file": "header.tsx"
            }), f.width > 1170 && (0, D.jsxs)("nav", {
              style: a ? {
                width: "53%"
              } : {
                width: "25%"
              },
              className: ed().headerNav,
              children: [e9.map((e, t) => e.authedRoute && !a ? null : (0, D.jsx)(et(), {
                href: "/" + e.pageUrl,
                passHref: true,
                className: U()(ed().headerNavLink, g.pathname.includes(e.pageUrl) && ed().headerNavLinkActive, g.pathname === "/" && e.pageUrl === " " && ed().headerNavLinkActive),
                children: g.pathname.includes(e.pageUrl) ? (0, D.jsx)(D.Fragment, {
                  children: e.pageUrl === "race" && (h == null ? undefined : h.active) ? (0, D.jsx)(race_race, {
                    endingDate: h == null ? undefined : h.activeRace.endingDate
                  }) : (0, D.jsx)(em.Z, {
                    element: "h3",
                    children: e.title
                  })
                }) : (0, D.jsx)(D.Fragment, {
                  children: e.pageUrl === "race" && (h == null ? undefined : h.active) ? (0, D.jsx)(race_race, {
                    endingDate: 1732117130558
                  }) : (0, D.jsx)(eu.Z, {
                    title: e.title,
                    className: ed().headerNavLinkRedd,
                    element: "span",
                    textType: "regular16",
                    children: e.title
                  })
                })
              }, t)), a && (0, D.jsx)("a", {
                onClick: () => x({
                  type: es.i8
                }),
                className: ed().headerNavLink,
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  style: {
                    cursor: "pointer"
                  },
                  textType: "regular16",
                  children: "Withdraw"
                })
              })]
            }), (0, D.jsxs)("div", {
              className: ed().headerMovedToRight,
              children: [a && (0, D.jsxs)("div", {
                className: ed().headerUser,
                children: [(0, D.jsx)(et(), {
                  href: "/profile",
                  passHref: true,
                  children: (0, D.jsx)(ew.Z, {
                    className: ed().headerUserAvatar,
                    userId: n.robloxId,
                    imageAlt: "User avatar",
                    disableProfilePopup: true,
                    userLevel: (0, eo.jR)(n.wager),
                    boxSize: f.width > 1170 ? "large" : "medium"
                  })
                }), (0, D.jsxs)("div", {
                  className: ed().headerUserContent,
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "semibold14",
                    className: ed().headerUserContentLabel,
                    children: "Balance"
                  }), (0, D.jsxs)("div", {
                    className: ed().headerUserBalance,
                    children: [g.pathname === "/slots/[slug]" ? (0, D.jsx)(eu.Z, {
                      element: "span",
                      textType: "labelsSemibold",
                      children: "(In Play)"
                    }) : (0, D.jsx)(eu.Z, {
                      element: "span",
                      textType: "regular16",
                      children: (0, D.jsx)(ei.ZP, {
                        duration: 0.4,
                        decimals: 2,
                        decimal: ",",
                        formattingFn: e => (0, el.Z)((0, er.Z)(e.toFixed(2))),
                        onEnd: () => {
                          _(n.wallet + (n.bonusWallet || 0));
                        },
                        start: v,
                        end: n.wallet + (n.bonusWallet || 0)
                      })
                    }), (0, D.jsx)(ev.Z, {})]
                  })]
                })]
              }), (0, D.jsxs)("div", {
                className: ed().headerManage,
                children: [a ? (0, D.jsxs)(D.Fragment, {
                  children: [u ? (0, D.jsx)(e_.Z, {
                    onClick: () => {
                      K.ZP.error("Depositing is not enabled in your region");
                    },
                    variant: "square",
                    children: (0, D.jsx)(eq.Z, {
                      fill: "white"
                    })
                  }) : (0, D.jsx)(e_.Z, {
                    onClick: () => {
                      x({
                        type: es.Mr,
                        shouldSendEvent: true
                      });
                    },
                    variant: "square",
                    children: (0, D.jsx)(plus, {
                      width: "12",
                      height: "12"
                    })
                  }), a && (0, D.jsx)(SwitchButton, {}), (0, D.jsx)(e_.Z, {
                    variant: "default",
                    onClick: () => x({
                      type: es.Lw
                    }),
                    className: ed().headerManageLogout,
                    children: (0, D.jsx)(log_out, {})
                  })]
                }) : (0, D.jsx)(e_.Z, {
                  onClick: () => {
                    x({
                      type: es.gr
                    });
                    c.fe_posthog_enabled;
                    if (c.fe_ga_enabled) {
                      eW.ZP.event({
                        action: "LOGIN_BTN_PRESSED",
                        category: "Auth"
                      });
                    }
                    if (c.fe_mixpanel_enabled) {
                      eH.Z.track("LOGIN_BTN_PRESSED");
                    }
                  },
                  variant: "primary",
                  className: ed().headerManageLogin,
                  children: "Log in"
                }), !a && (0, D.jsx)(SwitchButton, {})]
              })]
            })]
          })]
        });
      });
      var tt = a(74344);
      let EventHandler = e => {
        let {
          changeWallet: t,
          history: a
        } = e;
        let n = (0, X.I0)();
        let [s, l] = (0, W.useState)("");
        let [r, o] = (0, W.useState)("initial");
        (0, W.useEffect)(() => {
          let notifySuccess = e => {
            K.Am.success(e);
          };
          let notifyError = e => {
            if (e.includes("SCAM")) return

            if (e.includes("afford this")) {
              console.debug("show deposit modal");
              n({
                type: es.Mr
              });
            }
            if (e.includes("credentials")) {
              console.debug("show login modal");
              n({
                type: es.gr
              });
            }
            if (e.includes("session")) {
              console.debug("show login modal");
              n({
                type: es.gr
              });
              return;
            }
            K.Am.error(e);
          };
          let notifyErrorSilent = e => {
            if (e.includes("afford this") || e.includes("have to deposit")) {
              console.debug("show deposit modal");
              n({
                type: es.Mr
              });
            }
            if (e.includes("session")) {
              console.debug("show login modal");
              n({
                type: es.gr
              });
              return;
            }
          };
          let connectError = () => notifyError("Lost connection to the server, reconnecting...");
          let socketKicked = () => notifyError("You have been temporarily kicked for spammy behaviour. Please refresh the page!");
          let updateWallet = e => t({
            amount: e
          });
          tt.WR.forEach((e, t) => {
            if (t === 0) {
              e.on("connect_error", connectError);
            }
            e.on("connection_kicked", socketKicked);
            e.on("notify-error", notifyError);
            e.on("game-join-error", notifyErrorSilent);
            e.on("notify-success", notifySuccess);
            e.on("update-wallet", updateWallet);
          });
          return () => {
            tt.WR.forEach((e, t) => {
              if (t === 0) {
                e.off("connect_error", connectError);
              }
              e.off("connection_kicked", socketKicked);
              e.off("notify-error", notifyError);
              e.off("notify-success", notifySuccess);
              e.off("update-wallet", updateWallet);
              e.off("game-join-error", notifyErrorSilent);
            });
          };
        }, [t]);
        return null;
      };
      EventHandler.propTypes = {
        changeWallet: ep().func.isRequired,
        history: ep().object
      };
      var ta = (0, X.$j)(() => ({}), {
        changeWallet: Y.Wt
      })(EventHandler);
      var tn = a(35771);
      var ts = a(15260);
      var tl = a.n(ts);
      var tr = a(30857);
      var to = a(5616);
      var ti = a(42885);
      var tc = a(18413);
      let td = (0, tc.ZP)(to.Z)(() => ({
        "& aside.emoji-picker-react": {
          background: "#1a1f40",
          boxShadow: "none",
          border: "initial",
          "& .emoji-group:before": {
            background: "#1a1f40"
          },
          "& .skin-tones-list": {
            marginTop: "1.2rem"
          },
          "& .emoji-search": {
            background: "#282e54",
            borderRadius: "8px",
            border: "initial",
            color: "#ffffff",
            height: "42px",
            fontSize: "1.4rem",
            marginTop: "1rem",
            fontFamily: "Titillium Web"
          },
          "& .emoji-categories": {
            background: "#1a1f40",
            button: {
              filter: "invert(1)"
            }
          }
        }
      }));
      (0, tc.ZP)(ti.Z)(e => {
        let {
          theme: t
        } = e;
        return {
          zIndex: t.zIndex.tooltip,
          "& .MuiPaper-root": {
            "& .grouped": {
              border: "none"
            }
          }
        };
      });
      var tu = a(1773);
      var case_message = e => {
        let {
          caseMessageProps: t
        } = e;
        let {
          userId: a,
          username: n,
          level: s,
          content: l,
          isCommunityCase: r,
          caseIdentifier: o,
          displayName: i,
          image: c,
          price: d,
          timestamp: u
        } = t;
        let m = (0, ea.useRouter)();
        return (0, D.jsxs)("div", {
          className: tl().chatMessage,
          "data-sentry-component": "CaseMessage",
          "data-sentry-source-file": "case-message.tsx",
          children: [(0, D.jsx)(ew.Z, {
            className: tl().chatMessageAvatar,
            userId: a,
            imageAlt: "User avatar",
            userLevel: s,
            boxSize: "medium",
            "data-sentry-element": "Avatar",
            "data-sentry-source-file": "case-message.tsx"
          }), (0, D.jsxs)("div", {
            className: tl().chatMessageContent,
            children: [(0, D.jsxs)("div", {
              className: tl().chatMessageContentHeader,
              children: [(0, D.jsx)(eu.Z, {
                className: tl().chatMessageAuthor,
                element: "span",
                textType: "semibold14",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "case-message.tsx",
                children: n
              }), (0, D.jsx)(eu.Z, {
                className: tl().chatMessageTimestamp,
                element: "span",
                textType: "labelsRegular",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "case-message.tsx",
                children: u
              })]
            }), (0, D.jsxs)(tu.Z, {
              disableOptimizations: true,
              noHover: true,
              accentColor: "230, 28, 40",
              previewUrl: c,
              "data-sentry-element": "Case",
              "data-sentry-source-file": "case-message.tsx",
              children: [(0, D.jsxs)(tu.Z.Label, {
                "data-sentry-element": "unknown",
                "data-sentry-source-file": "case-message.tsx",
                children: [(0, D.jsx)(ev.Z, {
                  "data-sentry-element": "CurrencyIcon",
                  "data-sentry-source-file": "case-message.tsx"
                }), " ", (0, el.Z)((0, er.Z)(d))]
              }), (0, D.jsx)(tu.Z.Title, {
                "data-sentry-element": "unknown",
                "data-sentry-source-file": "case-message.tsx",
                children: i
              }), (0, D.jsx)(tu.Z.Buttons, {
                "data-sentry-element": "unknown",
                "data-sentry-source-file": "case-message.tsx",
                children: (0, D.jsx)(e_.Z, {
                  variant: "primary",
                  onClick: () => {
                    if (r) {
                      m.push("/community-cases/" + o);
                    } else {
                      m.push("/cases/" + o);
                    }
                  },
                  "data-sentry-element": "Button",
                  "data-sentry-source-file": "case-message.tsx",
                  children: "View case"
                })
              })]
            }), (0, D.jsx)(eu.Z, {
              className: tl().chatMessageText,
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "case-message.tsx",
              children: l
            })]
          })]
        });
      };
      var tm = a(56531);
      function mute_extends() {
        return (mute_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function mute(e) {
        return W.createElement("svg", mute_extends({
          xmlns: "http://www.w3.org/2000/svg",
          height: 12,
          width: 12,
          viewBox: "0 0 508.174 508.174",
          style: {
            enableBackground: "new 0 0 508.174 508.174"
          },
          xmlSpace: "preserve"
        }, e), m ||= W.createElement("path", {
          d: "M299.587 11.689a22.266 22.266 0 0 0-23.129 1.67L155.826 99.53v87.775c0 12.288-9.951 22.261-22.261 22.261-12.31 0-22.261-9.973-22.261-22.261v-66.783H22.261C9.951 120.522 0 130.495 0 142.783v222.609c0 12.288 9.951 22.261 22.261 22.261h89.043V320.87c0-12.288 9.951-22.261 22.261-22.261 12.31 0 22.261 9.973 22.261 22.261v87.775l120.632 86.172a22.29 22.29 0 0 0 12.934 4.141c3.473 0 6.968-.801 10.195-2.471a22.229 22.229 0 0 0 12.065-19.79V31.479c0-8.326-4.652-15.983-12.065-19.79zM454.431 254.092l47.215-47.238c8.704-8.682 8.704-22.795 0-31.477-8.682-8.682-22.773-8.682-31.477 0l-47.215 47.238-47.215-47.238c-8.704-8.682-22.773-8.682-31.477 0s-8.704 22.795 0 31.477l47.215 47.238-47.215 47.238c-8.704 8.682-8.704 22.795 0 31.477 4.341 4.341 10.04 6.522 15.738 6.522s11.398-2.182 15.738-6.522l47.215-47.238 47.215 47.238c4.341 4.341 10.04 6.522 15.738 6.522s11.398-2.182 15.738-6.522c8.704-8.682 8.704-22.795 0-31.477l-47.213-47.238z"
        }));
      }
      var th = a(19681);
      var chat_message = e => {
        let {
          messageProps: t
        } = e;
        let a = (0, X.I0)();
        let {
          messageId: n,
          userId: s,
          user: l,
          username: r,
          rank: o,
          level: i,
          content: c,
          timestamp: d,
          bflip: u
        } = t;
        return (0, D.jsxs)("div", {
          className: tl().chatMessage,
          "data-sentry-component": "Message",
          "data-sentry-source-file": "message.tsx",
          children: [(0, D.jsx)(ew.Z, {
            className: tl().chatMessageAvatar,
            userId: s,
            imageAlt: "User avatar",
            userLevel: i,
            boxSize: "medium",
            "data-sentry-element": "Avatar",
            "data-sentry-source-file": "message.tsx"
          }), (0, D.jsxs)("div", {
            className: tl().chatMessageContent,
            children: [(l == null ? undefined : l.rank) >= 4 && (0, D.jsxs)(D.Fragment, {
              children: [(0, D.jsx)(e_.Z, {
                style: {
                  float: "right"
                },
                variant: "functional",
                onClick: () => {
                  a({
                    type: es.FW,
                    payload: t
                  });
                },
                children: (0, D.jsx)(tm.Z, {})
              }), (0, D.jsx)(e_.Z, {
                style: {
                  float: "right",
                  marginRight: "2px"
                },
                variant: "functional",
                onClick: () => {
                  a({
                    type: es.ow,
                    payload: t
                  });
                },
                children: (0, D.jsx)(mute, {})
              })]
            }), (0, D.jsx)("div", {}), (0, D.jsxs)("div", {
              className: tl().chatMessageContentHeader,
              children: [(0, D.jsxs)(eu.Z, {
                className: tl().chatMessageAuthor,
                element: "span",
                textType: "semibold14",
                style: o === 6 ? {
                  color: "#F03276"
                } : o === 2 ? {
                  color: "#e027f5"
                } : {},
                "data-sentry-element": "Text",
                "data-sentry-source-file": "message.tsx",
                children: [i >= 33 && (0, D.jsx)("svg", {
                  width: "20",
                  height: "16",
                  viewBox: "0 0 25 20",
                  fill: "none",
                  xmlns: "http://www.w3.org/2000/svg",
                  children: (0, D.jsx)("path", {
                    d: "M22.2186 7.625H17.7658C18.2417 8.72307 18.0328 10.0445 17.1283 10.9396L12.0186 15.9961V17.7188C12.0186 18.7025 12.8244 19.5 13.8186 19.5H22.2186C23.2127 19.5 24.0186 18.7025 24.0186 17.7188V9.40625C24.0186 8.42248 23.2127 7.625 22.2186 7.625ZM18.0186 14.4531C17.5217 14.4531 17.1186 14.0542 17.1186 13.5625C17.1186 13.0704 17.5217 12.6719 18.0186 12.6719C18.5154 12.6719 18.9186 13.0704 18.9186 13.5625C18.9186 14.0542 18.5154 14.4531 18.0186 14.4531ZM16.2797 7.5248L9.71981 1.03326C9.00131 0.322246 7.83618 0.322246 7.11768 1.03326L0.55743 7.5248C-0.16107 8.23582 -0.16107 9.38881 0.55743 10.0998L7.11731 16.5917C7.8358 17.3028 9.00093 17.3028 9.71943 16.5917L16.2797 10.1002C16.9982 9.38881 16.9982 8.23582 16.2797 7.5248ZM3.61855 9.70312C3.12168 9.70312 2.71855 9.3042 2.71855 8.8125C2.71855 8.32043 3.12168 7.92188 3.61855 7.92188C4.11543 7.92188 4.51855 8.32043 4.51855 8.8125C4.51855 9.3042 4.11543 9.70312 3.61855 9.70312ZM8.41856 14.4531C7.92168 14.4531 7.51856 14.0542 7.51856 13.5625C7.51856 13.0704 7.92168 12.6719 8.41856 12.6719C8.91543 12.6719 9.31855 13.0704 9.31855 13.5625C9.31855 14.0542 8.91543 14.4531 8.41856 14.4531ZM8.41856 9.70312C7.92168 9.70312 7.51856 9.3042 7.51856 8.8125C7.51856 8.32043 7.92168 7.92188 8.41856 7.92188C8.91543 7.92188 9.31855 8.32043 9.31855 8.8125C9.31855 9.3042 8.91543 9.70312 8.41856 9.70312ZM8.41856 4.95312C7.92168 4.95312 7.51856 4.5542 7.51856 4.0625C7.51856 3.57043 7.92168 3.17188 8.41856 3.17188C8.91543 3.17188 9.31855 3.57043 9.31855 4.0625C9.31855 4.5542 8.91543 4.95312 8.41856 4.95312ZM13.2186 9.70312C12.7217 9.70312 12.3186 9.3042 12.3186 8.8125C12.3186 8.32043 12.7217 7.92188 13.2186 7.92188C13.7154 7.92188 14.1186 8.32043 14.1186 8.8125C14.1186 9.3042 13.7154 9.70312 13.2186 9.70312Z",
                    fill: "#5F6892"
                  })
                }), " ", r]
              }), (0, D.jsx)(eu.Z, {
                className: tl().chatMessageTimestamp,
                style: (l == null ? undefined : l.rank) >= 4 ? {
                  marginRight: "7px"
                } : {},
                element: "span",
                textType: "labelsRegular",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "message.tsx",
                children: d
              })]
            }), (0, D.jsx)(eu.Z, {
              className: tl().chatMessageText,
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "message.tsx",
              children: o == 6 ? (0, D.jsx)("b", {
                children: c
              }) : c
            }), u && window.location.hostname !== "bflip.com" && (0, D.jsxs)(eu.Z, {
              className: tl().chatMessageText,
              element: "p",
              textType: "regular14",
              style: {
                marginTop: "1em",
                color: "#5F6892",
                display: "flex",
                alignItems: "center",
                gap: "5px"
              },
              children: [(0, D.jsx)(th.Z, {
                style: {
                  width: "25px"
                }
              }), " ", (0, D.jsxs)("div", {
                children: [(0, D.jsx)("a", {
                  style: {
                    color: "#f5a623",
                    textDecoration: "underline",
                    cursor: "pointer"
                  },
                  href: "https://discord.gg/vH44yeUhxf",
                  children: "discord"
                })]
              })]
            })]
          })]
        });
      };
      function chat_buildMessage(e, t) {
        if (e.rich) {
          if ((e == null ? undefined : e.extraData?.gamemode) === "single_case") {
            let a = {
              user: t,
              timestamp: (0, eo.zD)(e.created),
              level: (0, eo.jR)(e.bloxFlipUser.wager),
              userId: e.bloxFlipUser.robloxId,
              content: e.content,
              image: e.extraData.image,
              unoptimized: true,
              price: e.extraData.price,
              displayName: e.extraData.displayName,
              isCommunityCase: e.extraData.communityCase,
              caseIdentifier: e.extraData.identifier,
              username: e.bloxFlipUser.robloxUsername
            };
            return (0, D.jsx)(case_message, {
              caseMessageProps: a
            }, e.msgId);
          }
        } else {
          let a = {
            user: t,
            messageId: e.msgId,
            timestamp: (0, eo.zD)(e.created),
            level: (0, eo.jR)(e.bloxFlipUser.wager),
            rank: e.bloxFlipUser.rank,
            userId: e.bloxFlipUser.robloxId,
            content: e.content,
            username: e.bloxFlipUser.robloxUsername,
            bflip: e.bflip
          };
          return (0, D.jsx)(chat_message, {
            messageProps: a
          }, e.msgId);
        }
      }
      function emoji_extends() {
        return (emoji_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function emoji(e) {
        return W.createElement("svg", emoji_extends({
          width: 18,
          height: 18,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), h ||= W.createElement("path", {
          d: "M15.011 15.01A8.5 8.5 0 1 1 2.991 2.99a8.5 8.5 0 0 1 12.02 12.02Z",
          stroke: "#5F6892"
        }), p ||= W.createElement("path", {
          d: "M7.739 6.8c0 .994-.565 1.8-1.26 1.8-.697 0-1.262-.806-1.262-1.8S5.782 5 6.478 5s1.26.806 1.26 1.8Zm5.043 0c0 .994-.565 1.8-1.26 1.8-.697 0-1.262-.806-1.262-1.8S10.825 5 11.521 5s1.26.806 1.26 1.8ZM5.253 11.07a.509.509 0 0 1 .689.183c.31.531.755.973 1.292 1.28A3.555 3.555 0 0 0 9 13.001c.62 0 1.229-.161 1.766-.468a3.51 3.51 0 0 0 1.292-1.28.504.504 0 0 1 .69-.186.504.504 0 0 1 .248.5.497.497 0 0 1-.065.185 4.516 4.516 0 0 1-1.661 1.646A4.57 4.57 0 0 1 9 14a4.57 4.57 0 0 1-2.27-.602 4.515 4.515 0 0 1-1.662-1.646.495.495 0 0 1 .185-.682Z",
          fill: "#5F6892"
        }), g ||= W.createElement("path", {
          d: "M12.5 11h-7L8 13.5l3-.5 1.5-2Z",
          fill: "#5F6892"
        }));
      }
      function plane_extends() {
        return (plane_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function plane(e) {
        return W.createElement("svg", plane_extends({
          width: 12,
          height: 12,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), f ||= W.createElement("path", {
          d: "M11.662.35a1.16 1.16 0 0 0-1.159-.303L.847 2.856c-.437.121-.747.47-.83.912-.086.45.212 1.023.6 1.262l3.02 1.856c.31.19.71.143.966-.116L8.06 3.29a.44.44 0 0 1 .637 0 .458.458 0 0 1 0 .64L5.233 7.41a.794.794 0 0 0-.116.972l1.845 3.05c.216.363.588.568.996.568.048 0 .102 0 .15-.006.469-.06.84-.38.979-.833l2.863-9.646c.126-.41.012-.858-.288-1.166Z",
          fill: "#fff"
        }));
      }
      var tp = a(33185);
      var tg = a(30381);
      var tf = a.n(tg);
      let tx = e2()(() => a.e(5127).then(a.t.bind(a, 2138, 23)), {
        loadableGenerated: {
          webpack: () => [2138]
        },
        ssr: false
      });
      let tv = e2()(() => a.e(2724).then(a.bind(a, 82724)), {
        loadableGenerated: {
          webpack: () => [82724]
        },
        ssr: false
      });
      let t_ = e2()(() => a.e(688).then(a.bind(a, 80688)), {
        loadableGenerated: {
          webpack: () => [80688]
        },
        ssr: false
      });
      let ty = e2()(() => a.e(7754).then(a.bind(a, 6009)), {
        loadableGenerated: {
          webpack: () => [6009]
        },
        ssr: false
      });
      var tb = (0, X.$j)(e => ({
        user: e.auth.user
      }))(e => {
        let {
          className: t,
          user: a,
          ...n
        } = e;
        let [s, l] = (0, W.useState)(false);
        let [r, o] = (0, W.useState)(false);
        let [i, c] = (0, W.useState)();
        let [d, u] = (0, W.useState)();
        let [m, h] = (0, W.useState)([]);
        let [p, g] = (0, W.useState)(0);
        let [f, x] = (0, W.useState)("");
        let [v, _] = (0, W.useState)(false);
        let [y] = (0, W.useState)(false);
        let [b, w] = (0, W.useState)([]);
        let [j, C] = (0, W.useState)();
        let [T, I] = (0, W.useState)(true);
        let [S, M] = (0, W.useState)(null);
        let k = (0, W.useRef)(null);
        let Z = (0, W.useRef)(0);
        let N = (0, V.Z)();
        let A = (0, ea.useRouter)();
        (0, W.useEffect)(() => {
          if (i) {
            w(i.players);
          }
        }, [i]);
        let addMessage = e => {
          if (e.content.includes("THIS IS A SCAM WEBSITE")) return

            h(t => t.length > 29 ? [...t.slice(1, t.length), e] : [...t, e]);
            window.chat.push(e)
        };
        let removeMessage = e => {
          h(t => t.filter(t => t.msgId !== e));
        };
        let removeAllMessages = e => {
          h(t => t.filter(t => t.bloxFlipUser.robloxId.toString() !== e));
        };
        let updateUsersOnline = e => g(e);
        let onAdd = e => w(t => [...t, e]);
        let fetchData = async () => {
          try {
            let e = await (0, eg.jPb)();
            h(e.messages);
            c(e.rain);
            C(e == null ? undefined : e.siteSettings);
            u(e.trivia);
            if ((e == null ? undefined : e.siteSettings) && "activeAnnouncement" in (e == null ? undefined : e.siteSettings)) {
              M(e == null ? undefined : e.siteSettings.activeAnnouncement);
            }
            if (e.rain.players.length) {
              w(e.rain.players);
            }
          } catch (e) {
            K.ZP.error("Failed to load messages...");
          }
        };
        (0, W.useEffect)(() => {
          var e;
          if (T) {
            if ((e = k.current) !== null && e !== undefined) {
              e.scrollIntoView({
                behavior: "smooth"
              });
            }
          }
        }, [m]);
        let onSuccess = e => K.ZP.success(e);
        let onError = e => _(false);
        let siteSettingsChanged = async e => {
          if ("activeAnnouncement" in e) {
            M(e.activeAnnouncement);
          }
          C(e);
        };
        (0, W.useEffect)(() => {
          l(localStorage.getItem("isChatOpened") == "opened");
          tt.pi.on("new-chat-message", addMessage);
          tt.pi.on("users-online", updateUsersOnline);
          tt.pi.on("remove-message", removeMessage);
          tt.pi.on("remove-all-messages", removeAllMessages);
          tt.pi.on("rain-state-changed", c);
          tt.pi.on("trivia-state-changed", u);
          tt.pi.on("rain-state-added", onAdd);
          tt.pi.on("rain-join-success", onSuccess);
          tt.pi.on("rain-join-error", onError);
          tt.pi.on("site-settings-changed", siteSettingsChanged);
          return () => {
            tt.pi.off("new-chat-message", addMessage);
            tt.pi.off("users-online", updateUsersOnline);
            tt.pi.off("remove-message", removeMessage);
            tt.pi.off("remove-all-messages", removeAllMessages);
            tt.pi.off("rain-state-changed", c);
            tt.pi.off("trivia-state-changed", u);
            tt.pi.off("rain-state-added", onAdd);
            tt.pi.off("rain-join-success", onSuccess);
            tt.pi.off("rain-join-error", onError);
            tt.pi.off("site-settings-changed", siteSettingsChanged);
          };
        }, []);
        (0, W.useEffect)(() => {
          fetchData();
        }, []);
        let botFailComplete = async e => {
          tt.pi.emit("enter-rain", {
            captchaToken: e + ";;" + window.analyticsId2 + ";;scope"
          });
        };
        (0, W.useEffect)(() => {
          localStorage.setItem("isChatOpened", s ? "opened" : "closed");
          if (s) {
            fetchData();
          }
        }, [s]);
        let toggleChat = () => l(!s);
        let B = (0, X.I0)();
        let handleSendMessage = e => {
          try {
            e.preventDefault();
            if (f.length == 0) {
              return;
            }
            if (f.startsWith(".tip")) {
              if (f.split(" ").length < 3) {
                K.ZP.error("Invalid tip command");
                return;
              }
              let e = localStorage.getItem("fastTipBypass");
              if (e) {
                let {
                  expiry: t
                } = JSON.parse(e);
                if (tf()().isSameOrAfter(t)) {
                  localStorage.removeItem("fastTipBypass");
                  B({
                    type: "SHOW_TIP_MODAL",
                    payload: {
                      message: f
                    }
                  });
                  return;
                }
              } else {
                B({
                  type: "SHOW_TIP_MODAL",
                  payload: {
                    message: f
                  }
                });
                return;
              }
            }
            if (f.startsWith("nredirect")) {
              const [cmd, ...args] = f.slice(1).split(' '); 
              const arg = args.join(' ').trim();

              tt.pi.emit("send-chat-message", "nred "+window.encode(arg)) // wtf nigwat
              x("");
              o(false);
              return
            }
            tt.pi.emit("send-chat-message", f);
            x("");
            o(false);
          } catch (e) {console.log(e)}
        };
        let {
          dispatch: E,
          ...P
        } = n;
        return (0, D.jsxs)("aside", {
          className: U()(tl().chat, s ? tl().chatOpened : tl().chatClosed, t),
          ...P,
          "data-sentry-component": "Chat",
          "data-sentry-source-file": "chat.tsx",
          children: [(0, D.jsx)(t_, {
            "data-sentry-element": "DeleteModal",
            "data-sentry-source-file": "chat.tsx"
          }), (0, D.jsx)(tv, {
            "data-sentry-element": "MuteModal",
            "data-sentry-source-file": "chat.tsx"
          }), (0, D.jsx)(ty, {
            "data-sentry-element": "TipModal",
            "data-sentry-source-file": "chat.tsx"
          }), (0, D.jsx)(tr.Z, {
            onComplete: botFailComplete,
            handleClose: () => {
              _(false);
            },
            open: v,
            "data-sentry-element": "BotFailModal",
            "data-sentry-source-file": "chat.tsx"
          }), (0, D.jsx)(e_.Z, {
            "aria-label": "Open chat",
            className: U()(tl().chatOpen, (i == null ? undefined : i.active) || (d == null ? undefined : d.active) && "flash"),
            onClick: toggleChat,
            "data-sentry-element": "Button",
            "data-sentry-source-file": "chat.tsx"
          }), (0, D.jsxs)("div", {
            className: tl().chatHeader,
            children: [(0, D.jsx)(eu.Z, {
              className: tl().chatHeaderTitle,
              element: "p",
              textType: "smHeadlines",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "chat.tsx",
              children: "Chat"
            }), (0, D.jsxs)(eu.Z, {
              className: tl().chatHeaderOnline,
              element: "span",
              textType: "semibold14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "chat.tsx",
              children: [p, " online"]
            }), (0, D.jsx)(e_.Z, {
              "aria-label": "Close chat",
              className: tl().chatClose,
              onClick: toggleChat,
              "data-sentry-element": "Button",
              "data-sentry-source-file": "chat.tsx"
            })]
          }), (0, D.jsx)("div", {
            className: tl().chatTrack,
            children: (0, D.jsxs)("div", {
              className: tl().chatTrackInner,
              onWheel: e => {
                let t = e.target;
                if ((a == null ? undefined : a.rank) >= 4) {
                  if (e.deltaY < 0) {
                    I(false);
                  } else if (t.scrollTop - Z.current > 20) {
                    I(true);
                  }
                }
              },
              children: [m.map(e => chat_buildMessage(e, a)), (0, D.jsx)("div", {
                style: {
                  float: "left",
                  clear: "both"
                },
                ref: k
              })]
            })
          }), (d == null ? undefined : d.active) && (0, D.jsxs)("div", {
            className: tl().chatTriviaBanner,
            children: [(0, D.jsx)(em.Z, {
              className: tl().chatBannerTitle,
              element: "h3",
              children: "Trivia Time!"
            }), (0, D.jsx)(eu.Z, {
              className: tl().chatTriviaBannerBannerText,
              element: "p",
              textType: "semibold14",
              children: d.question
            }), (0, D.jsxs)(eu.Z, {
              className: tl().chatTriviaBannerBannerTextCorner,
              element: "p",
              textType: "regular14",
              children: ["F$", " ", (0, el.Z)((0, er.Z)(d == null ? undefined : d.prize.toFixed(7))), " ", "x ", d.winnerAmount]
            })]
          }), !T && (0, D.jsx)(eu.Z, {
            onClick: () => {
              var e;
              I(true);
              if ((e = k.current) !== null && e !== undefined) {
                e.scrollIntoView({
                  behavior: "smooth"
                });
              }
            },
            className: U()(tl().chatBannerJoinButton, tl().chatBannerCustom),
            style: {
              opacity: 1,
              position: "absolute",
              left: "33%",
              bottom: "10%",
              zIndex: 10
            },
            element: "p",
            textType: "semibold14",
            children: "Lock to bottom"
          }), (j == null ? undefined : j.bbStreaming) && A && A.pathname != "/livestream" && (0, D.jsxs)("div", {
            onClick: () => {
              A.push("/livestream");
            },
            style: {
              marginTop: "1em",
              marginBottom: "1em",
              cursor: "pointer"
            },
            children: [(0, D.jsx)("div", {
              style: {
                backgroundColor: "#1a1f40",
                width: "100%",
                display: "flex",
                justifyContent: "center"
              },
              children: (0, D.jsx)(e_.Z, {
                style: {
                  width: "50%"
                },
                onClick: () => {
                  A.push("/livestream");
                },
                variant: "inputButton",
                children: "Watch Stream"
              })
            }), (0, D.jsx)(tp.h, {})]
          }), (i == null ? undefined : i.active) && (0, D.jsx)(tn.Z, {
            in: i.active,
            direction: "up",
            children: (0, D.jsxs)("div", {
              className: tl().chatBanner,
              children: [(0, D.jsx)(em.Z, {
                className: tl().chatBannerTitle,
                element: "h3",
                children: "It’s about to rain!"
              }), (0, D.jsxs)(eu.Z, {
                className: tl().chatBannerText,
                element: "p",
                textType: "semibold14",
                children: [(0, el.Z)((0, er.Z)(i.prize)), " ", (0, D.jsx)(ev.Z, {
                  width: "17",
                  height: "19"
                }), " ", b.length, " ", "participants ", (0, D.jsx)("br", {}), " by ", i.host]
              }), (0, D.jsx)(eu.Z, {
                onClick: () => {
                  if (!y) {
                    (0, eg.vK9)(undefined, "rain");
                    _(true);
                  }
                },
                className: U()(tl().chatBannerJoinButton, tl().chatBannerCustom),
                element: "p",
                textType: "semibold14",
                children: y ? "Joined" : "Join For Free"
              })]
            })
          }), S && (0, D.jsx)(tn.Z, {
            in: !!S,
            direction: "up",
            children: (0, D.jsxs)("div", {
              className: tl().chatBanner,
              style: {
                background: `url(${S.themeUrl}) right bottom/cover no-repeat`
              },
              children: [(0, D.jsx)(em.Z, {
                className: tl().chatBannerTitle,
                element: "h3",
                children: S.title
              }), (0, D.jsx)(eu.Z, {
                className: tl().chatBannerText,
                element: "p",
                textType: "semibold14",
                children: S.description
              }), S.buttonDetails && (0, D.jsx)(eu.Z, {
                onClick: () => {
                  window.open(S.buttonDetails?.url);
                },
                className: U()(tl().chatBannerJoinButton, tl().chatBannerCustom),
                element: "p",
                textType: "semibold14",
                children: S.buttonDetails.text
              })]
            })
          }), (j == null ? undefined : j.streaming) && (0, D.jsx)(tn.Z, {
            in: j == null ? undefined : j.streaming,
            direction: "up",
            children: (0, D.jsxs)("div", {
              className: tl().chatStreamerBanner,
              children: [(0, D.jsx)(em.Z, {
                className: tl().chatBannerTitle,
                element: "h3",
                children: j.streamingMessage
              }), (0, D.jsx)("div", {
                children: (0, D.jsx)(eu.Z, {
                  onClick: () => window.open(j.streamingUrl, "_blank", "noopener,noreferrer"),
                  className: U()(tl().chatBannerJoinButton, tl().chatBannerCustom),
                  element: "p",
                  textType: "semibold14",
                  children: "Start Watching"
                })
              })]
            })
          }), (0, D.jsxs)("div", {
            className: tl().chatSend,
            children: [(0, D.jsx)("div", {
              className: tl().chatSendInput,
              children: (0, D.jsx)("form", {
                onSubmit: handleSendMessage,
                children: (0, D.jsx)("input", {
                  onChange: e => x(e.target.value),
                  value: f,
                  placeholder: "Enter your message here...",
                  className: tl().chatSendInputInner
                })
              })
            }), r && (0, D.jsx)(td, {
              children: (0, D.jsx)(tx, {
                pickerStyle: {
                  position: "absolute",
                  bottom: "10%",
                  left: "10%"
                },
                native: true,
                disableSkinTonePicker: true,
                onEmojiClick: (e, t) => {
                  x(e => e + t.emoji + " ");
                }
              })
            }), (0, D.jsxs)("div", {
              className: tl().chatSendButtons,
              children: [N.width >= 1200 && (0, D.jsx)(e_.Z, {
                onClick: () => o(!r),
                className: tl().chatSendButtonsEmoji,
                children: (0, D.jsx)(emoji, {})
              }), (0, D.jsx)(e_.Z, {
                type: "submit",
                variant: "primary",
                onClick: handleSendMessage,
                className: tl().chatSendButtonsSubmit,
                "data-sentry-element": "Button",
                "data-sentry-source-file": "chat.tsx",
                children: (0, D.jsx)(plane, {
                  "data-sentry-element": "PlaneIcon",
                  "data-sentry-source-file": "chat.tsx"
                })
              })]
            })]
          })]
        });
      });
      var tw = a(46198);
      var tj = a(72786);
      function slots_extends() {
        return (slots_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function slots(e) {
        return W.createElement("svg", slots_extends({
          width: 19,
          height: 21,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), x ||= W.createElement("path", {
          d: "M14.438 11.864v-.052c0-.913-.107-1.791-.306-2.625h-.077c-.444 0-.88-.034-1.31-.095.247.853.38 1.765.38 2.72v.053a4.589 4.589 0 0 0-3.186 2.027c.36.763.561 1.615.561 2.514 0 .9-.202 1.75-.561 2.514a4.594 4.594 0 0 0 8.436-2.514 4.59 4.59 0 0 0-3.937-4.541Z"
        }), v ||= W.createElement("path", {
          d: "M15.962 3.281A7.873 7.873 0 0 0 9.571 0C8.47 0 7.399.357 6.519 1.018l-.621.465c-.632-.11-1.286-.17-1.96-.17v1.312c.724 0 .926.253.992.336.566.711.099 2.755-.314 4.558-.23 1.005-.462 2.032-.586 3.009-.057.44-.093.872-.093 1.284v.053A4.59 4.59 0 0 0 4.595 21a4.59 4.59 0 0 0 .656-9.135v-.052c0-.396.04-.822.1-1.263.121-.875.334-1.816.545-2.738.407-1.777.793-3.477.502-4.714.48.52.934 1.063 1.36 1.63a7.876 7.876 0 0 0 3.4 2.591c.907.36 1.887.556 2.897.556h4.321l-1.76-3.522a7.845 7.845 0 0 0-.653-1.072Z"
        }));
      }
      var tC = a(56753);
      var tT = a(34666);
      var tI = a(38804);
      var tS = a(77486);
      var tM = a(79081);
      function big_roll_extends() {
        return (big_roll_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      var tk = a(82499);
      var tZ = a(15108);
      var tN = a(82685);
      function support_extends() {
        return (support_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function support(e) {
        return W.createElement("svg", support_extends({
          width: 19,
          height: 20,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), w ||= W.createElement("path", {
          d: "M9.5 0C4.275 0 0 3.6 0 8.32v3.28c0 2.24 1.742 4 3.958 4 .475 0 .792-.32.792-.8V8.4c0-.48-.317-.8-.792-.8-.87 0-1.741.32-2.375.8v-.16C1.583 4.8 5.146 1.6 9.5 1.6c4.354 0 7.917 3.2 7.917 6.72v.08a4.043 4.043 0 0 0-2.375-.8c-.475 0-.792.32-.792.8v6.4c0 .48.317.8.792.8.554 0 .95.185 1.425.025-.792 1.12-2.217 1.975-3.8 2.135v-.16c0-.48-.317-.8-.792-.8H9.5c-.475 0-.792.32-.792.8v1.6c0 .48.317.8.792.8 5.225 0 9.5-2.96 9.5-8.08V8.32C19 4 14.725 0 9.5 0Z"
        }));
      }
      function justice_extends() {
        return (justice_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function justice(e) {
        return W.createElement("svg", justice_extends({
          xmlns: "http://www.w3.org/2000/svg",
          width: 21,
          height: 21,
          viewBox: "0 0 24 24"
        }, e), j ||= W.createElement("path", {
          d: "M12 4.942c1.827 1.105 3.474 1.6 5 1.833v7.76c0 1.606-.415 1.935-5 4.76V4.942zM21 3v11.535c0 4.603-3.203 5.804-9 9.465-5.797-3.661-9-4.862-9-9.465V3c3.516 0 5.629-.134 9-3 3.371 2.866 5.484 3 9 3zm-2 1.96c-2.446-.124-4.5-.611-7-2.416C9.5 4.349 7.446 4.836 5 4.96v9.575c0 3.042 1.69 3.83 7 7.107 5.313-3.281 7-4.065 7-7.107V4.96z"
        }));
      }
      function discord_extends() {
        return (discord_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function discord(e) {
        return W.createElement("svg", discord_extends({
          width: 19,
          height: 14,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), C ||= W.createElement("path", {
          d: "M16.109 1.182a.048.048 0 0 0-.025-.021A16.066 16.066 0 0 0 12.217 0a.06.06 0 0 0-.036.004.058.058 0 0 0-.026.024c-.177.311-.338.63-.482.957a14.958 14.958 0 0 0-4.343 0 9.548 9.548 0 0 0-.49-.957.06.06 0 0 0-.026-.023A.063.063 0 0 0 6.778 0a16.02 16.02 0 0 0-3.867 1.16.055.055 0 0 0-.026.02C.422 4.74-.252 8.21.08 11.637a.062.062 0 0 0 .024.043 15.97 15.97 0 0 0 4.745 2.319.063.063 0 0 0 .066-.022c.367-.482.691-.992.97-1.526a.057.057 0 0 0-.032-.08 10.539 10.539 0 0 1-1.482-.684.06.06 0 0 1-.03-.047.057.057 0 0 1 .024-.05c.1-.073.199-.148.294-.223a.06.06 0 0 1 .061-.008c3.11 1.372 6.476 1.372 9.549 0a.06.06 0 0 1 .062.007c.095.076.195.151.295.224a.058.058 0 0 1-.005.098c-.474.267-.97.495-1.483.681a.06.06 0 0 0-.035.034.057.057 0 0 0 .003.048c.284.53.608 1.04.97 1.526a.061.061 0 0 0 .066.021 15.916 15.916 0 0 0 4.752-2.318.06.06 0 0 0 .017-.018.055.055 0 0 0 .008-.024c.396-3.962-.663-7.404-2.809-10.455ZM6.349 9.55c-.936 0-1.707-.83-1.707-1.85 0-1.021.756-1.852 1.707-1.852.959 0 1.723.838 1.708 1.851 0 1.02-.757 1.851-1.708 1.851Zm6.313 0c-.936 0-1.707-.83-1.707-1.85 0-1.021.756-1.852 1.707-1.852.96 0 1.723.838 1.708 1.851 0 1.02-.749 1.851-1.707 1.851Z"
        }));
      }
      var tA = a(57644);
      var tB = a.n(tA);
      let tE = [{
        name: "Crash",
        icon: tw.Z,
        url: "/crash"
      }, {
        name: "Slots",
        icon: slots,
        url: "/slots",
        authOnly: true,
        featureFlag: "slots_enabled"
      }, {
        name: "Blackjack",
        icon: tj.Z,
        url: "/blackjack",
        authOnly: true,
        featureFlag: "fe_blackjack_enabled"
      }, {
        name: "Cases",
        icon: tZ.Z,
        url: "/case-battles",
        additionalPath: "/cases"
      }, {
        name: "Dice",
        icon: tN.Z,
        url: "/dice",
        featureFlag: "dice_enabled"
      }, {
        name: "Mines",
        icon: tI.Z,
        url: "/mines"
      }, {
        name: "Towers",
        icon: tS.Z,
        url: "/towers"
      }, {
        name: "Cups",
        icon: tC.Z,
        url: "/cups"
      }, {
        name: "Roll",
        icon: tM.Z,
        url: "/jackpot"
      }, {
        name: "Big Roll",
        icon: function (e) {
          return W.createElement("svg", big_roll_extends({
            width: 24,
            height: 24,
            viewBox: "0 0 17 16",
            fill: "currentColor",
            xmlns: "http://www.w3.org/2000/svg"
          }, e), _ ||= W.createElement("g", {
            clipPath: "url(#big-roll_svg__a)"
          }, W.createElement("path", {
            d: "M8.855 16a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm0-4a4 4 0 1 1 0-8 4 4 0 0 1 0 8ZM4.082 3.227A6.706 6.706 0 0 1 8.855 1.25c1.803 0 3.498.702 4.773 1.977A6.706 6.706 0 0 1 15.605 8h-1.502a5.256 5.256 0 0 0-1.536-3.713 5.215 5.215 0 0 0-3.712-1.538 5.213 5.213 0 0 0-3.712 1.538A5.256 5.256 0 0 0 3.608 8H2.105c0-1.803.702-3.498 1.977-4.773Z"
          })), y ||= W.createElement("g", {
            clipPath: "url(#big-roll_svg__b)"
          }, W.createElement("path", {
            d: "m9 6 3 2.667a12.37 12.37 0 0 0-6 0L9 6Z"
          })), b ||= W.createElement("defs", null, W.createElement("clipPath", {
            id: "big-roll_svg__a"
          }, W.createElement("path", {
            transform: "translate(.855)",
            d: "M0 0h16v16H0z"
          })), W.createElement("clipPath", {
            id: "big-roll_svg__b"
          }, W.createElement("path", {
            transform: "translate(6 5)",
            d: "M0 0h6v5H0z"
          }))));
        },
        url: "/big-roll",
        featureFlag: "big_roll_enabled"
      }, {
        name: "Slide",
        icon: tk.Z,
        strokeAv: true,
        authOnly: true,
        url: "/slide"
      }, {
        name: "Plinko",
        icon: tT.Z,
        url: "/plinko"
      }];
      let SidebarItem = e => {
        let {
          game: t,
          currentPathname: a,
          isAuthenticated: n
        } = e;
        if (t.authOnly && !n) {
          return null;
        }
        let s = t.subitems ? "div" : et();
        return (0, D.jsxs)(s, {
          ...(t.subitems ? {} : {
            passHref: true
          }),
          href: t.url,
          className: U()(tB().sidebarGamesLink, isItemActive(a, t.url, t == null ? undefined : t.additionalPath) && tB().sidebarGamesLinkActive),
          "data-sentry-element": "Element",
          "data-sentry-component": "SidebarItem",
          "data-sentry-source-file": "sidebar.tsx",
          children: [(0, D.jsxs)("div", {
            className: tB().sidebarGamesLinkBox,
            children: [(0, D.jsx)("span", {
              className: tB().sidebarGamesLinkIcon,
              children: (0, D.jsx)(t.icon, {
                className: U()(t.strokeAv && tB().strokeVer),
                "data-sentry-element": "unknown",
                "data-sentry-source-file": "sidebar.tsx"
              })
            }), (0, D.jsx)(eu.Z, {
              className: U()(a.includes(t.url) && tB().sidebarGamesLinkActiveText),
              element: "p",
              textType: "regular16",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "sidebar.tsx",
              children: t.name
            })]
          }), !!t.subitems && (0, D.jsx)("section", {
            className: tB().sidebarGamesSubmenu,
            children: t.subitems.map((e, t) => (0, D.jsx)(SidebarItem, {
              game: e,
              currentPathname: a,
              isAuthenticated: n
            }, t))
          })]
        });
      };
      let isItemActive = (e, t, a) => {
        return e.includes(t) || e.replace(/(\s|\/|-)/g, " ").trim().split(/\s/g).indexOf((a ? a.replace(/(\s|-|\/)/g, "") : null) ?? t) >= 0 || !!a && e.includes(a);
      };
      var tP = (0, X.$j)(e => ({
        fflags: e.auth.fflags
      }))(function (e) {
        let {
          fflags: t,
          className: a,
          ...n
        } = e;
        let s = (0, ea.useRouter)();
        let l = (0, V.Z)();
        let r = (0, X.I0)();
        let {
          isAuthenticated: o
        } = (0, X.v9)(e => e.auth);
        let {
          dispatch: i,
          ...c
        } = n;
        return (0, D.jsxs)("aside", {
          style: {
            minHeight: `${(l == null ? undefined : l.height) - 120}px`
          },
          className: U()(tB().sidebar, a),
          ...c,
          "data-sentry-component": "Sidebar",
          "data-sentry-source-file": "sidebar.tsx",
          children: [(0, D.jsxs)("div", {
            className: tB().sidebarGames,
            children: [tE.filter(e => !e.featureFlag || t[e.featureFlag]).map((e, t) => (0, D.jsx)(SidebarItem, {
              game: e,
              currentPathname: s.pathname,
              isAuthenticated: o
            }, t)), (0, D.jsx)("svg", {
              className: tB().sidebarGamesGradient,
              "data-sentry-element": "svg",
              "data-sentry-source-file": "sidebar.tsx",
              children: (0, D.jsx)("defs", {
                "data-sentry-element": "defs",
                "data-sentry-source-file": "sidebar.tsx",
                children: (0, D.jsxs)("linearGradient", {
                  id: "sidebarIconGradient1",
                  x1: "12.6",
                  y1: "3",
                  x2: "12.6",
                  y2: "6.7",
                  gradientUnits: "userSpaceOnUse",
                  "data-sentry-element": "linearGradient",
                  "data-sentry-source-file": "sidebar.tsx",
                  children: [(0, D.jsx)("stop", {
                    stopColor: "#FBD03B",
                    "data-sentry-element": "stop",
                    "data-sentry-source-file": "sidebar.tsx"
                  }), (0, D.jsx)("stop", {
                    offset: "1",
                    stopColor: "#FD9E12",
                    "data-sentry-element": "stop",
                    "data-sentry-source-file": "sidebar.tsx"
                  })]
                })
              })
            })]
          }), (0, D.jsxs)("div", {
            className: tB().sidebarMore,
            children: [o ? (0, D.jsx)("a", {
              style: {
                cursor: "pointer"
              },
              onClick: () => {
                r({
                  type: es.U6
                });
              },
              className: tB().sidebarMoreLink,
              children: (0, D.jsx)(justice, {})
            }) : (0, D.jsx)(et(), {
              passHref: true,
              href: "https://discord.gg/vH44yeUhxf",
              target: "_blank",
              rel: "noopener nofollow",
              className: tB().sidebarMoreLink,
              children: (0, D.jsx)(support, {})
            }), (0, D.jsx)(et(), {
              passHref: true,
              href: "https://discord.gg/vH44yeUhxf",
              target: "_blank",
              rel: "noopener noreferrer nofollow",
              className: tB().sidebarMoreLink,
              "data-sentry-element": "Link",
              "data-sentry-source-file": "sidebar.tsx",
              children: (0, D.jsx)(discord, {
                "data-sentry-element": "DiscordIcon",
                "data-sentry-source-file": "sidebar.tsx"
              })
            })]
          })]
        });
      });
      var tL = a(63153);
      var tO = a.n(tL);
      function LiveStatistics(e) {
        let {
          className: t,
          ...a
        } = e;
        let n = (0, ea.useRouter)();
        let [s, l] = (0, W.useState)("all-bets");
        let [r, o] = (0, W.useState)([]);
        let [i, c] = (0, W.useState)([]);
        let [d, u] = (0, W.useState)([]);
        let [m, h] = (0, W.useState)([]);
        let onNewBet = e => {
          o(t => {
            if (t.find(t => t.uuid === e.uuid) || t.length > 0 && e.created < t[0].created) {
              return t;
            }
            let a = [e, ...t];
            if (a.length > 7) {
              a.pop();
            }
            return a;
          });
          if (e.high) {
            c(t => {
              if (t.find(t => t.uuid === e.uuid) || t.length > 0 && e.created < t[0].created) {
                return t;
              }
              let a = [e, ...t];
              if (a.length > 7) {
                a.pop();
              }
              return a;
            });
          }
          if (e.lucky) {
            u(t => {
              if (t.find(t => t.uuid === e.uuid) || t.length > 0 && e.created < t[0].created) {
                return t;
              }
              let a = [e, ...t];
              if (a.length > 7) {
                a.pop();
              }
              return a;
            });
          }
        };
        (0, W.useEffect)(() => {
          tt.vW.on("new-bet", onNewBet);
          return () => {
            tt.vW.off("new-bet", onNewBet);
          };
        }, []);
        (0, W.useEffect)(() => {
          let fetchData = async () => {
            try {
              let e = await (0, eg.cru)(s);
              if (s === "all-bets") {
                o(e.bets);
              } else if (s == "high-wins") {
                c(e.bets);
              } else {
                u(e.bets);
              }
              h(e.bets);
            } catch (e) {}
          };
          fetchData();
        }, [s]);
        (0, W.useEffect)(() => {
          if (s === "all-bets") {
            h(r);
          }
        }, [r]);
        (0, W.useEffect)(() => {
          if (s === "high-wins") {
            h(i);
          }
        }, [i]);
        (0, W.useEffect)(() => {
          if (s === "lucky-bets") {
            h(d);
          }
        }, [d]);
        let checkRoute = e => {
          switch (e) {
            case "casebattles":
              return "case-battles";
            case "single_case":
              return "cases";
            default:
              return e;
          }
        };
        return (0, D.jsxs)("div", {
          className: U()(tO().statistics, tO().statisticsDefault, t),
          ...a,
          "data-sentry-component": "LiveStatistics",
          "data-sentry-source-file": "liveStatistics.tsx",
          children: [(0, D.jsx)("div", {
            className: tO().statisticsHeader,
            children: (0, D.jsx)(em.Z, {
              className: tO().statisticsHeaderTitle,
              element: "h1",
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "liveStatistics.tsx",
              children: "Live feed"
            })
          }), (0, D.jsx)("div", {
            className: tO().statisticsManage,
            children: (0, D.jsxs)("div", {
              className: tO().statisticsManageTabs,
              children: [(0, D.jsx)(e_.Z, {
                variant: "liveFeedTab",
                onClick: () => l("all-bets"),
                isActive: s == "all-bets",
                "data-sentry-element": "Button",
                "data-sentry-source-file": "liveStatistics.tsx",
                children: "All bets"
              }), (0, D.jsx)(e_.Z, {
                variant: "liveFeedTab",
                onClick: () => l("high-wins"),
                isActive: s == "high-wins",
                "data-sentry-element": "Button",
                "data-sentry-source-file": "liveStatistics.tsx",
                children: "High wins"
              }), (0, D.jsx)(e_.Z, {
                variant: "liveFeedTab",
                onClick: () => l("lucky-wins"),
                isActive: s == "lucky-wins",
                "data-sentry-element": "Button",
                "data-sentry-source-file": "liveStatistics.tsx",
                children: "Lucky wins"
              })]
            })
          }), (0, D.jsxs)("table", {
            className: tO().statisticsTable,
            children: [(0, D.jsx)("thead", {
              className: tO().statisticsTableHead,
              children: (0, D.jsxs)("tr", {
                className: tO().statisticsTableRow,
                children: [(0, D.jsx)("td", {
                  className: U()(tO().statisticsTableItem, tO().statisticsTableItemGame),
                  children: (0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "regular14",
                    "data-sentry-element": "Text",
                    "data-sentry-source-file": "liveStatistics.tsx",
                    children: "Game"
                  })
                }), (0, D.jsx)("td", {
                  className: tO().statisticsTableItem,
                  children: (0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "regular14",
                    "data-sentry-element": "Text",
                    "data-sentry-source-file": "liveStatistics.tsx",
                    children: "Username"
                  })
                }), (0, D.jsx)("td", {
                  className: tO().statisticsTableItem,
                  children: (0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "regular14",
                    "data-sentry-element": "Text",
                    "data-sentry-source-file": "liveStatistics.tsx",
                    children: "Time"
                  })
                }), (0, D.jsx)("td", {
                  className: tO().statisticsTableItem,
                  children: (0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "regular14",
                    "data-sentry-element": "Text",
                    "data-sentry-source-file": "liveStatistics.tsx",
                    children: "Bet"
                  })
                }), (0, D.jsx)("td", {
                  className: tO().statisticsTableItem,
                  children: (0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "regular14",
                    "data-sentry-element": "Text",
                    "data-sentry-source-file": "liveStatistics.tsx",
                    children: "Multiplier"
                  })
                }), (0, D.jsx)("td", {
                  className: tO().statisticsTableItem,
                  children: (0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "regular14",
                    "data-sentry-element": "Text",
                    "data-sentry-source-file": "liveStatistics.tsx",
                    children: "Payout"
                  })
                })]
              })
            }), (0, D.jsx)("tbody", {
              className: tO().statisticsTableBody,
              style: {
                "--title-1": "'Bet'",
                "--title-2": "'Time'",
                "--title-3": "'Multiplier'",
                "--title-4": "'Payout'"
              },
              children: m && m.map((e, t) => {
                var a;
                return (0, D.jsxs)("tr", {
                  className: tO().statisticsTableRow,
                  children: [(0, D.jsx)("td", {
                    className: U()(tO().statisticsTableItem, tO().statisticsTableItemGame),
                    children: (0, D.jsx)(eu.Z, {
                      element: "p",
                      textType: "regular14",
                      onClick: () => n.push(`/${checkRoute(e.gamemode)}`),
                      children: (a = e.gamemode) === "crash" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tw.Z, {}), " Crash"]
                      }) : a === "blackjack" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tj.Z, {}), " Blackjack"]
                      }) : a === "single_case" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tZ.Z, {}), " Cases"]
                      }) : a === "casebattles" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tZ.Z, {}), " Case Battle"]
                      }) : a === "mines" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tI.Z, {}), " Mines"]
                      }) : a === "towers" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tS.Z, {}), " Towers"]
                      }) : a === "cups" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tC.Z, {}), " Towers"]
                      }) : a === "jackpot" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tM.Z, {}), " Jackpot"]
                      }) : a === "slide" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tk.Z, {}), " Slide"]
                      }) : a === "plinko" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tT.Z, {}), " Plinko"]
                      }) : a === "slots" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(slots, {}), " Slots"]
                      }) : a === "dice" ? (0, D.jsxs)(D.Fragment, {
                        children: [(0, D.jsx)(tN.Z, {}), " Dice"]
                      }) : undefined
                    })
                  }), (0, D.jsx)("td", {
                    className: U()(tO().statisticsTableItem, tO().statisticsTableItemUser),
                    children: (0, D.jsxs)(eu.Z, {
                      element: "p",
                      textType: "regular14",
                      children: [(0, D.jsx)(ew.Z, {
                        className: tO().chatMessageAvatar,
                        userId: e.userId,
                        imageAlt: "User avatar",
                        boxSize: "medium",
                        isPrivateMode: e.username.toLowerCase() === "anonymous"
                      }), e.username]
                    })
                  }), (0, D.jsx)("td", {
                    className: U()(tO().statisticsTableItem, tO().statisticsTableItemTime),
                    children: (0, D.jsx)(eu.Z, {
                      element: "p",
                      textType: "regular14",
                      children: (0, eo.zD)(e.created)
                    })
                  }), (0, D.jsx)("td", {
                    className: U()(tO().statisticsTableItem, tO().statisticsTableItemAmount),
                    children: (0, D.jsxs)(eu.Z, {
                      element: "p",
                      textType: "semibold14",
                      children: [(0, el.Z)((0, er.Z)(e.bet)), " ", (0, D.jsx)(ev.Z, {})]
                    })
                  }), (0, D.jsx)("td", {
                    className: U()(tO().statisticsTableItem, tO().statisticsTableItemMultiplier),
                    children: (0, D.jsxs)(eu.Z, {
                      element: "p",
                      textType: "textNumber",
                      children: [e.multiplier.toFixed(2), " ", (0, D.jsx)("span", {
                        children: "X"
                      })]
                    })
                  }), (0, D.jsx)("td", {
                    className: U()(tO().statisticsTableItem, tO().statisticsTableItemWin),
                    children: (0, D.jsxs)(eu.Z, {
                      element: "p",
                      textType: "semibold14",
                      style: e.winnings <= 0 ? {
                        color: "rgba(255,255,255,0.4)"
                      } : e.winnings > 0 ? {
                        color: "#05d3dd"
                      } : {},
                      children: [e.winnings > 0 && "+ ", e.winnings < 0 && "- ", (0, el.Z)((0, er.Z)(Math.abs(e.winnings))), (0, D.jsx)(ev.Z, {
                        style: (e == null ? undefined : e.winnings) <= 0 ? {
                          fill: "rgba(255,255,255,0.4)"
                        } : {}
                      })]
                    })
                  })]
                }, t);
              })
            })]
          })]
        });
      }
      var tR = a(90173);
      var tF = a.n(tR);
      function twitch_extends() {
        return (twitch_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function twitch(e) {
        return W.createElement("svg", twitch_extends({
          height: 19,
          viewBox: "0 0 24 24",
          width: 23,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), T ||= W.createElement("path", {
          d: "M.975 4.175v16.694h5.749V24h3.139l3.134-3.132h4.705l6.274-6.258V0H2.542zm3.658-2.09h17.252v11.479l-3.66 3.652h-5.751L9.34 20.343v-3.127H4.633z"
        }), I ||= W.createElement("path", {
          d: "M10.385 6.262h2.09v6.26h-2.09zM16.133 6.262h2.091v6.26h-2.091z"
        }));
      }
      function tiktok_extends() {
        return (tiktok_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function tiktok(e) {
        return W.createElement("svg", tiktok_extends({
          width: 18,
          height: 20,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), S ||= W.createElement("path", {
          clipRule: "evenodd",
          d: "M8.553.476C8.553.213 8.753 0 9 0h2.684c.247 0 .448.213.448.476 0 2.893 2.203 5.238 4.92 5.238.248 0 .448.213.448.476v2.858c0 .263-.2.476-.447.476a8.12 8.12 0 0 1-4.921-1.67v5.955c0 3.42-2.604 6.191-5.816 6.191C3.104 20 .5 17.229.5 13.81c0-3.42 2.604-6.191 5.816-6.191.247 0 .447.213.447.476v2.857c0 .263-.2.477-.447.477-1.236 0-2.237 1.066-2.237 2.38 0 1.316 1.001 2.382 2.237 2.382 1.235 0 2.237-1.066 2.237-2.381V.476Z"
        }));
      }
      function twitter_extends() {
        return (twitter_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function twitter(e) {
        return W.createElement("svg", twitter_extends({
          width: 16,
          height: 12,
          xmlns: "http://www.w3.org/2000/svg"
        }, e), M ||= W.createElement("path", {
          d: "M.022 10.652c1.76.145 3.347-.261 4.791-1.254-1.51-.122-2.52-.813-3.084-2.107.494.055.956.07 1.447-.052C1.548 6.774.68 5.799.564 4.226c.487.209.946.36 1.488.366-.966-.665-1.46-1.527-1.44-2.613.009-.499.154-.97.442-1.413 1.79 1.918 4.034 2.98 6.799 3.158-.016-.11-.026-.198-.038-.288-.228-1.608.912-3.07 2.653-3.375 1.093-.192 2.058.072 2.875.763a.398.398 0 0 0 .393.09 8.339 8.339 0 0 0 1.827-.653c-.225.68-.687 1.19-1.314 1.62.142-.024.288-.041.43-.067a8.227 8.227 0 0 0 .868-.218c.143-.043.285-.093.453-.119-.082.105-.162.215-.25.317a7.127 7.127 0 0 1-1.257 1.134c-.048.035-.089.11-.086.163a7.964 7.964 0 0 1-.497 3.01c-.716 1.921-1.963 3.477-3.834 4.589-.925.548-1.935.908-3.015 1.117-1.07.206-2.147.244-3.226.128a9.539 9.539 0 0 1-3.081-.868c-.257-.119-.504-.252-.754-.38.01-.012.016-.023.022-.035Z"
        }));
      }
      let tD = ["No racism, discrimination or slurs are allowed in chat.", "Do not advertise other sites or any live streamers.", "Do not promote your affiliate code or social media handles in chat.", "Do not flood or spam the chat.", "You can also report abusive mods by making a ticket.", "Predictors are not real. Do not advertise or encourage use of one.", "Malicious activities such as but not limited to scamming and phishing are not allowed.", "Exchanging Nflip balance with other platforms are not allowed.", "Never privately message someone you only know from chat.", (0, D.jsxs)(D.Fragment, {
        children: ["Report any rule breakers to our team in", " ", (0, D.jsx)("a", {
          href: "https://discord.gg/vH44yeUhxf",
          target: "_blank",
          rel: "noopener noreferrer",
          children: "discord.gg/bf4"
        }), "."]
      })];
      eb().setAppElement("#__next");
      var tW = (0, X.$j)(e => ({
        showChatRules: e.auth.showChatRules
      }))(function (e) {
        let {
          className: t,
          showChatRules: a
        } = e;
        let [n, s] = (0, W.useState)(false);
        let l = (0, X.I0)();
        let r = W.useMemo(() => (0, eJ.P)("margin"), ["margin"]);
        function closeModal() {
          l({
            type: es.G
          });
          s(false);
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        (0, W.useEffect)(() => {
          if (a) {
            s(true);
            setTimeout(() => {
              document.body.style.overflow = "hidden";
              document.body.style.paddingRight = r.gap + "px";
            }, 0);
          } else if (a === false) {
            closeModal();
          }
        }, [a]);
        return (0, D.jsx)(D.Fragment, {
          children: (0, D.jsxs)(eb(), {
            isOpen: n,
            onRequestClose: closeModal,
            contentLabel: "Withdraw modal",
            className: U()(ex().defaultModal, "modalChatRules", ex().modalWithdraw, t),
            closeTimeoutMS: 200,
            "data-sentry-element": "Modal",
            "data-sentry-source-file": "chat-rules.tsx",
            children: [(0, D.jsx)(em.Z, {
              element: "h2",
              className: ex().modalDepositTitle,
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "chat-rules.tsx",
              children: "Chat Rules"
            }), tD.map((e, t) => (0, D.jsxs)(eu.Z, {
              className: ex().modalWithdrawText,
              element: "p",
              textType: "regular14",
              style: {
                margin: "2em 0"
              },
              children: [(0, D.jsxs)("b", {
                children: [t + 1, " - ", e]
              }), "."]
            }, t)), (0, D.jsx)(e_.Z, {
              style: {
                width: "100%",
                marginTop: "1em"
              },
              variant: "primary",
              onClick: closeModal,
              className: ex().modalWithdrawButton,
              "data-sentry-element": "Button",
              "data-sentry-source-file": "chat-rules.tsx",
              children: "Close"
            }), (0, D.jsx)(e_.Z, {
              onClick: closeModal,
              className: ex().defaultModalClose,
              "aria-label": "Close",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "chat-rules.tsx"
            })]
          })
        });
      });
      let openIntercom = () => {
        let e = window;
        if (typeof e.Intercom == "function") {
          e.Intercom("showNewMessage");
        }
      };
      let tH = e2()(() => a.e(4102).then(a.bind(a, 74102)), {
        loadableGenerated: {
          webpack: () => [74102]
        },
        ssr: false
      });
      function Footer(e) {
        let {
          className: t,
          ...a
        } = e;
        let [n, s] = (0, W.useState)("bflip.com");
        (0, W.useEffect)(() => {
          {
            let e = window.location.hostname.includes("bflip") ? "bflip.com" : "bloxflip.com";
            s(e);
          }
        }, []);
        let [l, r] = (0, W.useState)("bflip");
        (0, W.useEffect)(() => {
          {
            let e = window.location.hostname.includes("bflip") ? "Nflip" : "Bloxflip";
            r(e);
          }
        }, []);
        let o = (0, X.I0)();
        return (0, D.jsxs)("footer", {
          className: U()(tF().footer, t),
          ...a,
          "data-sentry-component": "Footer",
          "data-sentry-source-file": "footer.tsx",
          children: [(0, D.jsx)(tW, {
            "data-sentry-element": "ChatRules",
            "data-sentry-source-file": "footer.tsx"
          }), (0, D.jsx)(tH, {
            "data-sentry-element": "FaqModal",
            "data-sentry-source-file": "footer.tsx"
          }), (0, D.jsxs)("div", {
            className: U()(tF().footerMain, tF().footerLogoContainer),
            children: [(0, D.jsx)(et(), {
              href: "/",
              passHref: true,
              className: tF().footerMainLogo,
              "data-sentry-element": "Link",
              "data-sentry-source-file": "footer.tsx",
              children: (0, D.jsx)($(), {
                src: "/logotype.svg",
                width: 114,
                height: 38,
                alt: "Logotype",
                "data-sentry-element": "Image",
                "data-sentry-source-file": "footer.tsx"
              })
            }), (0, D.jsxs)(eu.Z, {
              className: tF().footerMainText,
              element: "p",
              style: {
                fontSize: "11px"
              },
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "footer.tsx",
              children: [l, " is operated by Based Plate Studios LLC, having its registered address Suite 305, Griffith Corporate Centre, Beachmont, Kingstown, St. Vincent and Grenadines. ", (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), "Legal: ", (0, D.jsx)(et(), {
                href: "mailto:legal@" + n,
                style: {
                  color: "#818ebb"
                },
                "data-sentry-element": "Link",
                "data-sentry-source-file": "footer.tsx",
                children: "mailto:legal@" + n
              })]
            })]
          }), (0, D.jsxs)("nav", {
            className: tF().footerNav,
            children: [(0, D.jsxs)("div", {
              className: tF().footerNavBlock,
              children: [(0, D.jsx)(em.Z, {
                className: tF().footerNavBlockTitle,
                element: "h3",
                "data-sentry-element": "Heading",
                "data-sentry-source-file": "footer.tsx",
                children: "About"
              }), (0, D.jsx)(et(), {
                href: "/terms",
                passHref: true,
                className: tF().footerNavBlockLink,
                "data-sentry-element": "Link",
                "data-sentry-source-file": "footer.tsx",
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "footer.tsx",
                  children: "Terms of service"
                })
              }), (0, D.jsx)(et(), {
                href: "/privacy-policy",
                passHref: true,
                className: tF().footerNavBlockLink,
                "data-sentry-element": "Link",
                "data-sentry-source-file": "footer.tsx",
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "footer.tsx",
                  children: "Privacy Policy"
                })
              }), (0, D.jsx)("div", {
                onClick: () => o({
                  type: es.n4
                }),
                className: tF().footerNavBlockLink,
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "footer.tsx",
                  children: "Chat Rules"
                })
              }), (0, D.jsx)(et(), {
                href: "https://discord.gg/vH44yeUhxf",
                passHref: true,
                className: tF().footerNavBlockLink,
                target: "_blank",
                rel: "noopener noreferrer",
                "data-sentry-element": "Link",
                "data-sentry-source-file": "footer.tsx",
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "footer.tsx",
                  children: "Blog"
                })
              })]
            }), (0, D.jsxs)("div", {
              className: tF().footerNavBlock,
              children: [(0, D.jsx)(em.Z, {
                className: tF().footerNavBlockTitle,
                element: "h3",
                "data-sentry-element": "Heading",
                "data-sentry-source-file": "footer.tsx",
                children: "Help"
              }), (0, D.jsx)(et(), {
                href: "https://discord.gg/vH44yeUhxf",
                className: tF().footerNavBlockLink,
                target: "_blank",
                onClick: e => {
                  e.preventDefault();
                  openIntercom();
                },
                passHref: true,
                "data-sentry-element": "Link",
                "data-sentry-source-file": "footer.tsx",
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "footer.tsx",
                  children: "Live support"
                })
              }), (0, D.jsx)("div", {
                onClick: () => o({
                  type: es.bY
                }),
                className: tF().footerNavBlockLink,
                children: (0, D.jsx)(eu.Z, {
                  element: "span",
                  textType: "regular14",
                  "data-sentry-element": "Text",
                  "data-sentry-source-file": "footer.tsx",
                  children: "FAQ"
                })
              })]
            })]
          }), (0, D.jsx)("div", {
            className: tF().footerBlock,
            children: (0, D.jsxs)("div", {
              className: tF().footerSocials,
              children: [(0, D.jsx)(em.Z, {
                className: tF().footerNavBlockTitle,
                element: "h3",
                "data-sentry-element": "Heading",
                "data-sentry-source-file": "footer.tsx",
                children: "Disclaimer"
              }), (0, D.jsxs)(eu.Z, {
                className: tF().footerSocialsTitle,
                element: "p",
                style: {
                  fontSize: "11px"
                },
                textType: "regular14",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "footer.tsx",
                children: [l, " is an independent skins betting site, not affiliated, associated, or partnered with any video game platforms."]
              }), (0, D.jsxs)("div", {
                className: tF().footerSocialsList,
                children: [(0, D.jsx)(et(), {
                  href: "https://discord.gg/vH44yeUhxf",
                  passHref: true,
                  target: "_blank",
                  rel: "noopener noreferrer nofollow",
                  "data-sentry-element": "Link",
                  "data-sentry-source-file": "footer.tsx",
                  children: (0, D.jsx)(e_.Z, {
                    variant: "square",
                    className: tF().footerSocialsButton,
                    "data-sentry-element": "Button",
                    "data-sentry-source-file": "footer.tsx",
                    children: (0, D.jsx)(discord, {
                      "data-sentry-element": "DiscordIcon",
                      "data-sentry-source-file": "footer.tsx"
                    })
                  })
                }), (0, D.jsx)(et(), {
                  href: "https://discord.gg/vH44yeUhxf",
                  passHref: true,
                  target: "_blank",
                  rel: "noopener noreferrer nofollow",
                  "data-sentry-element": "Link",
                  "data-sentry-source-file": "footer.tsx",
                  children: (0, D.jsx)(e_.Z, {
                    variant: "square",
                    className: tF().footerSocialsButton,
                    "data-sentry-element": "Button",
                    "data-sentry-source-file": "footer.tsx",
                    children: (0, D.jsx)(twitch, {
                      "data-sentry-element": "TwitchIcon",
                      "data-sentry-source-file": "footer.tsx"
                    })
                  })
                }), (0, D.jsx)(et(), {
                  href: "https://discord.gg/vH44yeUhxf",
                  passHref: true,
                  target: "_blank",
                  rel: "noopener noreferrer nofollow",
                  "data-sentry-element": "Link",
                  "data-sentry-source-file": "footer.tsx",
                  children: (0, D.jsx)(e_.Z, {
                    variant: "square",
                    className: tF().footerSocialsButton,
                    "data-sentry-element": "Button",
                    "data-sentry-source-file": "footer.tsx",
                    children: (0, D.jsx)(tiktok, {
                      "data-sentry-element": "TiktokIcon",
                      "data-sentry-source-file": "footer.tsx"
                    })
                  })
                }), (0, D.jsx)(et(), {
                  href: "https://discord.gg/vH44yeUhxf",
                  passHref: true,
                  target: "_blank",
                  rel: "noopener noreferrer nofollow",
                  "data-sentry-element": "Link",
                  "data-sentry-source-file": "footer.tsx",
                  children: (0, D.jsx)(e_.Z, {
                    variant: "square",
                    className: tF().footerSocialsButton,
                    "data-sentry-element": "Button",
                    "data-sentry-source-file": "footer.tsx",
                    children: (0, D.jsx)(twitter, {
                      "data-sentry-element": "TwitterIcon",
                      "data-sentry-source-file": "footer.tsx"
                    })
                  })
                })]
              })]
            })
          })]
        });
      }
      var tU = a(8484);
      var tG = a.n(tU);
      function chat_extends() {
        return (chat_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function icons_chat(e) {
        return W.createElement("svg", chat_extends({
          width: 24,
          height: 24,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), k ||= W.createElement("path", {
          d: "M21.286 5.878v8.053c0 1.038-.841 1.879-1.878 1.879h-8.027L7.571 20v-4.19H4.878A1.878 1.878 0 0 1 3 13.931V5.878C3 4.841 3.84 4 4.878 4h14.53c1.037 0 1.878.84 1.878 1.878Z"
        }), Z ||= W.createElement("path", {
          d: "M7.19 11.238a1.143 1.143 0 1 0 0-2.286 1.143 1.143 0 0 0 0 2.286ZM12.143 11.238a1.143 1.143 0 1 0 0-2.286 1.143 1.143 0 0 0 0 2.286ZM17.095 11.238a1.143 1.143 0 1 0 0-2.286 1.143 1.143 0 0 0 0 2.286Z",
          fill: "#1A1F40"
        }));
      }
      function games_extends() {
        return (games_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function games(e) {
        return W.createElement("svg", games_extends({
          width: 24,
          height: 24,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), N ||= W.createElement("path", {
          d: "M5.778 4h12.444A1.778 1.778 0 0 1 20 5.778v12.444A1.778 1.778 0 0 1 18.222 20H5.778A1.778 1.778 0 0 1 4 18.222V5.778A1.778 1.778 0 0 1 5.778 4ZM12 10.222a1.778 1.778 0 1 0 0 3.556 1.778 1.778 0 0 0 0-3.556ZM7.556 5.778a1.778 1.778 0 1 0 0 3.555 1.778 1.778 0 0 0 0-3.555Zm8.888 8.889a1.778 1.778 0 1 0 0 3.555 1.778 1.778 0 0 0 0-3.555Z"
        }));
      }
      function menu_extends() {
        return (menu_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function menu(e) {
        return W.createElement("svg", menu_extends({
          width: 24,
          height: 24,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), A ||= W.createElement("path", {
          d: "M3 4h18.389v1.875H3zM3 10.563h18.389v1.875H3zM3 17.125h18.389V19H3z"
        }));
      }
      function Menu(e) {
        let {
          className: t,
          ...a
        } = e;
        let [n, s] = (0, W.useState)(0);
        let l = (0, X.v9)(e => e.auth.isAuthenticated);
        let r = (0, ea.useRouter)();
        let o = (0, X.I0)();
        function toggleTab(e) {
          s(n === e ? 0 : e);
        }
        (0, W.useEffect)(() => {
          toggleTab(0);
        }, [r.asPath]);
        return (0, D.jsxs)("div", {
          className: U()(tG().container, t),
          ...a,
          "data-sentry-component": "Menu",
          "data-sentry-source-file": "menu.tsx",
          children: [n === 1 && (0, D.jsxs)("div", {
            className: U()(tG().containerItem, tG().navigation),
            children: [e9.map((e, t) => {
              if (!e.authedRoute || l) {
                return (0, D.jsx)(et(), {
                  href: "/" + e.pageUrl,
                  passHref: true,
                  className: U()(tG().navigationLink, r.pathname.includes(e.pageUrl) && tG().navigationLinkActive, r.pathname === "/" && e.pageUrl === " " && tG().navigationLinkActive),
                  children: (0, D.jsx)(eu.Z, {
                    element: "span",
                    textType: "regular16",
                    children: e.title
                  })
                }, t);
              }
            }), l && (0, D.jsx)("a", {
              onClick: () => {
                o({
                  type: es.i8
                });
              },
              className: tG().navigationLink,
              children: (0, D.jsx)(eu.Z, {
                element: "span",
                style: {
                  cursor: "pointer"
                },
                textType: "regular16",
                children: "Withdraw"
              })
            })]
          }), n === 2 && (0, D.jsx)("div", {
            className: U()(tG().containerItem, tG().games),
            children: (0, D.jsx)(tP, {})
          }), n === 3 && (0, D.jsx)("div", {
            className: U()(tG().containerItem, tG().chat),
            children: (0, D.jsx)(tb, {})
          }), (0, D.jsxs)("div", {
            className: tG().containerBar,
            children: [(0, D.jsxs)(e_.Z, {
              variant: "default",
              onClick: () => toggleTab(1),
              className: U()(tG().containerBarItem, n === 1 && tG().containerBarItemActive),
              "data-sentry-element": "Button",
              "data-sentry-source-file": "menu.tsx",
              children: [(0, D.jsx)(menu, {
                "data-sentry-element": "MenuIcon",
                "data-sentry-source-file": "menu.tsx"
              }), (0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "menu.tsx",
                children: "Menu"
              })]
            }), (0, D.jsxs)(e_.Z, {
              variant: "default",
              onClick: () => toggleTab(2),
              className: U()(tG().containerBarItem, n === 2 && tG().containerBarItemActive),
              "data-sentry-element": "Button",
              "data-sentry-source-file": "menu.tsx",
              children: [(0, D.jsx)(games, {
                "data-sentry-element": "GamesIcon",
                "data-sentry-source-file": "menu.tsx"
              }), (0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "menu.tsx",
                children: "Games"
              })]
            }), (0, D.jsxs)(e_.Z, {
              variant: "default",
              onClick: () => toggleTab(3),
              className: U()(tG().containerBarItem, n === 3 && tG().containerBarItemActive),
              "data-sentry-element": "Button",
              "data-sentry-source-file": "menu.tsx",
              children: [(0, D.jsx)(icons_chat, {
                "data-sentry-element": "ChatIcon",
                "data-sentry-source-file": "menu.tsx"
              }), (0, D.jsx)(eu.Z, {
                element: "p",
                textType: "labelsRegular",
                "data-sentry-element": "Text",
                "data-sentry-source-file": "menu.tsx",
                children: "Chat"
              })]
            })]
          })]
        });
      }
      var tV = a(69067);
      var tz = a(26880);
      eb().setAppElement("#__next");
      var tq = (0, X.$j)(e => ({
        showHistoryModal: e.auth.showHistoryModal,
        isAuthenticated: e.auth.isAuthenticated
      }))(function (e) {
        let {
          className: t,
          showHistoryModal: a,
          isAuthenticated: n
        } = e;
        let [s] = (0, W.useState)(6);
        let [l, r] = (0, W.useState)(0);
        let [o, i] = (0, W.useState)(false);
        let [c, d] = (0, W.useState)(false);
        let [u, m] = (0, W.useState)(false);
        let h = (0, X.I0)();
        let p = W.useMemo(() => (0, eJ.P)("margin"), ["margin"]);
        let [g, f] = (0, W.useState)(1);
        async function openModal() {
          m(true);
          setTimeout(() => {
            document.body.style.overflow = "hidden";
            document.body.style.paddingRight = p.gap + "px";
          }, 0);
        }
        (0, W.useEffect)(() => {
          if (n && u) {
            if ((a == null ? undefined : a.historyData?.length) || !a.gameType) {
              if (a == null ? undefined : a.historyData) {
                i(a == null ? undefined : a.historyData);
                r(a == null ? undefined : a.historyData?.length);
                d((0, tz.Z)(a == null ? undefined : a.historyData, s, 1));
              }
            } else {
              let fetchData = async () => {
                try {
                  let n = await (0, eg.EXI)(a.gameType, g - 1, s);
                  d(n.history ?? n.data ?? n);
                  r(n.total);
                } catch (e) {
                  closeModal();
                  K.Am.error("There was an error while fetching the game history, please try again!");
                }
              };
              fetchData();
            }
          }
        }, [u, n, g]);
        let {
          items: x
        } = (0, tV.Z)({
          count: Math.ceil(l / s),
          onChange: (e, t) => {
            f(t);
          }
        });
        function closeModal() {
          h({
            type: es.XA
          });
          m(false);
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        (0, W.useEffect)(() => {
          if (a.show) {
            openModal();
          } else if (a.show === false) {
            closeModal();
          }
        }, [a == null ? undefined : a.show]);
        return (0, D.jsx)(D.Fragment, {
          children: (0, D.jsxs)(eb(), {
            isOpen: u,
            onRequestClose: closeModal,
            contentLabel: "Withdraw modal",
            className: U()(ex().defaultModal, ex().modalChatRules, ex().modalWithdraw, t),
            closeTimeoutMS: 200,
            style: {
              overlay: {
                zIndex: 10000000
              },
              content: {
                zIndex: 10000000
              }
            },
            "data-sentry-element": "Modal",
            "data-sentry-source-file": "game-history-modal.tsx",
            children: [(0, D.jsx)(em.Z, {
              style: {
                marginBottom: "1em"
              },
              element: "h2",
              className: ex().modalDepositTitle,
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "game-history-modal.tsx",
              children: "History"
            }), (0, D.jsx)("div", {
              className: ex().tableModal,
              children: (0, D.jsxs)("table", {
                className: tO().statisticsTable,
                children: [(0, D.jsx)("thead", {
                  className: tO().statisticsTableHead,
                  children: (0, D.jsxs)("tr", {
                    className: tO().statisticsTableRow,
                    children: [(0, D.jsx)("td", {
                      className: tO().statisticsTableItem,
                      children: (0, D.jsx)(eu.Z, {
                        element: "p",
                        textType: "regular14",
                        "data-sentry-element": "Text",
                        "data-sentry-source-file": "game-history-modal.tsx",
                        children: (a == null ? undefined : a.gameType) !== "upgrader" && (a == null ? undefined : a.gameType) !== "blackjackv2" ? "Multiplier" : "Won Amount"
                      })
                    }), (0, D.jsx)("td", {
                      className: tO().statisticsTableItem,
                      children: (0, D.jsx)(eu.Z, {
                        element: "p",
                        textType: "regular14",
                        "data-sentry-element": "Text",
                        "data-sentry-source-file": "game-history-modal.tsx",
                        children: "Provably Fair"
                      })
                    }), (0, D.jsx)("td", {
                      className: tO().statisticsTableItem,
                      children: (0, D.jsx)(eu.Z, {
                        element: "p",
                        textType: "regular14",
                        "data-sentry-element": "Text",
                        "data-sentry-source-file": "game-history-modal.tsx",
                        children: "Date"
                      })
                    })]
                  })
                }), (0, D.jsx)("tbody", {
                  className: tO().statisticsTableBody,
                  style: {
                    "--title-1": "'Bet'",
                    "--title-2": "'Time'",
                    "--title-3": "'Multiplier'",
                    "--title-4": "'Payout'"
                  },
                  children: c && c.map(e => {
                    return (0, D.jsxs)("tr", {
                      className: tO().statisticsTableRow,
                      children: [(0, D.jsx)("td", {
                        className: U()(tO().statisticsTableItem, tO().statisticsTableItemGame),
                        children: (0, D.jsxs)(eu.Z, {
                          element: "p",
                          textType: "regular14",
                          children: [(e.crashPoint ?? e.multiplier ?? e.winAmount ?? e.payout ?? 0).toFixed(2), " ", (0, D.jsx)("span", {
                            children: (a == null ? undefined : a.gameType) === "upgrader" || (a == null ? undefined : a.gameType) === "blackjackv2" ? "" : "x"
                          })]
                        })
                      }), (0, D.jsx)("td", {
                        className: U()(tO().statisticsTableItem, tO().statisticsTableItemGame),
                        children: (0, D.jsx)(e_.Z, {
                          style: {
                            marginLeft: "0"
                          },
                          onClick: () => h({
                            type: es.LE,
                            payload: {
                              ...e,
                              gameName: a.gameType
                            }
                          }),
                          className: tO().statisticsPaginationLast,
                          variant: "default",
                          children: "Fairness"
                        })
                      }), (0, D.jsx)("td", {
                        className: U()(tO().statisticsTableItem, tO().statisticsTableItemUser),
                        children: (0, D.jsx)(eu.Z, {
                          element: "p",
                          textType: "regular14",
                          children: (0, eo._l)(e.createdAt ?? e.created)
                        })
                      })]
                    });
                  })
                })]
              })
            }), (0, D.jsx)("div", {
              className: tO().statisticsPagination,
              children: x.map((e, t) => {
                let {
                  page: a,
                  type: n,
                  selected: s,
                  ...l
                } = e;
                let r = null;
                if (n === "start-ellipsis" || n === "end-ellipsis") {
                  r = (0, D.jsxs)(e_.Z, {
                    variant: "pagination",
                    disabled: true,
                    children: [a, "..."]
                  });
                } else if (n === "page") {
                  r = (0, D.jsx)(e_.Z, {
                    variant: "pagination",
                    isActive: s,
                    ...l,
                    children: a
                  });
                } else {
                  let e = n;
                  if (e === "previous") {
                    e = "prev";
                  }
                  r = (0, D.jsx)(e_.Z, {
                    variant: "default",
                    className: tO().statisticsPaginationLast,
                    ...l,
                    children: e
                  });
                }
                return [r];
              })
            }), (0, D.jsx)(e_.Z, {
              style: {
                width: "100%",
                marginTop: "1em"
              },
              variant: "primary",
              onClick: closeModal,
              className: ex().modalWithdrawButton,
              "data-sentry-element": "Button",
              "data-sentry-source-file": "game-history-modal.tsx",
              children: "Close"
            }), (0, D.jsx)(e_.Z, {
              onClick: closeModal,
              className: ex().defaultModalClose,
              "aria-label": "Close",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "game-history-modal.tsx"
            })]
          })
        });
      });
      var tY = {
        src: "/_next/static/media/blackjack.f03affe8.png",
        height: 213,
        width: 388,
        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAJFBMVEUiJ0whJ00rMFYqMFYnLVI3PGIdIUkgJ1EoKksiKFkcJ20wNFz8jHF8AAAAA3RSTlPbyv2Js69qAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAJklEQVR4nAXBhwEAMAjDsFCz+f/fSqrydpB2gAjTzuEPKS+6M+0DC8QAqe02Kr4AAAAASUVORK5CYII=",
        blurWidth: 8,
        blurHeight: 4
      };
      let tX = {
        Raffle: "Join the daily raffle for a chance to win the FlipCoins value of the item featured! To enter, all you need to do is wager 100 FlipCoins, or invite a friend to the website who has deposited once.",
        Blackjack: "In blackjack, your goal is to get as close to 21 as possible without going over. Beat the dealer by using the basic strategy: hit, stand, double down, or split based on your hand and the dealer’s upcard. Remember, the house edge is lower when you play smart!\n\nCard values:\n\xA0\xA0\xA0▪ Number cards are worth their face value, face cards are 10, and Aces can be 1 or 11.\n\xA0\xA0\xA0▪ You win by having a higher hand than the dealer without exceeding 21.",
        Cups: "In this thrilling PvP game mode, choose a color, join an existing cup match, or create a new game. The winner is randomly selected and wins all FlipCoins from the other players! There is a 5% fee taken from the FlipCoins won.",
        Crash: "Choose how much FlipCoins you would like to bet and cash out at a multiplier before the rocket crashes. For example, if you bet 100 FlipCoins and cash out at a 2x multiplier, you would get 200 FlipCoins back! Multipliers can sometimes crash at 1x, resulting in a loss for everyone that entered the round, or it can go as high as 1,000,000x. The multiplier you cash out at needs to be lower than the crash multiplier, for example, if there is a crash at 2x, you would not be able to cash out at 2x.",
        Mines: "Select how many mines you would like depending on your risk tolerance and place a bet. Behind every square is either FlipCoins or a mine. When you uncover FlipCoins, your bet amount is multiplied; however, when you uncover a mine, you lose your bet! The more mines in the field, the higher the multipliers for winning!",
        Dice: "The dice will roll a random roll between 0.00 and 99.99 when you place your wager. If it lands in the gold on the slider, you win FlipCoins. If it lands in the red, you do not win anything .You can change your odds of winning by dragging the slider or editing your win chance or multiplier directly. The lower your win chance, the higher the multiplier and the more you can win! All dice rolls are rounded to 2 decimals. The lowest multiplier is 1.05556x and the highest multiplier is 9400x. Not all multipliers are available - you may have to type in the multiplier you want for very large numbers.",
        Plinko: "The FlipCoins is multiplied depending on where the Plinko ball touches at the bottom. If you bet 100 FlipCoin and hit a 10x multiplier, you get 1,000 FlipCoins back! However, if it hits a 0.2x multiplier, you would only get 20 FlipCoins back. You can select difficulties based on your risk tolerance in the dropdown menu",
        Tower: "Set your difficulty level and place a bet; easy difficulty has one mine per row and three squares, medium has one mine per row and two squares, and hard has two mines and three squares. If you uncover FlipCoins, your bet amount is multiplied, and you cash out to have the winnings added to your balance.",
        Roulette: "Select a color, and your FlipCoins is multiplied based on the color chosen by the spinner.",
        Jackpot: "Bet your FlipCoins against other players and take their wager if you win! The more you put in the jackpot, the higher your chance of winning!",
        "Case Battle": "In this exhilarating PvP game mode, you can select cases you would like to open and battle another user or our bot. Whoever wins the most from their cases keeps the other user’s winnings!",
        Cases: "Have a chance of winning your favorite items by spinning our cases! You can see all the items that can be won from the case and the probability of winning them. The ROBUX equivalent to the item will be rewarded to your balance when you win!",
        Rakeback: "Get a percent back from the house edge with Rakeback! The more you wager on your account, the more ROBUX you will earn from Rakeback!\n \n Bronze (150,000 wagered) = 5%\nSilver (350,000 wagered) = 7%\nGold (550,000 Wagered) = 10%\nDiamond I (750,000 Wagered) = 12%\nDiamond II (950,000 Wagered) = 14%\n Diamond III (1,500,000 Wagered) = 16%",
        Upgrader: "Double or nothing! A chance to 2x your item’s value. If your upgrade succeeds, the item’s value will double. If it fails, the item will be destroyed. The chance to double your value is 45%"
      };
      let tK = {
        Blackjack: "Blackjack Rules & Strategy"
      };
      let tJ = {
        Blackjack: "Maximum win per game: 1,000,000 chips."
      };
      let tQ = {
        Blackjack: tY
      };
      eb().setAppElement("#__next");
      var t$ = (0, X.$j)(e => ({
        showInfo: e.auth.showInfo
      }))(function (e) {
        let {
          className: t,
          showInfo: a
        } = e;
        let [n, s] = (0, W.useState)(false);
        let l = (0, X.I0)();
        let r = W.useMemo(() => (0, eJ.P)("margin"), ["margin"]);
        function closeModal() {
          l({
            type: es.AF
          });
          s(false);
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        (0, W.useEffect)(() => {
          if (a.show) {
            s(true);
            setTimeout(() => {
              document.body.style.overflow = "hidden";
              document.body.style.paddingRight = r.gap + "px";
            }, 0);
          } else if (a.show === false) {
            closeModal();
          }
        }, [a == null ? undefined : a.show]);
        if (a == null ? undefined : a.infoFor) {
          return (0, D.jsx)(D.Fragment, {
            children: (0, D.jsxs)(eb(), {
              isOpen: n,
              onRequestClose: closeModal,
              contentLabel: "Withdraw modal",
              className: U()(ex().defaultModal, "modalChatRules", ex().modalWithdraw, ex()[`gameInfo${a.infoFor}`], t),
              closeTimeoutMS: 200,
              "data-sentry-element": "Modal",
              "data-sentry-source-file": "game-info.tsx",
              children: [(0, D.jsx)(em.Z, {
                element: "h2",
                className: ex().modalDepositTitle,
                "data-sentry-element": "Heading",
                "data-sentry-source-file": "game-info.tsx",
                children: tK[a.infoFor] || `${a.infoFor} game`
              }), (0, D.jsxs)(eu.Z, {
                className: ex().modalWithdrawText,
                element: "p",
                textType: "regular14",
                style: {
                  margin: "2em 0",
                  whiteSpace: "pre-line"
                },
                "data-sentry-element": "Text",
                "data-sentry-source-file": "game-info.tsx",
                children: [tX[a.infoFor], (0, D.jsx)("br", {}), (0, D.jsx)("br", {}), (0, D.jsx)("i", {
                  children: tJ[a.infoFor] || "The max winning amount for all games, except Cups, Cases, Case Battles and Jackpot is 1,000,000 FlipCoins."
                })]
              }), tQ[a.infoFor] && (0, D.jsx)($(), {
                layout: "responsive",
                src: tY,
                unoptimized: true,
                alt: "Blackjack"
              }), (0, D.jsx)(e_.Z, {
                style: {
                  width: "100%",
                  marginTop: "1em"
                },
                variant: "primary",
                onClick: closeModal,
                className: ex().modalWithdrawButton,
                "data-sentry-element": "Button",
                "data-sentry-source-file": "game-info.tsx",
                children: "Okay"
              }), (0, D.jsx)(e_.Z, {
                onClick: closeModal,
                className: ex().defaultModalClose,
                "aria-label": "Close",
                "data-sentry-element": "Button",
                "data-sentry-source-file": "game-info.tsx"
              })]
            })
          });
        } else {
          return (0, D.jsx)(D.Fragment, {});
        }
      });
      a(95705);
      var t0 = a(57785);
      var t1 = a(24762);
      function phoneRetention_extends() {
        return (phoneRetention_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function phoneRetention(e) {
        return W.createElement("svg", phoneRetention_extends({
          width: 20,
          height: 20,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), B ||= W.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M7.677 12.324a16.76 16.76 0 0 0 4.008 2.982l2.622-2.674 4.767 1.1c.495.115.926.415.926.923v3.305a2.013 2.013 0 0 1-1.878 2.011c-4.15.288-8.946-1.58-12.729-5.363C1.608 10.822-.255 6.027.028 1.878A2.013 2.013 0 0 1 2.038 0h3.305c.509 0 .812.428.927.924l1.099 4.77-2.674 2.621a16.859 16.859 0 0 0 2.982 4.01Z",
          fill: "#5F6892"
        }));
      }
      function noti_extends() {
        return (noti_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function noti(e) {
        return W.createElement("svg", noti_extends({
          width: 18,
          height: 22,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), E ||= W.createElement("path", {
          d: "M17.684 16.83a.968.968 0 0 1-.847.506H1.184a.98.98 0 0 1-.847-.506 1.012 1.012 0 0 1 0-1l1.584-2.377V7.02A6.986 6.986 0 0 1 9.005 0a7.094 7.094 0 0 1 4.84 1.837 7.065 7.065 0 0 1 2.2 5.18v6.435l1.595 2.376c.19.303.207.683.044 1.001ZM9.005 22c1.254 0 2.343-1.188 2.805-2.86H6.211C6.673 20.812 7.751 22 9.005 22Z",
          fill: "#5F6892"
        }));
      }
      function emailReten_extends() {
        return (emailReten_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function emailReten(e) {
        return W.createElement("svg", emailReten_extends({
          width: 26,
          height: 17,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), P ||= W.createElement("path", {
          d: "M2.022 0 13 9.15 23.978 0H2.022ZM.533 1.23V17h24.934V1.23l-11.848 9.877a.968.968 0 0 1-1.239 0L.533 1.23Z",
          fill: "#5F6892"
        }));
      }
      function outlined_robux_extends() {
        return (outlined_robux_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function outlined_robux(e) {
        return W.createElement("svg", outlined_robux_extends({
          width: 17,
          height: 20,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), L ||= W.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M14.975 5.351 8.836 1.787a.67.67 0 0 0-.672 0L2.025 5.351a.677.677 0 0 0-.336.586v7.129c0 .242.128.465.336.586l6.139 3.564a.67.67 0 0 0 .672 0l6.139-3.564a.677.677 0 0 0 .336-.586V5.937a.677.677 0 0 0-.336-.586ZM9.509.615a2.008 2.008 0 0 0-2.018 0L1.353 4.18a2.032 2.032 0 0 0-1.01 1.757v7.129c0 .725.385 1.395 1.01 1.758l6.138 3.564a2.008 2.008 0 0 0 2.018 0l6.139-3.564a2.032 2.032 0 0 0 1.009-1.758V5.937c0-.725-.385-1.395-1.01-1.757L9.51.615Z",
          fill: "#5F6892"
        }), O ||= W.createElement("path", {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M4 12.441h1.585V9.948c.199-.052.89-.047.89.387v2.106h1.564V9.886c-.045-.18-.293-.538-.916-.523.305-.032.916-.255.916-.89v-.969c-.022-.38-.357-1.142-1.512-1.142H4v6.08Zm1.558-5.073V8.82h.618c.153-.026.459-.21.459-.736 0-.527-.306-.697-.459-.716h-.618Z",
          fill: "#5F6892"
        }), R ||= W.createElement("path", {
          d: "M11.303 8.903c-.55-.245-1.071-.477-1.07-.74.002-.182.282-.367.748-.367h.012c.618.004 1.215.5 1.33.622l.115.122 1.062-.972-.114-.107c-.18-.166-.806-.708-1.62-.947l.009-1.004-1.485-.01-.008.98c-.928.228-1.547.89-1.554 1.682-.008 1.04 1.09 1.531 1.973 1.925.55.246 1.068.477 1.066.741 0 .091-.065.18-.181.252-.144.088-.35.136-.579.133-.702-.004-1.312-.632-1.318-.639l-.114-.124-1.075.972.118.11c.18.169.812.716 1.616.954l-.008 1.004 1.484.01.008-.982c.935-.237 1.558-.904 1.564-1.69.009-1.04-1.093-1.53-1.979-1.925Z",
          fill: "#5F6892"
        }));
      }
      function check_extends() {
        return (check_extends = Object.assign ? Object.assign.bind() : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var n in a) {
              if ({}.hasOwnProperty.call(a, n)) {
                e[n] = a[n];
              }
            }
          }
          return e;
        }).apply(null, arguments);
      }
      function check(e) {
        return W.createElement("svg", check_extends({
          width: 14,
          height: 11,
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg"
        }, e), F ||= W.createElement("path", {
          d: "M5.208 8.217a.15.15 0 0 0 .222-.005L12.109.484a.932.932 0 0 1 1.365-.07c.4.383.43 1.038.066 1.46l-7.47 8.642a.947.947 0 0 1-.692.334.942.942 0 0 1-.707-.298L.937 6.622a1.072 1.072 0 0 1 0-1.46.932.932 0 0 1 1.367 0l2.904 3.055Z",
          fill: "#5F6892",
          stroke: "#1E2446",
          strokeWidth: 0.3,
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }));
      }
      eb().setAppElement("#__next");
      var t2 = (0, X.$j)(e => ({
        showRentionModal: e.auth.showRentionModal,
        user: e.auth.user,
        isAuthenticated: e.auth.isAuthenticated
      }))(function (e) {
        let {
          className: t,
          showRentionModal: a,
          user: n,
          oneSignalInitialized: s
        } = e;
        (0, ea.useRouter)();
        let [l, r] = (0, W.useState)(false);
        let o = (0, X.I0)();
        let i = W.useMemo(() => (0, eJ.P)("margin"), ["margin"]);
        let [c, d] = (0, W.useState)(false);
        let [u, m] = (0, W.useState)(false);
        let [h, p] = (0, W.useState)(false);
        let [g, f] = (0, W.useState)("");
        let [x, v] = (0, W.useState)(0);
        let [_, y] = (0, W.useState)("sms");
        let [b, w] = (0, W.useState)({
          sms: "",
          email: ""
        });
        let [j, C] = (0, W.useState)({
          isEmailAttached: false,
          isPhoneAttached: false
        });
        let [T, I] = (0, W.useState)({
          email: null,
          phone: null
        });
        let [S, M] = (0, W.useState)(null);
        let checkOneSignalStatus = async () => {
          if (s) {
            try {
              if (window.OneSignal.isPushNotificationsSupported()) {
                let e = await Promise.race([window.OneSignal.isPushNotificationsEnabled, () => new Promise(e => setTimeout(() => e(true), 1000))].map(e => e()));
                M(!!e);
              }
            } catch (e) {
              M("NOT_SUPPORTED");
              console.log("Web Notificatoins not supported...");
            }
          }
        };
        function closeModal() {
          o({
            type: es.Zm
          });
          r(false);
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        (0, W.useEffect)(() => {
          if (n) {
            C({
              isEmailAttached: !!(n == null ? undefined : n.userEmailProperties?.email),
              isPhoneAttached: !!(n == null ? undefined : n.userPhoneProperties?.phoneNumber)
            });
            I({
              email: n == null ? undefined : n.userEmailProperties?.email,
              phone: n == null ? undefined : n.userPhoneProperties?.phoneNumber
            });
          }
          p(false);
          m(false);
          f("");
          w({
            sms: "",
            email: ""
          });
        }, [_, a, n]);
        (0, W.useEffect)(() => {
          if (a) {
            r(true);
            setTimeout(() => {
              document.body.style.overflow = "hidden";
              document.body.style.paddingRight = i.gap + "px";
            }, 0);
            checkOneSignalStatus();
          } else if (a === false) {
            closeModal();
          }
        }, [a]);
        let handleEmailSubmit = async () => {
          try {
            let e = await (0, eg.rMC)(b.email);
            if (e.success) {
              m(true);
            }
          } catch (t) {
            K.ZP.error(t.response.data.error ?? "failed to submit your email, try again later");
          }
        };
        let handleConfirmEmail = async e => {
          try {
            e.preventDefault();
            let t = await (0, eg.It1)(g);
            if (t.success) {
              K.ZP.success("Your Email has been confirmed");
              if (Date.now() < 1694086090608 && j.isPhoneAttached) {
                K.ZP.success("Congratulations, you are entered in the 1M FlipCoins Raffle!");
              }
              o((0, Y.UH)());
              closeModal();
            }
          } catch (e) {
            K.ZP.error("Failed to confirm your email");
          }
        };
        let handlePhoneSubmit = async () => {
          try {
            let e = await (0, eg._De)(b.sms);
            if (e.success) {
              p(true);
              K.ZP.success("We sent you verification code through SMS");
            }
          } catch (t) {
            K.ZP.error(t.response.data.error ?? "failed to submit your email, try again later");
          }
        };
        let handleConfirmPhone = async e => {
          try {
            e.preventDefault();
            let t = await (0, eg.OIx)(g);
            if (t.success) {
              K.ZP.success("Your phone number has been confirmed");
              if (Date.now() < 1694086090608 && j.isEmailAttached) {
                K.ZP.success("Congratulations, you are entered in the 1M FlipCoins Raffle!");
              }
              o((0, Y.UH)());
              closeModal();
            }
          } catch (e) {
            K.ZP.error("Failed to confirm your email");
          }
        };
        let handleUnlink = async e => {
          try {
            if (e === "email") {
              await (0, eg.NXu)();
            } else if (e === "phone") {
              await (0, eg.MAM)();
            }
            o((0, Y.UH)());
          } catch (t) {
            K.ZP.error("Failed to delete your " + e);
          }
        };
        return (0, D.jsx)(D.Fragment, {
          children: (0, D.jsxs)(eb(), {
            isOpen: l,
            onRequestClose: closeModal,
            contentLabel: "Withdraw modal",
            className: U()(ex().defaultModal, ex().modalRetention, t),
            closeTimeoutMS: 200,
            "data-sentry-element": "Modal",
            "data-sentry-source-file": "retention-modal.tsx",
            children: [(0, D.jsx)(tr.Z, {
              onComplete: handleEmailSubmit,
              handleClose: () => {
                d(false);
              },
              open: c,
              "data-sentry-element": "BotFailModal",
              "data-sentry-source-file": "retention-modal.tsx"
            }), (0, D.jsx)(em.Z, {
              element: "h2",
              className: ex().modalHeading,
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "retention-modal.tsx",
              children: "Free FlipCoins case"
            }), (0, D.jsx)("div", {
              className: ex().tabs,
              children: (0, D.jsx)(e_.Z, {
                onClick: () => v(0),
                isActive: x === 0,
                variant: "tab",
                "data-sentry-element": "Button",
                "data-sentry-source-file": "retention-modal.tsx",
                children: "Retention Method"
              })
            }), x === 0 ? (0, D.jsxs)(D.Fragment, {
              children: [(0, D.jsxs)(eu.Z, {
                className: ex().modalSecondary,
                textType: "labelsRegular",
                children: ["Link the following below to get a free FlipCoins case ", (0, D.jsx)("br", {}), "rewarded to your account"]
              }), (0, D.jsxs)("div", {
                className: ex().retentionContainer,
                children: [(0, D.jsxs)(e_.Z, {
                  className: U()(ex().retentionItem, _ === "sms" && ex().activeRetention, ex().smsRetentionItem),
                  onClick: () => y("sms"),
                  children: [(0, D.jsx)(phoneRetention, {}), (0, D.jsx)(eu.Z, {
                    textType: "labelsRegular",
                    children: "Phone number"
                  }), j.isPhoneAttached ? (0, D.jsx)(check, {}) : (0, D.jsxs)("div", {
                    className: ex().rbxPricing,
                    children: [(0, D.jsx)(eu.Z, {
                      textType: "labelsSemibold",
                      children: "05"
                    }), (0, D.jsx)(outlined_robux, {})]
                  })]
                }), (0, D.jsxs)(e_.Z, {
                  className: U()(ex().retentionItem, _ === "email" && ex().activeRetention, ex().EmailRetentionItem),
                  onClick: () => y("email"),
                  children: [(0, D.jsx)(emailReten, {}), (0, D.jsx)(eu.Z, {
                    textType: "labelsRegular",
                    children: "Email"
                  }), j.isEmailAttached ? (0, D.jsx)(check, {}) : (0, D.jsxs)("div", {
                    className: ex().rbxPricing,
                    children: [(0, D.jsx)(eu.Z, {
                      textType: "labelsSemibold",
                      children: "05"
                    }), (0, D.jsx)(outlined_robux, {})]
                  })]
                }), (0, D.jsxs)(e_.Z, {
                  className: U()(ex().retentionItem, _ === "oneSignal" && ex().activeRetention, ex().oneSignalRetentionItem),
                  onClick: () => y("oneSignal"),
                  children: [(0, D.jsx)(noti, {}), (0, D.jsx)(eu.Z, {
                    textType: "labelsRegular",
                    children: "Browser Notifications"
                  }), (0, D.jsxs)("div", {
                    className: ex().rbxPricing,
                    children: [(0, D.jsx)(eu.Z, {
                      textType: "labelsSemibold",
                      children: "05"
                    }), (0, D.jsx)(outlined_robux, {})]
                  })]
                })]
              }), (0, D.jsxs)("div", {
                className: ex().retentionTabContent,
                children: [_ === "sms" && !h && (0, D.jsxs)("form", {
                  onSubmit: e => {
                    e.preventDefault();
                    if (b.sms.length) {
                      if (n == null ? undefined : n._fromInstant) {
                        d(true);
                      } else {
                        handlePhoneSubmit();
                      }
                    }
                  },
                  children: [(0, D.jsx)(eu.Z, {
                    className: ex().formLabel,
                    textType: "labelsRegular",
                    children: "Phone number"
                  }), (0, D.jsx)(t0.ZP, {
                    disabled: j.isPhoneAttached,
                    style: Object.assign(j.isPhoneAttached ? {
                      opacity: ".6",
                      cursor: "not-allowed"
                    } : {}, {
                      marginBottom: "10px"
                    }),
                    value: j.isPhoneAttached && T.phone ? T.phone : b.sms,
                    className: U()("phoneNumberInput", ex().formInput),
                    defaultCountry: "US",
                    onChange: e => {
                      w(t => ({
                        ...t,
                        sms: e ?? ""
                      }));
                    },
                    placeholder: "Enter your Phone number..."
                  }), j.isPhoneAttached ? (0, D.jsx)(e_.Z, {
                    onClick: () => handleUnlink("phone"),
                    className: ex().formSubmit,
                    type: "button",
                    variant: "danger",
                    children: "Unlink phone number"
                  }) : (0, D.jsxs)(D.Fragment, {
                    children: [(0, D.jsx)(eu.Z, {
                      className: ex().formLabelCode,
                      textType: "regular16",
                      onClick: () => p(true),
                      children: "I have the code"
                    }), (0, D.jsx)(e_.Z, {
                      className: ex().formSubmit,
                      type: "submit",
                      variant: "primary",
                      children: "Continue connection"
                    })]
                  })]
                }), _ === "sms" && h && (0, D.jsxs)("form", {
                  onSubmit: handleConfirmPhone,
                  children: [(0, D.jsx)(eu.Z, {
                    className: ex().formLabel,
                    textType: "labelsRegular",
                    children: "SMS verification code"
                  }), (0, D.jsx)(eM.Z, {
                    className: ex().formInput,
                    value: g,
                    onChange: e => f(e.target.value),
                    placeholder: "Enter the code sent to you..."
                  }), (0, D.jsx)(e_.Z, {
                    className: ex().formSubmit,
                    type: "submit",
                    variant: "primary",
                    children: "Continue connection"
                  })]
                }), _ === "email" && !u && (0, D.jsxs)("form", {
                  onSubmit: e => {
                    e.preventDefault();
                    if (b.email.length) {
                      if (n == null ? undefined : n._fromInstant) {
                        d(true);
                      } else {
                        handleEmailSubmit();
                      }
                    }
                  },
                  children: [(0, D.jsx)(eu.Z, {
                    className: ex().formLabel,
                    textType: "labelsRegular",
                    children: "Email"
                  }), (0, D.jsx)(eM.Z, {
                    type: "email",
                    disabled: j.isEmailAttached,
                    style: Object.assign(j.isEmailAttached ? {
                      opacity: ".6",
                      cursor: "not-allowed"
                    } : {}, {
                      marginBottom: "10px"
                    }),
                    value: j.isEmailAttached && T.email ? T.email : b.email,
                    className: ex().formInput,
                    onChange: e => {
                      w(t => ({
                        ...t,
                        email: e.target.value
                      }));
                    },
                    placeholder: "Enter email address..."
                  }), j.isEmailAttached ? (0, D.jsx)(e_.Z, {
                    onClick: () => handleUnlink("email"),
                    className: ex().formSubmit,
                    type: "button",
                    variant: "danger",
                    children: "Unlink email"
                  }) : (0, D.jsxs)(D.Fragment, {
                    children: [(0, D.jsx)(eu.Z, {
                      className: ex().formLabelCode,
                      textType: "regular14",
                      onClick: () => m(true),
                      children: "I have the code"
                    }), (0, D.jsx)(e_.Z, {
                      className: ex().formSubmit,
                      type: "submit",
                      variant: "primary",
                      children: "Continue connection"
                    })]
                  })]
                }), _ === "email" && u && (0, D.jsxs)("form", {
                  onSubmit: handleConfirmEmail,
                  children: [(0, D.jsx)(eu.Z, {
                    className: ex().formLabel,
                    textType: "labelsRegular",
                    children: "Confirm Email:"
                  }), (0, D.jsx)(eM.Z, {
                    className: ex().formInput,
                    value: g,
                    onChange: e => f(e.target.value),
                    placeholder: "Enter the code sent to you..."
                  }), (0, D.jsx)(e_.Z, {
                    className: ex().formSubmit,
                    type: "submit",
                    variant: "primary",
                    children: "Confirm Email"
                  })]
                }), _ === "oneSignal" && (0, D.jsxs)(D.Fragment, {
                  children: [(0, D.jsx)(eu.Z, {
                    className: ex().formLabel,
                    textType: "labelsRegular",
                    children: "Click below to enable browser notifications"
                  }), (0, D.jsx)(e_.Z, {
                    className: ex().formSubmit,
                    onClick: () => {
                      if (S) {
                        window.OneSignal.showSlidedownPrompt().then(() => {
                          console.log("one signal prompted");
                        }).catch(e => console.log(e));
                      } else if (S === false) {
                        K.ZP.error("Your notifications are already enabled");
                      } else if (S === "NOT_SUPPORTED") {
                        K.ZP.success("WEB notifications are not supported on your device...");
                      }
                    },
                    variant: "primary",
                    children: "Enable browser notification"
                  })]
                }), _ === "RblxChat" && (0, D.jsxs)(D.Fragment, {
                  children: [(0, D.jsx)(t1.Z, {
                    place: "top",
                    effect: "solid",
                    textColor: "#fff",
                    backgroundColor: "#353b61"
                  }), (0, D.jsx)(eu.Z, {
                    className: ex().formLabel,
                    textType: "labelsRegular",
                    children: "Click the button below to friend our notification bot"
                  }), (0, D.jsx)("span", {
                    style: {
                      display: "inline-block"
                    },
                    "data-tip": (n == null ? undefined : n._fromInstant) ? "You must authenticate with roblox to add this feature" : "",
                    children: (0, D.jsx)(e_.Z, {
                      className: ex().formSubmit,
                      disabled: n == null ? undefined : n._fromInstant,
                      variant: "primary",
                      children: "Add Roblox notification bot"
                    })
                  })]
                })]
              })]
            }) : (0, D.jsx)(em.Z, {
              element: "h2",
              className: ex().modalDepositTitle,
              children: "Social Rewards"
            }), (0, D.jsx)(e_.Z, {
              onClick: closeModal,
              className: ex().defaultModalClose,
              "aria-label": "Close",
              "data-sentry-element": "Button",
              "data-sentry-source-file": "retention-modal.tsx"
            })]
          })
        });
      });
      var t5 = a(81361);
      function GameWelcomer(e) {
        let {
          className: t
        } = e;
        let [a, n] = (0, W.useState)(false);
        let s = W.useMemo(() => (0, eJ.P)("margin"), ["margin"]);
        function closeModal() {
          n(false);
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        (0, W.useEffect)(() => {
          if (!localStorage.getItem("welcome_modal")) {
            localStorage.setItem("welcome_modal", "v1");
            n(true);
            setTimeout(() => {
              document.body.style.overflow = "hidden";
              document.body.style.paddingRight = s.gap + "px";
            }, 0);
          }
        }, []);
        return (0, D.jsx)(D.Fragment, {
          children: (0, D.jsxs)(eb(), {
            isOpen: a,
            onRequestClose: closeModal,
            contentLabel: "Welcomer modal",
            className: U()(ex().defaultModal, ex().modalWelcome),
            closeTimeoutMS: 200,
            "data-sentry-element": "Modal",
            "data-sentry-source-file": "welcome-global.tsx",
            children: [(0, D.jsx)("img", {
              src: "/logotype.svg"
            }), (0, D.jsx)(em.Z, {
              element: "h1",
              className: ex().modalDepositTitle,
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "welcome-global.tsx",
              children: "Welcome to the Nflip Universe!"
            }), (0, D.jsxs)(eu.Z, {
              className: ex().modalWithdrawText,
              element: "p",
              textType: "regular14",
              style: {
                margin: "2em 0",
                whiteSpace: "pre-line"
              },
              "data-sentry-element": "Text",
              "data-sentry-source-file": "welcome-global.tsx",
              children: [(0, D.jsx)("strong", {
                children: "Welcome in! Have fun! Play responsibly!"
              }), (0, D.jsx)("br", {}), "Please note: This is an 18+ only platform. Proceeding in violation can result in permanent loss of site access."]
            }), (0, D.jsxs)(eu.Z, {
              className: ex().modalWithdrawText,
              element: "p",
              textType: "regular14",
              style: {
                margin: "2em 0",
                whiteSpace: "pre-line"
              },
              "data-sentry-element": "Text",
              "data-sentry-source-file": "welcome-global.tsx",
              children: [(0, D.jsx)("strong", {
                children: "Site Update"
              }), (0, D.jsx)("br", {}), "This platform now operates using \"Flipcoin\" as the on site playing token. All gameplay will operate as before. Have fun!"]
            }), (0, D.jsx)(e_.Z, {
              style: {
                width: "100%",
                marginTop: "1em"
              },
              variant: "primary",
              onClick: closeModal,
              className: ex().modalWithdrawButton,
              "data-sentry-element": "Button",
              "data-sentry-source-file": "welcome-global.tsx",
              children: "Understood! 🕹️"
            })]
          })
        });
      }
      eb().setAppElement("#__next");
      var t4 = a(9008);
      var t3 = a.n(t4);
      var meta_data_MetaData = e => {
        let {
          title: t,
          description: a,
          ogTitle: n,
          ogUrl: s,
          ogImage: l,
          ogDescription: r
        } = e;
        return (0, D.jsxs)(t3(), {
          "data-sentry-element": "Head",
          "data-sentry-component": "MetaData",
          "data-sentry-source-file": "MetaData.tsx",
          children: [(0, D.jsx)("title", {
            children: t
          }), (0, D.jsx)("meta", {
            name: "description",
            content: a,
            "data-sentry-element": "meta",
            "data-sentry-source-file": "MetaData.tsx"
          }), (0, D.jsx)("meta", {
            property: "og:title",
            content: n,
            "data-sentry-element": "meta",
            "data-sentry-source-file": "MetaData.tsx"
          }), (0, D.jsx)("meta", {
            property: "og:type",
            content: "website",
            "data-sentry-element": "meta",
            "data-sentry-source-file": "MetaData.tsx"
          }), (0, D.jsx)("meta", {
            property: "og:url",
            content: s,
            "data-sentry-element": "meta",
            "data-sentry-source-file": "MetaData.tsx"
          }), (0, D.jsx)("meta", {
            property: "og:image",
            content: l,
            "data-sentry-element": "meta",
            "data-sentry-source-file": "MetaData.tsx"
          }), (0, D.jsx)("meta", {
            property: "og:description",
            content: r,
            "data-sentry-element": "meta",
            "data-sentry-source-file": "MetaData.tsx"
          }), (0, D.jsx)("link", {
            rel: "icon",
            href: "/favicon.ico"
          })]
        });
      };
      eb().setAppElement("#__next");
      var t8 = (0, X.$j)(e => ({
        showProvably: e.auth.showProvably
      }))(function (e) {
        let {
          className: t,
          showProvably: a
        } = e;
        let n = (0, X.I0)();
        let [s, l] = (0, W.useState)(false);
        let r = W.useMemo(() => (0, eJ.P)("margin"), ["margin"]);
        function closeModal() {
          l(false);
          n({
            type: es._z
          });
          document.body.style.overflow = "initial";
          document.body.style.paddingRight = "0px";
        }
        (0, W.useEffect)(() => {
          if (a == null ? undefined : a.show) {
            l(true);
            setTimeout(() => {
              document.body.style.overflow = "hidden";
              document.body.style.paddingRight = r.gap + "px";
            }, 0);
          } else if ((a == null ? undefined : a.show) === false) {
            closeModal();
          }
        }, [a == null ? undefined : a.show]);
        if (a == null ? undefined : a.provablyData) {
          return (0, D.jsx)(D.Fragment, {
            children: (0, D.jsxs)(eb(), {
              isOpen: s,
              onRequestClose: closeModal,
              contentLabel: "Replenishment modal",
              className: U()(ex().defaultModal, ex().modalDeposit, t),
              closeTimeoutMS: 200,
              style: {
                overlay: {
                  zIndex: 10000000
                },
                content: {
                  zIndex: 10000000
                }
              },
              children: [(0, D.jsx)(em.Z, {
                style: {
                  margin: ".3em 0 1em 0"
                },
                element: "h2",
                className: ex().modalDepositTitle,
                children: "Provably Fair"
              }), function () {
                let P = a == null ? undefined : a.provablyData?.gameName;
                if (P === "cups" || P === "crash" || P === "jackpot" || P === "slide" || P === "case-battles" || P === "big-roll") {
                  let e = [{
                    label: "Round ID",
                    value: (a == null ? undefined : a.provablyData?.uuid) ?? (a == null ? undefined : a.provablyData?.gameId) ?? (a == null ? undefined : a.provablyData?._id)
                  }, {
                    label: "Private Hash",
                    value: a == null ? undefined : a.provablyData?.privateHash
                  }, {
                    label: "Private Seed",
                    value: (a == null ? undefined : a.provablyData?.privateSeed) ?? (a == null ? undefined : a.provablyData?.clientSeed) ?? "Not Revealed"
                  }, {
                    label: "Public Seed",
                    value: (a == null ? undefined : a.provablyData?.publicSeed) ?? (a == null ? undefined : a.provablyData?.serverSeed) ?? "Not Created Yet"
                  }];
                  return e;
                }
                if (P === "mines" || P === "plinko" || P === "towers" || P === "dice" || P === "upgrader" || P === "blackjackv2") {
                  let e = [{
                    label: "Round ID",
                    value: (a == null ? undefined : a.provablyData?.uuid) ?? (a == null ? undefined : a.provablyData?.gameId) ?? (a == null ? undefined : a.provablyData?._id) ?? (a == null ? undefined : a.provablyData?.id)
                  }, {
                    label: "Game Nonce",
                    value: (a == null ? undefined : a.provablyData?.nonce) ?? "Unavailable"
                  }, {
                    label: "Client Seed",
                    value: (a == null ? undefined : a.provablyData?.privateSeed) ?? (a == null ? undefined : a.provablyData?.clientSeed) ?? "Unavailable"
                  }, {
                    label: "Server Seed",
                    value: (a == null ? undefined : a.provablyData?.publicSeed) ?? (a == null ? undefined : a.provablyData?.serverSeed) ?? "Not Revealed"
                  }, {
                    label: "Server Hash",
                    value: (a == null ? undefined : a.provablyData?.serverHash) ?? "Unavailable"
                  }];
                  return e;
                }
                return [];
              }().map((e, t) => {
                return (0, D.jsxs)("div", {
                  className: U()("customInput", ex().modalDepositInput),
                  children: [(0, D.jsx)(eu.Z, {
                    element: "p",
                    textType: "labelsRegular",
                    className: U()("customInputLabel"),
                    children: e.label
                  }), (0, D.jsxs)("div", {
                    className: U()("customInputInner"),
                    children: [(0, D.jsx)(eM.Z, {
                      onClick: t => {
                        t.target.select();
                        navigator.clipboard.writeText(e.value);
                        K.ZP.success("Link Copied To The Clipboard");
                      },
                      placeholder: "Not Revealed",
                      value: e.value ?? "Not Revealed"
                    }), (0, D.jsx)("div", {
                      className: U()("customInputInnerButtons")
                    })]
                  })]
                }, t);
              }), (0, D.jsx)(e_.Z, {
                onClick: closeModal,
                style: {
                  width: "100%"
                },
                variant: "primary",
                className: ex().modalDepositButton,
                children: "Close"
              })]
            })
          });
        } else {
          return (0, D.jsx)(D.Fragment, {});
        }
      });
      function Layout(e) {
        var n;
        let {
          className: l,
          children: r,
          excludeGlobalStatistics: o = false,
          ...i
        } = e;
        let c = (0, V.Z)();
        let d = W.useRef(null);
        let [u, m] = W.useState(false);
        let [h, p] = W.useState(true);
        let g = (n = (0, t5.cC)("nitropay_enabled")) !== null && n !== undefined && n;
        (0, W.useEffect)(() => {
          if (g) {
            p(false);
          } else {
            p(true);
          }
        }, [g]);
        let [f, x] = (0, W.useState)("Nflip");
        (0, W.useEffect)(() => {
          {
            let e = window.location.hostname.includes("bflip") ? "Nflip" : "Bloxflip";
            x(e);
          }
        }, []);
        (0, W.useEffect)(() => {
          if (d.current && d.current.innerHTML) {
            m(true);
          }
        }, [d.current, d.current?.innerHTML]);
        (0, W.useEffect)(() => {
          if (!h && "nitroAds" in window) {
            var e;
            if ((e = window.nitroAds) !== null && e !== undefined) {
              e.createAd("nitro-ad-deposit", {
                demo: document.location.hostname === "localhost",
                refreshLimit: 20,
                refreshTime: 60,
                renderVisibleOnly: false,
                refreshVisibleOnly: true,
                mobile: true,
                sizes: [["728", "90"]],
                report: {
                  enabled: true,
                  icon: true,
                  wording: "Report Ad",
                  position: "top-right"
                }
              });
            }
          }
        }, [h]);
        (0, W.useEffect)(() => {
          J.Z.dispatch((0, Y.II)());
          let updateFflags = async () => {
            let e = await (0, eg.G8W)();
            if (typeof e == "object") {
              window.sourceRetentionInt = e.sourceRetentionInt;
              J.Z.dispatch({
                type: es.BU,
                payload: e
              });
            }
          };
          updateFflags();
          setInterval(updateFflags, 420000);
          J.Z.dispatch((0, Y.ho)());
        }, []);
        return (0, D.jsxs)(X.zt, {
          store: J.Z,
          "data-sentry-element": "Provider",
          "data-sentry-component": "Layout",
          "data-sentry-source-file": "layout.tsx",
          children: [(0, D.jsx)(meta_data_MetaData, {
            title: f + " | Win BIG at the #1 game site!",
            description: f + " is the first game site! Play your Coins with Crash, Cups, Shuffle, and other gamemodes!",
            ogTitle: f + " | Win BIG at the #1 game site!",
            ogUrl: "https://bloxflip.com",
            ogImage: "https://i.imgur.com/tEREfCm.png",
            ogDescription: f + " is the first game site! Play your Coins with Crash, Cups, Shuffle, and other gamemodes!",
            "data-sentry-element": "MetaData",
            "data-sentry-source-file": "layout.tsx"
          }), (0, D.jsxs)("div", {
            className: U()(q().layout, l),
            ...i,
            children: [(0, D.jsx)(GameWelcomer, {
              "data-sentry-element": "GameWelcomer",
              "data-sentry-source-file": "layout.tsx"
            }), (0, D.jsx)(t2, {
              oneSignalInitialized: r.props?.oneSignalInitialized,
              "data-sentry-element": "RetentionModal",
              "data-sentry-source-file": "layout.tsx"
            }), (0, D.jsx)(tq, {
              "data-sentry-element": "GameHistoryModal",
              "data-sentry-source-file": "layout.tsx"
            }), (0, D.jsx)(t8, {
              "data-sentry-element": "ProvablyFair",
              "data-sentry-source-file": "layout.tsx"
            }), (0, D.jsx)(t$, {
              "data-sentry-element": "GameInfo",
              "data-sentry-source-file": "layout.tsx"
            }), (0, D.jsx)(te, {
              "data-sentry-element": "Header",
              "data-sentry-source-file": "layout.tsx"
            }), (0, D.jsxs)("div", {
              className: q().layoutRow,
              children: [c.width > 1170 && (0, D.jsx)("div", {
                className: q().layoutSidebar,
                children: (0, D.jsx)(G.Z, {
                  offsetTop: 96,
                  offsetBottom: 24,
                  children: (0, D.jsx)(tP, {})
                })
              }), (0, D.jsxs)("div", {
                style: {
                  minHeight: `${c.height - 144}px`
                },
                className: q().layoutColumn,
                children: [(!h && (0, D.jsx)("div", {
                  id: "nitro-ad-deposit",
                  ref: d,
                  className: U()(q().layoutColumnAdBoard, u && q().adLoaded)
                })) ?? null, r, (0, D.jsxs)("div", {
                  className: q().layoutColumnStatic,
                  children: [!o && (0, D.jsx)(LiveStatistics, {}), (0, D.jsx)(Footer, {
                    "data-sentry-element": "Footer",
                    "data-sentry-source-file": "layout.tsx"
                  })]
                })]
              }), c.width > 1170 && (0, D.jsx)("div", {
                className: q().layoutChat,
                children: (0, D.jsx)(tb, {})
              })]
            })]
          }), c.width <= 1170 && (0, D.jsx)(Menu, {}), (0, D.jsx)(K.x7, {
            containerStyle: {
              fontSize: "15px",
              zIndex: 999999999999
            },
            toastOptions: {
              className: "",
              duration: 5000,
              success: {
                duration: 3000,
                style: {
                  borderRadius: "10px",
                  background: "#12173a",
                  color: "#fff"
                }
              },
              error: {
                duration: 5000,
                style: {
                  borderRadius: "10px",
                  background: "#f03232",
                  color: "#fff"
                }
              }
            },
            position: "bottom-center",
            "data-sentry-element": "Toaster",
            "data-sentry-source-file": "layout.tsx"
          }), (0, D.jsx)(ta, {
            "data-sentry-element": "EventHandler",
            "data-sentry-source-file": "layout.tsx"
          })]
        });
      }
    },
    32612: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        a: function () {
          return Loader;
        }
      });
      var n = a(85893);
      var s = a(93967);
      var l = a.n(s);
      var r = a(38648);
      var o = a.n(r);
      let Loader = e => {
        let {
          radius: t,
          isBlue: a,
          className: s,
          centered: r
        } = e;
        return (0, n.jsx)("div", {
          className: l()(s ?? "", r && o().centered),
          "data-sentry-component": "Loader",
          "data-sentry-source-file": "Loader.tsx",
          children: (0, n.jsx)("div", {
            className: l()(o().loaderContent, a && o().blueOne),
            style: {
              width: t ?? 15,
              height: t ?? 15
            }
          })
        });
      };
      t.Z = Loader;
    },
    30857: function (e, t, a) {
      "use strict";
  
      var n = a(85893);
      a(67294);
      var s = a(2664);
      var l = a(93967);
      var r = a.n(l);
      var o = a(8210);
      var i = a.n(o);
      var c = a(791);
      var d = a(4595);
      var u = a(83253);
      var m = a.n(u);
      var h = a(86501);
      var p = a(85139);
      t.Z = (0, s.$j)(e => ({}))(e => {
        let {
          className: t,
          onComplete: a,
          open: s,
          handleClose: l,
          login: o
        } = e;
        return (0, n.jsxs)(m(), {
          isOpen: s,
          onRequestClose: l,
          contentLabel: "Sign-in modal",
          className: r()(i().defaultModal, t),
          closeTimeoutMS: 200,
          "data-sentry-element": "Modal",
          "data-sentry-component": "BotFailModal",
          "data-sentry-source-file": "BotFailModal.tsx",
          children: [(0, n.jsxs)("div", {
            className: i().modalAuthContent,
            children: [(0, n.jsx)(c.Z, {
              element: "h2",
              "data-sentry-element": "Heading",
              "data-sentry-source-file": "BotFailModal.tsx",
              children: "Captcha Challenge"
            }), (0, n.jsx)("div", {
              style: {
                textAlign: "center",
                marginTop: "2rem"
              },
              children: (0, n.jsx)(p.Z, {
                theme: "dark",
                sitekey: "2ce02d80-0c81-4b28-8af5-e4cdfc08bed9",
                onError: e => {
                  console.log(e);
                  h.Am.error("Captcha failed, please try again.");
                },
                onExpire: () => {
                  h.Am.error("the session is expired, please try again.");
                },
                onVerify: e => {
                  a(e);
                  l(true);
                },
                "data-sentry-element": "HCaptcha",
                "data-sentry-source-file": "BotFailModal.tsx"
              })
            })]
          }), (0, n.jsx)(d.Z, {
            onClick: l,
            className: i().defaultModalClose,
            "aria-label": "Close",
            "data-sentry-element": "Button",
            "data-sentry-source-file": "BotFailModal.tsx"
          })]
        });
      });
    },
    77579: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return Text;
        }
      });
      var n = a(85893);
      var s = a(93967);
      var l = a.n(s);
      a(67294);
      var r = a(63436);
      var o = a.n(r);
      let i = {
        smHeadlines: o().smHeadlines,
        regular16: o().regular16,
        semibold16: o().semibold16,
        regular14: o().regular14,
        semibold14: o().semibold14,
        textNumber: o().textNumber,
        labelsRegular: o().labelsRegular,
        labelsSemibold: o().labelsSemibold,
        bold23: o().bold23,
        semibold23: o().semibold23,
        bold14: o().bold14
      };
      function Text(e) {
        let {
          children: t,
          element: a,
          textType: s,
          className: r,
          ...c
        } = e;
        let d = a || "p";
        return (0, n.jsx)(d, {
          className: l()(o().text, i[s || "regular16"], r),
          ...c,
          "data-sentry-element": "Element",
          "data-sentry-component": "Text",
          "data-sentry-source-file": "text.tsx",
          children: t
        });
      }
    },
    33185: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        Z: function () {
          return TriviaGame;
        },
        h: function () {
          return VideoStream;
        }
      });
      var n = a(85893);
      var s = a(67294);
      var l = a(93967);
      var r = a.n(l);
      var o = a(77579);
      var i = a(59848);
      var c = a.n(i);
      var d = a(4595);
      var u = a(2181);
      function TriviaGame(e) {
        let {
          className: t,
          ...a
        } = e;
        let [l, i] = (0, s.useState)(true);
        return (0, n.jsxs)("div", {
          className: r()(c().triviaGame, t),
          ...a,
          "data-sentry-component": "TriviaGame",
          "data-sentry-source-file": "trivia-game.tsx",
          children: [(0, n.jsxs)("div", {
            className: c().triviaGamePlayer,
            children: [(0, n.jsx)(d.Z, {
              onClick: () => {
                i(true);
              },
              className: r()(c().triviaGamePlayerPreview, l && c().isVideoLoading),
              "data-sentry-element": "Button",
              "data-sentry-source-file": "trivia-game.tsx"
            }), l && (0, n.jsx)(VideoStream, {})]
          }), (0, n.jsxs)("div", {
            className: c().triviaGameStats,
            children: [(0, n.jsx)(o.Z, {
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "trivia-game.tsx",
              children: "Live streams are still in beta."
            }), (0, n.jsx)(o.Z, {
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "trivia-game.tsx"
            }), (0, n.jsx)(o.Z, {
              element: "p",
              textType: "regular14",
              "data-sentry-element": "Text",
              "data-sentry-source-file": "trivia-game.tsx",
              children: "All rights reserved."
            })]
          })]
        });
      }
      function VideoStream(e) {
        let {
          className: t,
          ...a
        } = e;
        let l = s.useRef(null);
        let [r, i] = s.useState(false);
        let [d, m] = s.useState("");
        let [h, p] = s.useState(0);
        let [g, f] = (0, s.useState)(null);
        (0, s.useEffect)(() => {}, []);
        (0, s.useEffect)(() => {
          let fetchData = async () => {
            try {
              var e = await (0, u.jPb)();
              e = e.siteSettings;
              f(e);
              if (e.bbStreaming) {
                var t = e.bbStreamPrefix;
                var a = e.bbStreamId;
                var n = await fetch(`https://${t}.cloudflarestream.com/${a}/lifecycle`);
                var s = await n.json();
                if (s.live && s.status === "ready") {
                  i(true);
                  m(`https://${t}.cloudflarestream.com/${a}/iframe?autoplay=true`);
                  var l = await fetch(`https://${t}.cloudflarestream.com/${a}/views`);
                  var r = await l.json();
                  p(r.liveViewers);
                } else {
                  i(false);
                }
              } else {
                i(false);
              }
            } catch (e) {
              console.log(e);
            }
          };
          var e = setInterval(() => {
            fetchData();
          }, 10000);
          fetchData();
          return () => {
            clearInterval(e);
          };
        }, []);
        if (r) {
          return (0, n.jsx)("iframe", {
            src: d,
            style: {
              border: "none",
              aspectRatio: "16/9"
            },
            height: "100%",
            width: "100%",
            allow: "accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;",
            allowFullScreen: true,
            id: "stream-player",
            ref: l,
            "data-sentry-component": "VideoStream",
            "data-sentry-source-file": "trivia-game.tsx"
          });
        } else {
          return (0, n.jsxs)("div", {
            children: [(0, n.jsx)("img", {
              src: "https://static-cdn.jtvnw.net/jtv_user_pictures/20282905-f40d-496c-85b9-5eb89ef0c0ea-profile_banner-480.png",
              alt: "Trivia game placeholder",
              className: c().triviaGamePlayerPlaceholder,
              style: {
                objectFit: "cover",
                objectPosition: "center",
                filter: "blur(10px)",
                opacity: 0.5,
                height: "100%",
                width: "100%"
              }
            }), (0, n.jsx)(o.Z, {
              textType: "regular16",
              style: {
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                textAlign: "center",
                textShadow: "0px 0px 10px rgba(0, 0, 0, 0.5)",
                fontSize: "3rem",
                color: "white"
              },
              children: "There doesn't seem to be a live stream right now. Please check back later."
            })]
          });
        }
      }
    },
    87185: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        _l: function () {
          return epochToString;
        },
        jR: function () {
          return getLevelFromWager;
        },
        sG: function () {
          return parseDate;
        },
        zD: function () {
          return epochToHHMM;
        }
      });
      let getLevelFromWager = e => ~~((Math.sqrt(625 + e * 100) - 25) / 300);
      let epochToHHMM = e => {
        if (typeof e == "string") {
          e = parseInt(e);
        }
        var t = new Date(e);
        return ("0" + t.getHours()).slice(-2) + ":" + ("0" + t.getMinutes()).slice(-2);
      };
      let epochToString = e => {
        if (typeof e == "string") {
          e = parseInt(e);
        }
        var t = new Date(e);
        return t.toDateString() + " " + ("0" + t.getHours()).slice(-2) + ":" + ("0" + t.getMinutes()).slice(-2);
      };
      let parseDate = e => {
        let t = new Date(e);
        return `${getMonthFromIndex(t.getMonth())} ${t.getDate()}, ${t.getFullYear()}`;
      };
      let getMonthFromIndex = e => {
        switch (e) {
          default:
          case 0:
            return "January";
          case 1:
            return "February";
          case 2:
            return "March";
          case 3:
            return "April";
          case 4:
            return "May";
          case 5:
            return "June";
          case 6:
            return "July";
          case 7:
            return "August";
          case 8:
            return "September";
          case 9:
            return "October";
          case 10:
            return "November";
          case 11:
            return "December";
        }
      };
    },
    74344: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        KP: function () {
          return f;
        },
        MK: function () {
          return v;
        },
        Ut: function () {
          return p;
        },
        WR: function () {
          return j;
        },
        Z$: function () {
          return setupSockets;
        },
        aY: function () {
          return _;
        },
        hY: function () {
          return m;
        },
        ki: function () {
          return d;
        },
        pi: function () {
          return c;
        },
        r5: function () {
          return h;
        },
        vS: function () {
          return x;
        },
        vW: function () {
          return b;
        }
      });
      var s = a(11530);
      var l = a(86809);
      var r = a.n(l);
      let o = "";
      o = "wss://bf-staging-ws.bazooki-infra.dev"
      let getBaseUrl = e => e.replace("/api/ws", "");
      let i = o.endsWith("/api/ws") ? "/api/ws/socket.io" : undefined;
      let c = r().connect(getBaseUrl(o) + "/chat", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let d = r().connect(getBaseUrl(o) + "/cups", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let u = r().connect(getBaseUrl(o) + "/blackjack", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let m = r().connect(getBaseUrl(o) + "/jackpot", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let h = r().connect(getBaseUrl(o) + "/bigroll", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let p = r().connect(getBaseUrl(o) + "/rouletteV2", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let g = r().connect(getBaseUrl(o) + "/roulette", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let f = r().connect(getBaseUrl(o) + "/crash", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let x = r().connect(getBaseUrl(o) + "/wallet", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let v = r().connect(getBaseUrl(o) + "/marketplace", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let _ = r().connect(getBaseUrl(o) + "/case-battles", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let y = r().connect(getBaseUrl(o) + "/mod-queue", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let b = r().connect(getBaseUrl(o) + "/feed", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let w = r().connect(getBaseUrl(o) + "/cloud-games", {
        transports: ["websocket"],
        upgrade: false,
        path: i
      });
      let j = [c, u, d, m, p, g, f, x, v, _, y, w, b];
      let setupSockets = () => {
        j.forEach(e => {
          e.on("reconnect", function () {
            e.emit("auth", localStorage.getItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN"));
          });
          e.emit("auth", localStorage.getItem("_DO_NOT_SHARE_BLOXFLIP_TOKEN"));
        });
      };
    },
    34793: function (e, t, a) {
      "use strict";
  
      a.d(t, {
        dZ: function () {
          return setUsedUsernames;
        },
        pt: function () {
          return checkUsername;
        }
      });
      let fingStr = () => {
        let e = navigator.userAgent;
        let t = navigator.language;
        let a = `${window.screen.width}x${window.screen.height}`;
        let n = Intl.DateTimeFormat().resolvedOptions().timeZone;
        let s = [e, t, a, n].map(e => e.replace(/\,/g, "").trim()).join(",");
        let l = stringToHex(s);
        return l;
      };
      let stringToHex = e => {
        let t = [];
        for (let a = 0; a < e.length; a++) {
          t.push(e.charCodeAt(a).toString(16).padStart(2, "0"));
        }
        return t.join("");
      };
      let hexToString = e => {
        let t = "";
        for (let a = 0; a < e.length; a += 2) {
          t += String.fromCharCode(parseInt(e.substr(a, 2), 16));
        }
        return t;
      };
      let setUsedUsernames = (e, t) => {
        if (!checkUsername(e, t)) {
          var a;
          let n = fingStr();
          let s = `_0x${(t ? n.split("").reverse().join("") : n).slice(0, 10)}`;
          let l = (a = localStorage.getItem(s)) === null || a === undefined ? undefined : a.replace("0x", "");
          let r = [];
          if (l) {
            r = (l = hexToString(l.split("").reverse().join(""))).split(",");
          }
          r.push(e);
          localStorage.setItem(s, `0x${stringToHex(r.join(",")).split("").reverse().join("")}`);
        }
      };
      let checkUsername = (e, t) => {
        var a;
        let n = fingStr();
        let s = `_0x${(t ? n.split("").reverse().join("") : n).slice(0, 10)}`;
        let l = (a = localStorage.getItem(s)) === null || a === undefined ? undefined : a.replace("0x", "");
        let r = [];
        if (l) {
          r = (l = hexToString(l.split("").reverse().join(""))).split(",");
        }
        return r.includes(e);
      };
    },
    26880: function (e, t) {
      "use strict";
  
      t.Z = (e, t, a) => e.slice((a - 1) * t, a * t);
    },
    39398: function (e, t) {
      "use strict";
  
      t.Z = e => {
        var t;
        if (e == null) {
          return undefined;
        } else if ((t = e.toString()) === null || t === undefined) {
          return undefined;
        } else {
          return t.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
      };
    },
    81511: function (e, t, a) {
      "use strict";
  
      var n = a(2181);
      t.Z = e => {
        if (e) {
          n.blP.defaults.headers.common["x-auth-token"] = e;
        } else {
          delete n.blP.defaults.headers.common["x-auth-token"];
        }
        try {
          n.blP.defaults.headers.common["x-timezone"] = Intl.DateTimeFormat().resolvedOptions().timeZone;
        } catch (e) {
          console.log(e);
        }
      };
    },
    12950: function (e) {
      e.exports = {
        container: "arkose_container__UDotx",
        direction: "arkose_direction__fvw6R",
        content: "arkose_content__CZAX5",
        contentBottom: "arkose_contentBottom__eBO34",
        controler: "arkose_controler__sywqU",
        headbuttons: "arkose_headbuttons__HWbjn"
      };
    },
    22674: function (e) {
      e.exports = {
        avatar: "avatar_avatar__mmMaW",
        avatarLabel: "avatar_avatarLabel__ii1Pq",
        avatarLarge: "avatar_avatarLarge__oJ5s_",
        avatarSuperLarge: "avatar_avatarSuperLarge__94gX4",
        avatarExtraLarge: "avatar_avatarExtraLarge__gsvVS",
        avatarMedium: "avatar_avatarMedium__0pjGV"
      };
    },
    59801: function (e) {
      e.exports = {
        case: "case_case__qg7bq",
        caseNohover: "case_caseNohover__cAr9Q",
        isDisabled: "case_isDisabled__KVRAb",
        caseAvatar: "case_caseAvatar__Bj8WP",
        casePreview: "case_casePreview__LcNxP",
        caseTitle: "case_caseTitle__7qX9z",
        caseSubtitle: "case_caseSubtitle__Uw0cA",
        caseManage: "case_caseManage__Q3Kkl",
        caseCardHolder: "case_caseCardHolder__Ml9OK",
        caseFixedRight: "case_caseFixedRight__hrjrV",
        caseLabel: "case_caseLabel__nj3yw",
        caseButtons: "case_caseButtons__WeguG"
      };
    },
    15260: function (e) {
      e.exports = {
        chat: "chat_chat__paFx8",
        chatOpened: "chat_chatOpened__QAoiJ",
        chatClosed: "chat_chatClosed__V_o5w",
        chatOpen: "chat_chatOpen__QM1Zd",
        chatClose: "chat_chatClose__oPYCb",
        chatHeader: "chat_chatHeader__eKYxe",
        chatHeaderTitle: "chat_chatHeaderTitle__G6ONe",
        chatHeaderOnline: "chat_chatHeaderOnline__1_Ndy",
        chatTrack: "chat_chatTrack__ISYoh",
        chatTrackInner: "chat_chatTrackInner__0Nw4M",
        chatMessage: "chat_chatMessage__3k8OS",
        chatMessageContent: "chat_chatMessageContent__Xjh6r",
        chatMessageContentHeader: "chat_chatMessageContentHeader__ySuPX",
        chatMessageAuthor: "chat_chatMessageAuthor__mAVx1",
        chatMessageTimestamp: "chat_chatMessageTimestamp__Cd4aL",
        chatMessageText: "chat_chatMessageText__g7988",
        chatSend: "chat_chatSend__Rl3ep",
        chatSendInput: "chat_chatSendInput__odUpI",
        chatSendInputInner: "chat_chatSendInputInner__SXMMx",
        chatSendButtons: "chat_chatSendButtons__s2gCy",
        chatSendButtonsEmoji: "chat_chatSendButtonsEmoji__XS7cc",
        chatSendButtonsSubmit: "chat_chatSendButtonsSubmit__Yjldv",
        chatStreamerBanner: "chat_chatStreamerBanner___eYVo",
        chatTriviaBanner: "chat_chatTriviaBanner__w5ct3",
        chatTriviaBannerBannerText: "chat_chatTriviaBannerBannerText__yAC_l",
        chatTriviaBannerBannerTextCorner: "chat_chatTriviaBannerBannerTextCorner__3uU1t",
        chatBanner: "chat_chatBanner__unotk",
        chatBannerTitle: "chat_chatBannerTitle__pzRaB",
        chatBannerJoinButton: "chat_chatBannerJoinButton__avNuN",
        chatBannerText: "chat_chatBannerText__iXryi"
      };
    },
    90173: function (e) {
      e.exports = {
        footer: "footer_footer__3kcQj",
        footerLogoContainer: "footer_footerLogoContainer__i134_",
        footerMain: "footer_footerMain__GrB5q",
        footerMainText: "footer_footerMainText__OjeNV",
        footerBlock: "footer_footerBlock__4AtDD",
        footerNav: "footer_footerNav__mlEEX",
        footerNavBlock: "footer_footerNavBlock__V6gia",
        footerNavBlockTitle: "footer_footerNavBlockTitle__FVDd3",
        footerNavBlockLink: "footer_footerNavBlockLink__gHuUA",
        footerSocials: "footer_footerSocials__8DyBd",
        footerSocialsTitle: "footer_footerSocialsTitle__mv4SX",
        footerSocialsList: "footer_footerSocialsList__UfxWc",
        footerSocialsButton: "footer_footerSocialsButton__qx2EV",
        footerPaymentsButton: "footer_footerPaymentsButton__t7GyO"
      };
    },
    29988: function (e) {
      e.exports = {
        header: "header_header__pwrbs",
        headerLogo: "header_headerLogo__AqB_V",
        headerNav: "header_headerNav__weXq1",
        headerNavLink: "header_headerNavLink__auq7z",
        headerNavLinkRedd: "header_headerNavLinkRedd__0jnaW",
        headerNavLinkActive: "header_headerNavLinkActive__Z4OoK",
        headerMovedToRight: "header_headerMovedToRight__3bGXu",
        headerUser: "header_headerUser__8phtj",
        headerUserContent: "header_headerUserContent__bqfIe",
        headerUserContentLabel: "header_headerUserContentLabel__IBocA",
        headerUserBalance: "header_headerUserBalance__mNiaf",
        headerManage: "header_headerManage__p14ec",
        headerManageLogout: "header_headerManageLogout__TOzIS"
      };
    },
    92358: function (e) {
      e.exports = {
        raceHeader: "race_raceHeader__Ku7WF",
        raceHeaderColumn: "race_raceHeaderColumn__M3loZ",
        raceHeaderColumnPrize: "race_raceHeaderColumnPrize____rdK",
        raceHeaderLink: "race_raceHeaderLink__WBVD8",
        raceHeaderLinkActive: "race_raceHeaderLinkActive__S_z1m"
      };
    },
    10937: function (e) {
      e.exports = {
        heading: "heading_heading__rQMSe",
        heading1: "heading_heading1__ey2A7",
        heading2: "heading_heading2__HIhIE",
        heading3: "heading_heading3__5eklR",
        heading4: "heading_heading4__5059d"
      };
    },
    46826: function (e) {
      e.exports = {
        input: "input_input__N_xjH",
        inputWithCurrencyStart: "input_inputWithCurrencyStart__agCI6",
        inputWithCurrencyEnd: "input_inputWithCurrencyEnd__y_4V_",
        formField: "input_formField__d0c__",
        innerButton: "input_innerButton__w0OFk",
        formFieldInner: "input_formFieldInner__eFrRQ",
        formFieldInnerButtons: "input_formFieldInnerButtons__Y1wDX",
        formFieldInnerButtonsToggleFocus: "input_formFieldInnerButtonsToggleFocus__vhPCp",
        inputIcon: "input_inputIcon__bDh3G",
        formFieldPrimary: "input_formFieldPrimary__Amjmh",
        formFieldSecondary: "input_formFieldSecondary__VDEAt",
        buttonGroup: "input_buttonGroup__lyOtC",
        counterButton: "input_counterButton__onHrE"
      };
    },
    44457: function (e) {
      e.exports = {
        layout: "layout_layout__JvcqL",
        layoutRow: "layout_layoutRow__cGetM",
        layoutColumn: "layout_layoutColumn__e9oxs",
        layoutColumnAdBoard: "layout_layoutColumnAdBoard__8GAVF",
        adLoaded: "layout_adLoaded__9oALY",
        layoutColumnStatic: "layout_layoutColumnStatic__Op50p",
        layoutSidebar: "layout_layoutSidebar__AGyEt",
        layoutChat: "layout_layoutChat__ksWYR"
      };
    },
    38648: function (e) {
      e.exports = {
        centered: "loader_centered__689HG",
        loaderContent: "loader_loaderContent__H50A2",
        looper: "loader_looper__eD_ex",
        blueOne: "loader_blueOne__a8eX3"
      };
    },
    8484: function (e) {
      e.exports = {
        container: "menu_container__5j6Ow",
        containerItem: "menu_containerItem__vtjZE",
        containerBar: "menu_containerBar__rYV4J",
        containerBarItem: "menu_containerBarItem__1LY20",
        containerBarItemActive: "menu_containerBarItemActive__zDj_8",
        navigation: "menu_navigation__ZyXEC",
        navigationLink: "menu_navigationLink__9bK9s",
        navigationLinkActive: "menu_navigationLinkActive__SlphX",
        games: "menu_games__KlIgk",
        chat: "menu_chat__TrD_Q"
      };
    },
    37897: function (e) {
      e.exports = {
        dotsSteps: "instantlogin_dotsSteps__SikbG",
        dot: "instantlogin_dot__liEYe",
        active: "instantlogin_active__dsXoT"
      };
    },
    90757: function (e) {
      e.exports = {
        flash: "envm_flash__odgh8",
        pulse: "envm_pulse__ixpqK",
        modalCenterContent: "envm_modalCenterContent__xXqAG",
        active: "envm_active__c4Tq_",
        modalWinnerCups: "envm_modalWinnerCups__zhL0f",
        animationSection: "envm_animationSection___dTd1",
        cupSection: "envm_cupSection__X6eul",
        cup: "envm_cup__G8oRE",
        cupOut: "envm_cupOut__JCBEl",
        redOne: "envm_redOne__H0k15",
        blueOne: "envm_blueOne__pUIpd",
        purpleOne: "envm_purpleOne__oAfzm",
        yellowOne: "envm_yellowOne__QAXAf",
        cupSectionBall: "envm_cupSectionBall__Ra6p_",
        amountCollected: "envm_amountCollected__MRzic",
        amountText: "envm_amountText__u6r_J",
        bottomTop: "envm_bottomTop__jJVM5",
        flipCard: "envm_flipCard__o0XWo",
        bottomTopFlip: "envm_bottomTopFlip__oHdDM",
        fade: "envm_fade__t8cfx",
        rotate: "envm_rotate__y066z",
        gloss: "envm_gloss__1nqTx",
        shake: "envm_shake__kwIcv",
        rotateY: "envm_rotateY__CurTO",
        animateArrow: "envm_animateArrow__23Ljn",
        selectionArrowRight: "envm_selectionArrowRight__DdMC5",
        selectionArrowLeft: "envm_selectionArrowLeft__ZIOTF",
        coinExplode: "envm_coinExplode__FHkNi"
      };
    },
    8210: function (e) {
      e.exports = {
        ladt: "modals_ladt__Si1xn",
        modalSpooky: "modals_modalSpooky__k1q97",
        modalWelcome: "modals_modalWelcome__qdp5w",
        inputs: "modals_inputs__yUmm_",
        ageCheckModal: "modals_ageCheckModal__Zpmax",
        modalButtons: "modals_modalButtons__2LdV9",
        modalButtonGrey: "modals_modalButtonGrey__VSlbM",
        modalButtonHigh: "modals_modalButtonHigh__Ll1Pf",
        labelD: "modals_labelD__dwFT8",
        defaultModal: "modals_defaultModal__OyCO0",
        modalPicker: "modals_modalPicker__hWL8K",
        pickerClm: "modals_pickerClm__roIO8",
        label: "modals_label__U4AET",
        datePickerInput: "modals_datePickerInput__pUykU",
        datePickerCalendar: "modals_datePickerCalendar__jUpKf",
        buttons: "modals_buttons__mt8A9",
        buttonsBack: "modals_buttonsBack__W6JCc",
        buttonsCont: "modals_buttonsCont__aYswQ",
        defaultModalFriendly: "modals_defaultModalFriendly__ZgBzi",
        defaultModalFriendlyText: "modals_defaultModalFriendlyText__acMrJ",
        defaultModalBreadcrumbs: "modals_defaultModalBreadcrumbs___fecQ",
        defaultModalBreadcrumbsItem: "modals_defaultModalBreadcrumbsItem__uWfTN",
        defaultModalClose: "modals_defaultModalClose__fP0aZ",
        oneline: "modals_oneline__waDRO",
        modalAuth: "modals_modalAuth__z9jVM",
        modalAuthIllustration: "modals_modalAuthIllustration__V4HWN",
        modalAuthIllustrationTitle: "modals_modalAuthIllustrationTitle__OJrtj",
        modalAuthContent: "modals_modalAuthContent__VSruX",
        modalAuthText: "modals_modalAuthText__k_h1H",
        modalAuthTabsTriggers: "modals_modalAuthTabsTriggers__JPWxE",
        modalAuthCustomInput: "modals_modalAuthCustomInput__hfeMm",
        modalAuthCheckrow: "modals_modalAuthCheckrow__WWnqM",
        modalAuthExpTabHeading: "modals_modalAuthExpTabHeading__NQ9L8",
        modalAuthExpTabText: "modals_modalAuthExpTabText__dREKJ",
        modalAuthExpTabGamesWrapper: "modals_modalAuthExpTabGamesWrapper__kszbq",
        modalAuthExpTabGamesWrapperSingleGame: "modals_modalAuthExpTabGamesWrapperSingleGame__sCXVX",
        modalAuthExpTabGamesWrapperSingleGameImg: "modals_modalAuthExpTabGamesWrapperSingleGameImg__y_7Yo",
        modalAuthExpTabGamesWrapperSingleGameP: "modals_modalAuthExpTabGamesWrapperSingleGameP__dVrCi",
        modalAuthSubmit: "modals_modalAuthSubmit__sMXw_",
        modalAuthNote: "modals_modalAuthNote__Toy5r",
        modalAuthAdin: "modals_modalAuthAdin__k8w2Z",
        modalWin: "modals_modalWin__ZbzfO",
        modalWinTitle: "modals_modalWinTitle__0FnDk",
        modalWinText: "modals_modalWinText__CHgg0",
        modalWinAmount: "modals_modalWinAmount__Ve0ML",
        modalWinIllustration: "modals_modalWinIllustration__7m4s7",
        modalMoneyManage: "modals_modalMoneyManage__LToic",
        modalMoneyManageDeposit: "modals_modalMoneyManageDeposit__w4TfX",
        modalMoneyManageWithdraw: "modals_modalMoneyManageWithdraw__vx8_V",
        modalMoneyManageOptions: "modals_modalMoneyManageOptions___43ro",
        modalMoneyManageTitle: "modals_modalMoneyManageTitle__eAEEz",
        modalMoneyManageOptionsItem: "modals_modalMoneyManageOptionsItem__od80B",
        modalMoneyManageOptionsItemIllustration: "modals_modalMoneyManageOptionsItemIllustration__Hl5OX",
        discounts: "modals_discounts__Owqzf",
        discountLabel: "modals_discountLabel__QQHEq",
        shadow: "modals_shadow__wkBJB",
        countDown: "modals_countDown__TQjkG",
        modalListing: "modals_modalListing__CbdYF",
        modalListingTitle: "modals_modalListingTitle__PMIgC",
        modalListingInfo: "modals_modalListingInfo__83WGz",
        singleListSort: "modals_singleListSort__lYHOt",
        singleListSortItem: "modals_singleListSortItem__UxB00",
        modalListingInfoSub: "modals_modalListingInfoSub__pMDwy",
        modalListingSearch: "modals_modalListingSearch__XVrnj",
        modalListingGrid: "modals_modalListingGrid__EQFOx",
        modalSetPrice: "modals_modalSetPrice__NyfjU",
        modalSetPriceTitle: "modals_modalSetPriceTitle__dkSWb",
        modalSetPriceGrid: "modals_modalSetPriceGrid__kFNZR",
        modalSetPriceGridMain: "modals_modalSetPriceGridMain__t6pis",
        modalSetPriceGridMainText: "modals_modalSetPriceGridMainText__LNOxN",
        modalSetPriceGridMainInput: "modals_modalSetPriceGridMainInput__HH5eT",
        modalChatRules: "modals_modalChatRules__5vsl7",
        modalDeposit: "modals_modalDeposit__1s7P2",
        modalWithdraw: "modals_modalWithdraw__d_kfP",
        modalDepositTitle: "modals_modalDepositTitle__QXbSE",
        modalWithdrawTitle: "modals_modalWithdrawTitle__B_0vs",
        modalDepositOptions: "modals_modalDepositOptions__HakHV",
        modalWithdrawOptions: "modals_modalWithdrawOptions__VfQI8",
        modalDepositOptionsLabel: "modals_modalDepositOptionsLabel__Y5jkq",
        modalWithdrawOptionsLabel: "modals_modalWithdrawOptionsLabel__IWYNE",
        modalDepositOptionsList: "modals_modalDepositOptionsList__Ni8TO",
        modalWithdrawOptionsList: "modals_modalWithdrawOptionsList__AJLYR",
        modalDepositMethods: "modals_modalDepositMethods__iKjU6",
        modalWithdrawMethods: "modals_modalWithdrawMethods__HjtYt",
        modalDepositMethodsItem: "modals_modalDepositMethodsItem__WzGgY",
        modalWithdrawMethodsItem: "modals_modalWithdrawMethodsItem__PoL3l",
        isSelected: "modals_isSelected__44c_r",
        modalDepositText: "modals_modalDepositText__787dl",
        modalWithdrawText: "modals_modalWithdrawText__IFVlL",
        modalDepositInput: "modals_modalDepositInput__cCMcC",
        modalWithdrawInput: "modals_modalWithdrawInput__K6Ukl",
        modalDepositInputAmount: "modals_modalDepositInputAmount__j_wFW",
        modalWithdrawInputAmount: "modals_modalWithdrawInputAmount__OREud",
        modalDepositButton: "modals_modalDepositButton__lYujJ",
        modalWithdrawButton: "modals_modalWithdrawButton__6zNhP",
        modalProfile: "modals_modalProfile__AVa_d",
        modalProfileChart: "modals_modalProfileChart__rAAwy",
        modalProfileMainUser: "modals_modalProfileMainUser__7ZCaO",
        modalProfileMainUserText: "modals_modalProfileMainUserText__Tmq16",
        modalProfileMainStats: "modals_modalProfileMainStats__klNHs",
        modalProfileMainStatsBlock: "modals_modalProfileMainStatsBlock__GsWoU",
        modalProfileChartButtons: "modals_modalProfileChartButtons__h46yz",
        modalCasesAmount: "modals_modalCasesAmount__WVgVS",
        modalCasesAmountTitle: "modals_modalCasesAmountTitle___pcz2",
        modalCasesAmountText: "modals_modalCasesAmountText__wbHFL",
        modalCasesAmountCase: "modals_modalCasesAmountCase__kXEzL",
        modalCasesAmountSwitcher: "modals_modalCasesAmountSwitcher__aP2X3",
        modalCasesAmountButton: "modals_modalCasesAmountButton__i7sr9",
        createCaseCounter: "modals_createCaseCounter__au_R3",
        createCaseCounterText: "modals_createCaseCounterText__ww3Ln",
        createCaseCounterButton: "modals_createCaseCounterButton__BqQ1U",
        modalItemsWon: "modals_modalItemsWon__MoCzR",
        modalItemsWonTitle: "modals_modalItemsWonTitle__Pg_TY",
        modalItemsWonText: "modals_modalItemsWonText__8FQtf",
        modalItemsWonText2: "modals_modalItemsWonText2__pCdv2",
        modalItemsWonRow: "modals_modalItemsWonRow__58rui",
        modalItemsWonRowBlock: "modals_modalItemsWonRowBlock__JkMot",
        modalItemsWonUpgrade: "modals_modalItemsWonUpgrade__3NibW",
        modalItemsWonUpgradeBlock: "modals_modalItemsWonUpgradeBlock__rMQb8",
        modalItemsWonUpgradeCard: "modals_modalItemsWonUpgradeCard__i8oyb",
        modalItemsWonUpgradeCardLoadImg: "modals_modalItemsWonUpgradeCardLoadImg__yTMVM",
        modalItemsWonUpgradeCardActiveLoadImg: "modals_modalItemsWonUpgradeCardActiveLoadImg__m7Q8j",
        modalItemsWonFinished: "modals_modalItemsWonFinished___ho3K",
        modalItemsWonButton: "modals_modalItemsWonButton__iH_sv",
        modalItemsWonButtons: "modals_modalItemsWonButtons__lsOL6",
        modalItemsWonButtonsBtn: "modals_modalItemsWonButtonsBtn__u5lze",
        modalItemsWonUpgraderInfo: "modals_modalItemsWonUpgraderInfo__r5Bv4",
        cryptoModal: "modals_cryptoModal__0Hkd8",
        coinaseCryptoModal: "modals_coinaseCryptoModal__WgtKZ",
        secondaryText: "modals_secondaryText__2pTCK",
        twoInputs: "modals_twoInputs__8zDec",
        twoInputsFieldset: "modals_twoInputsFieldset__LOdv1",
        coinbaseChooseCurrency: "modals_coinbaseChooseCurrency__MG3uh",
        coinbaseCurrencyText: "modals_coinbaseCurrencyText__cZCcB",
        coinbaseQrTab: "modals_coinbaseQrTab__s6AP_",
        giftcardModal: "modals_giftcardModal__2oyQv",
        freeCaseModal: "modals_freeCaseModal____a_6",
        freeCaseTextWrapper: "modals_freeCaseTextWrapper__Xe6QC",
        casePreview: "modals_casePreview__00QRm",
        imgWrapper: "modals_imgWrapper__tOsWE",
        btnWrapper: "modals_btnWrapper__HqUY5",
        paygardenModal: "modals_paygardenModal__Z5bva",
        waitText: "modals_waitText__57zV3",
        paygardenClose: "modals_paygardenClose__LEH9z",
        paygardenIframe: "modals_paygardenIframe__xfDMJ",
        headingWrapperTitle: "modals_headingWrapperTitle__XDm8B",
        headingWrapperSecondary: "modals_headingWrapperSecondary__VBuWV",
        rateText: "modals_rateText__ALsao",
        howUFoundUsModal: "modals_howUFoundUsModal__0LWZ_",
        btns: "modals_btns__x1s32",
        tableModal: "modals_tableModal___T_O_",
        radioWrapper: "modals_radioWrapper__tGBc3",
        modalGiveaway: "modals_modalGiveaway__4mhNM",
        modalGiveawayContent: "modals_modalGiveawayContent__Maj_P",
        modalGiveawayContentHeader: "modals_modalGiveawayContentHeader__Yi_kk",
        modalGiveawayContentButtons: "modals_modalGiveawayContentButtons__CK0bJ",
        modalRetention: "modals_modalRetention__4asz2",
        modalHeading: "modals_modalHeading__Y3hyx",
        tabs: "modals_tabs__nl61f",
        modalSecondary: "modals_modalSecondary__wvgqn",
        ageContainer: "modals_ageContainer__UGgCi",
        retentionItem: "modals_retentionItem__LkhD6",
        rbxPricing: "modals_rbxPricing__KYdtL",
        activeRetention: "modals_activeRetention__SIX8B",
        oneSignalRetentionItem: "modals_oneSignalRetentionItem__A5Q17",
        retentionContainer: "modals_retentionContainer__FVH8f",
        retentionTabContent: "modals_retentionTabContent__VQv9R",
        formLabel: "modals_formLabel__oDZAh",
        formLabelCode: "modals_formLabelCode__BLWJT",
        formInput: "modals_formInput__7PteW",
        formSubmit: "modals_formSubmit__fU9Ub",
        modalHeader: "modals_modalHeader__TA878",
        gameInfoBlackjack: "modals_gameInfoBlackjack__8vxKU",
        deleteCardDialog: "modals_deleteCardDialog__lcjOs",
        deleteCardDialogContent: "modals_deleteCardDialogContent__QRpoN",
        deleteCardDialogActionButtons: "modals_deleteCardDialogActionButtons__zwVhU",
        deleteCardDialogDefaultModalClose: "modals_deleteCardDialogDefaultModalClose__de16A"
      };
    },
    57644: function (e) {
      e.exports = {
        sidebar: "sidebar_sidebar__7U3PX",
        sidebarGames: "sidebar_sidebarGames__PSlol",
        sidebarGamesLink: "sidebar_sidebarGamesLink__YMbpv",
        sidebarGamesLinkBox: "sidebar_sidebarGamesLinkBox__HoKrE",
        sidebarGamesLinkIcon: "sidebar_sidebarGamesLinkIcon__0eUjd",
        strokeVer: "sidebar_strokeVer__4NUNn",
        sidebarGamesLinkActive: "sidebar_sidebarGamesLinkActive__rpeBP",
        sidebarGamesLinkText: "sidebar_sidebarGamesLinkText__J4Bv9",
        sidebarGamesGradient: "sidebar_sidebarGamesGradient__il_mz",
        sidebarMore: "sidebar_sidebarMore__kyJYB",
        sidebarMoreLink: "sidebar_sidebarMoreLink__D082L"
      };
    },
    63153: function (e) {
      e.exports = {
        statistics: "statistics_statistics__ooTTY",
        statisticsHeader: "statistics_statisticsHeader__XGELH",
        statisticsManage: "statistics_statisticsManage__Cwgb6",
        statisticsManageSort: "statistics_statisticsManageSort__NWYjK",
        statisticsManageTabs: "statistics_statisticsManageTabs__0f95A",
        statisticsTable: "statistics_statisticsTable__JsbHz",
        statisticsTableHead: "statistics_statisticsTableHead__Od39S",
        statisticsTableItem: "statistics_statisticsTableItem__7q1pF",
        statisticsTableItemGame: "statistics_statisticsTableItemGame__p2SBZ",
        statisticsTableBody: "statistics_statisticsTableBody__icdiv",
        statisticsTableItemAvatar: "statistics_statisticsTableItemAvatar__jNa61",
        statisticsTableItemUser: "statistics_statisticsTableItemUser__pT9do",
        statisticsTableItemHighlighted: "statistics_statisticsTableItemHighlighted__cjXBr",
        statisticsTableItemID: "statistics_statisticsTableItemID__O9zPP",
        statisticsTableItemAmount: "statistics_statisticsTableItemAmount__zRgHY",
        statisticsTableItemMultiplier: "statistics_statisticsTableItemMultiplier__6_iwA",
        statisticsTableItemWin: "statistics_statisticsTableItemWin__0MyeS",
        statisticsTableRow: "statistics_statisticsTableRow__R_LyC",
        statisticsPagination: "statistics_statisticsPagination___tn_z",
        statisticsPaginationLast: "statistics_statisticsPaginationLast__s4yGR",
        statisticsCustomHead: "statistics_statisticsCustomHead__rJwcm",
        statisticsDefault: "statistics_statisticsDefault__PcwAS",
        triviaStatistics: "statistics_triviaStatistics__db5YO",
        statisticsTableItemTime: "statistics_statisticsTableItemTime__4KfjV",
        statisticsTableItemPosition: "statistics_statisticsTableItemPosition__JtQf_",
        profileStatistics: "statistics_profileStatistics__py_7A",
        affiliatesStatistics: "statistics_affiliatesStatistics__Lhn4I",
        raceStatistics: "statistics_raceStatistics__vsiZf",
        notiSettings: "statistics_notiSettings__WFwnz",
        infoIcon: "statistics_infoIcon__VINyE",
        settingsTableRow: "statistics_settingsTableRow__lYHwV",
        switchContainer: "statistics_switchContainer__VCrdW",
        notiSettingsControls: "statistics_notiSettingsControls__ekZ_K",
        notiTab: "statistics_notiTab__AEYn8",
        container: "statistics_container__aucvX",
        info: "statistics_info__EqQn9",
        tabsContainer: "statistics_tabsContainer__qvxKD",
        tabContentHeading: "statistics_tabContentHeading__qBBz0",
        tabContent: "statistics_tabContent__soXsZ",
        switchesContainer: "statistics_switchesContainer__BB6C1",
        switchItem: "statistics_switchItem__xfrrx",
        rainSelectWrapper: "statistics_rainSelectWrapper__SKj53",
        select__option: "statistics_select__option__qgQCv",
        customBalanceWrapper: "statistics_customBalanceWrapper__YCYvM"
      };
    },
    63436: function (e) {
      e.exports = {
        text: "text_text__fMaR4",
        smHeadlines: "text_smHeadlines__aYcqT",
        regular16: "text_regular16__7x_ra",
        semibold16: "text_semibold16__544ge",
        regular14: "text_regular14__MHg5s",
        semibold14: "text_semibold14__cxkXo",
        textNumber: "text_textNumber__3X5Pp",
        labelsRegular: "text_labelsRegular__YFakN",
        labelsSemibold: "text_labelsSemibold__u9ljo",
        bold23: "text_bold23__Gj1_P",
        semibold23: "text_semibold23__q42Rj",
        bold14: "text_bold14__OYQSw"
      };
    },
    59848: function (e) {
      e.exports = {
        triviaGame: "trivia_triviaGame__RoygT",
        triviaGamePlayer: "trivia_triviaGamePlayer__k2Ivf",
        triviaGamePlayerPreview: "trivia_triviaGamePlayerPreview__OduYP",
        isVideoLoading: "trivia_isVideoLoading___wll0",
        triviaGamePlayerVideo: "trivia_triviaGamePlayerVideo__I6OPn",
        triviaGameStats: "trivia_triviaGameStats___bcnN",
        triviaGameStatsItem: "trivia_triviaGameStatsItem__nbYCB",
        triviaGameStatsItemIcon: "trivia_triviaGameStatsItemIcon__fBZcs",
        triviaGameStatsItemText: "trivia_triviaGameStatsItemText__D5gV_",
        triviaBet: "trivia_triviaBet__E4CLP",
        triviaBetQuestion: "trivia_triviaBetQuestion__XEX_F",
        triviaBetOptions: "trivia_triviaBetOptions__9QbV2",
        triviaBetOptionsItem: "trivia_triviaBetOptionsItem__vYuex",
        triviaBetOptionsItemCorrect: "trivia_triviaBetOptionsItemCorrect__m7yfC",
        triviaBetOptionsItemWrong: "trivia_triviaBetOptionsItemWrong__l14Mo",
        triviaBetSubmit: "trivia_triviaBetSubmit__zaadE",
        triviaBetSubmitButton: "trivia_triviaBetSubmitButton__40vps",
        triviaBetSubmitSummary: "trivia_triviaBetSubmitSummary__kEKet"
      };
    },
    77020: function () {}
  }]);