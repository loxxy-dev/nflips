# how does this shit work!?
<br>
basically BloxFlip didnt shut down their staging server, so basically this just proxies all requests to their staging API and overrides some of ther webpacl chunks to make it all work together
<br>
ok bye mwah
